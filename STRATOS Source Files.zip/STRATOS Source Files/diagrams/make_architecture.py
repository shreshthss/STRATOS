"""Generate STRATOS_System_Architecture.svg/.png (functional block diagram, proposed)."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "design"))
from svgkit import SVG, C, legend
from baseline import NAMES as N, RADIO, PINS

OUT = sys.argv[1]
gp = {sig: gpio for (_r, sig, gpio, *_x) in PINS}
W, H = 1500, 985
s = SVG(W, H, "STRATOS system architecture (proposed)",
        "Functional block diagram: sensing, control, onboard storage, telemetry, ground station, reconciliation and power.")
s.text(30, 36, "STRATOS — System architecture (functional block diagram)", size=21, weight=700)
s.text(30, 59, "Proposed design, Rev A. One baseline: the same parts appear in the BOM, schematic, pin map, power budget and CAD model.",
       size=12, fill=C["muted"])

s.rect(25, 78, 955, 670, fill=C["payload"], stroke=C["payload_edge"], sw=1.6, rx=12)
s.text(45, 103, "PAYLOAD  (Ø 65 × 113 mm can; proposed)", size=14, weight=700, fill=C["payload_edge"])
s.rect(1060, 78, 415, 670, fill=C["ground"], stroke=C["ground_edge"], sw=1.6, rx=12)
s.text(1080, 103, "GROUND STATION", size=14, weight=700, fill=C["ground_edge"])

# sensors
BME = (50, 130, 240, 78); s.block(*BME, "Environmental sensor", ["Bosch BME280: T, RH, P", "I2C @ 0x76/0x77"])
IMU = (50, 235, 240, 78); s.block(*IMU, "Motion sensor", ["ST LSM6DSOX: acc + gyro", f"I2C @ 0x6A · INT1 → IO{gp['IMU_INT1']}"])
VB = (50, 340, 240, 70); s.block(*VB, "Battery monitor", ["100 k / 100 k divider", f"ADC1 → IO{gp['VBAT_SENSE']}"])
# MCU
MCU = (365, 130, 270, 340)
s.block(*MCU, "Controller", ["ESP32-DevKitC V4", "(ESP32-WROOM-32E)"], fill="#FFFFFF", edge=C["payload_edge"])
mods = ["Acquisition + plausibility", "Record builder (seq, t_ms)", "Logger (ring buffer, CRC)", "Packet encoder (CRC-16)",
        "Radio driver", "Error handler / status", "Power + landing monitor"]
for i, m in enumerate(mods):
    s.rect(380, 186 + i * 38, 240, 30, fill=C["panel"], stroke=C["grid"], rx=5)
    s.text(500, 206 + i * 38, m, size=11, anchor="middle")
# storage + radio
SD = (710, 130, 245, 110); s.block(*SD, "Onboard storage", ["microSD (3 V breakout)", f"VSPI: IO{gp['SD_SCK']}/{gp['SD_MISO']}/{gp['SD_MOSI']}, CS IO{gp['SD_CS']}",
                                                             "LOG_<session>.CSV, 10 Hz", "independent of reception"],
                                    fill=C["hl"], edge=C["warn"])
RAD = (710, 290, 245, 110); s.block(*RAD, "Telemetry transmitter", ["Ra-01H (Semtech SX1276)", f"HSPI: IO{gp['RADIO_SCK']}/{gp['RADIO_MISO']}/{gp['RADIO_MOSI']}, NSS IO{gp['RADIO_NSS']}",
                                                                     f"GFSK {RADIO['freq_mhz']:.0f} MHz, +{RADIO['tx_power_dbm']} dBm, 1 Hz", "868 MHz helical antenna"])
IND = (710, 425, 245, 55); s.block(*IND, "Status outputs", [f"buzzer (IO{gp['BUZZER_EN']} via NPN) · LED (IO{gp['STATUS_LED']})"])

# power chain
py = 560
PW = [("18650 Li-ion", "BT1, 1 cell"), ("Protection", "DW01A + FS8205A"), ("PTC fuse", "2.5 A hold (RGEF250)"), ("SW1 pole A", "master switch"),
      ("S7V8F3", "3.3 V buck-boost"), ("SW1 pole B", "isolates regulator")]
xs = [50 + i * 152 for i in range(len(PW))]
for x, (a, b) in zip(xs, PW):
    s.block(x, py, 132, 62, a, [b], fill="#FFF7EF", edge=C["power"], tsize=12)
for i in range(len(PW) - 1):
    s.path([(xs[i] + 132, py + 31), (xs[i + 1], py + 31)], "power")
# VSYS sense drawn as labelled stubs (net-label style) so it does not cross other blocks or the rail
s.path([(xs[3] + 66, py + 62), (xs[3] + 66, py + 80)], "power")
s.text(xs[3] + 66, py + 96, "VSYS 3.0–4.2 V → battery monitor", size=10.5, fill=C["power"], anchor="middle", weight=600)
RAIL_Y = 520
s.path([(xs[5] + 66, py), (xs[5] + 66, RAIL_Y)], "power")
s.add(f'<line x1="70" y1="{RAIL_Y}" x2="955" y2="{RAIL_Y}" stroke="{C["power"]}" stroke-width="3"/>')
s.text(300, RAIL_Y + 17, "+3V3 rail (all modules)", size=10.5, fill=C["power"], weight=650)
for x, lab in ((120, "sensors"), (500, "controller"), (830, "storage, radio, outputs")):
    s.path([(x, RAIL_Y), (x, RAIL_Y - 14)], "power")
    s.text(x + 6, RAIL_Y - 4, lab, size=9.5, fill=C["power"])
s.path([(170, 432), (170, 410)], "power")
s.text(178, 446, "VSYS (from SW1 pole A)", size=9.5, fill=C["power"], weight=600)
s.text(50, 692, "Charging: normally in an external charger; supervised USB-C bench charging only with the shell removed.", size=11, fill=C["muted"])
s.text(50, 710, "USB on the ESP32 board is used only with SW1 OFF (pole B disconnects the regulator from the rail).", size=11, fill=C["muted"])

# data / control arrows in payload
s.path([(290, 169), (365, 169)], "data", "I2C", (327, 162))
s.path([(290, 274), (365, 274)], "data", "I2C + INT", (327, 267))
s.path([(290, 375), (365, 375)], "data", "ADC", (327, 368))
s.path([(635, 175), (710, 175)], "data", "every record", (672, 168))
s.path([(710, 215), (635, 215)], "control", "flush result", (672, 230))
s.path([(635, 330), (710, 330)], "data", "1 in 10", (672, 323))
s.path([(710, 370), (635, 370)], "control", "TX complete", (672, 385))
s.path([(635, 452), (710, 452)], "control")

# ground
RX = (1085, 130, 365, 92); s.block(*RX, "Receiver", ["Ra-01H + ESP32-DevKitC (receive firmware)", "868 MHz 1 dBi antenna, elevated",
                                                       "USB serial: RX,ms,rssi,snr,len,hex"])
VAL = (1085, 260, 365, 78); s.block(*VAL, "Packet validation", ["length · CRC-16 · magic/version", "seq tracking: gap / duplicate / session"])
GL = (1085, 375, 175, 92); s.block(*GL, "Ground logging", ["accepted · rejected", "gaps · raw capture", "UTC timestamps"], fill=C["hl"], edge=C["warn"])
LD = (1275, 375, 175, 92); s.block(*LD, "Live display", ["values, counts,", "gaps, rejects", "(from the log)"])
RC = (1085, 520, 365, 120); s.block(*RC, "Post-mission reconciliation", ["onboard log  vs  ground logs", "match / missing / corrupted /", "not transmitted / ground-only",
                                                                         "summary counts + discrepancy list"], fill="#F6F1FB", edge=C["control"])
s.path([(955, 345), (1010, 345), (1010, 176), (1085, 176)], "rf")
s.label(1010, 270, "GFSK", C["rf"], 10.5)
s.label(1010, 286, f"{RADIO['freq_mhz']:.0f} MHz", C["rf"], 10)
s.path([(1267, 222), (1267, 260)], "data", "frames", (1300, 245))
s.path([(1172, 338), (1172, 375)], "data", "accepted", (1210, 360))
s.path([(1260, 421), (1275, 421)], "data")
s.path([(1172, 467), (1172, 520)], "data", "ground logs", (1220, 497))
# physical card transfer
s.path([(955, 200), (995, 200), (995, 600), (1085, 600)], "control")
s.label(995, 680 - 60, "microSD card read", C["control"], 10)
s.label(995, 636, "after recovery", C["control"], 10)

# error / detection markers
for (x, y, n) in [(300, 140, 1), (700, 140, 2), (700, 300, 3), (1040, 160, 4), (40, 568, 5), (40, 345, 6)]:
    s.err(x, y, n)
for (x, y, n) in [(645, 145, 1), (955, 255, 2), (955, 410, 3), (1460, 300, 4), (645, 470, 5), (300, 395, 6), (1460, 540, 7)]:
    s.det(x, y, n)

# error table
s.rect(25, 768, 955, 200, fill="#FFFFFF", stroke=C["grid"], rx=10)
s.text(45, 793, "Where errors can occur (E) and where they are detected (D)", size=13, weight=700)
rows = [("E1", "sensor read fails or value implausible", "D1", "controller sets *_INVALID flag, writes sentinel / empty field"),
        ("E2", "microSD write or flush fails; card removed", "D2", "SD_WRITE_ERR flag; per-line CRC exposes damaged lines"),
        ("E3", "radio does not report TX complete", "D3", "tx = 'F' in onboard log; RADIO_ERR flag in next packet"),
        ("E4", "frame lost or corrupted on the link", "D4", "ground CRC-16 rejects frame; pkt_seq gap logged"),
        ("E5", "power interruption / brown-out reset", "D5", "new session ID; time restart visible; truncated line fails CRC"),
        ("E6", "battery depleted", "D6", "VBAT monitor → VBAT_LOW flag → safe shutdown closes the log"),
        ("—", "any loss above, after recovery", "D7", "reconciliation classifies every discrepancy or reports it as unresolved")]
for i, (e, et, d, dt) in enumerate(rows):
    y = 818 + i * 21
    s.text(45, y, e, size=10.5, weight=700, fill=C["error"])
    s.text(75, y, et, size=10.5)
    s.text(390, y, d, size=10.5, weight=700, fill=C["ok"])
    s.text(420, y, dt, size=10.5)
legend(s, 1060, 768, ["data", "control", "power", "rf"], "Legend (line style carries meaning)",
       extra=[(lambda sv, x, y: sv.err(x, y, ""), "Error source (E#)"), (lambda sv, x, y: sv.det(x, y, ""), "Detection point (D#)")])
s.text(1475, 975, "STRATOS • Team Nothingburger • Rev A", size=9, fill=C["muted"], anchor="end")
s.save(os.path.join(OUT, "STRATOS_System_Architecture.svg"), os.path.join(OUT, "STRATOS_System_Architecture.png"))
print("ok")
