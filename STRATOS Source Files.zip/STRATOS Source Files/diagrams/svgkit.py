"""Tiny SVG helper used to generate the STRATOS diagrams as editable SVG.

Every diagram is generated from Python so that names, pin labels and numbers
come from the same baseline data as the BOM, schematic and budgets.
"""
from __future__ import annotations

from xml.sax.saxutils import escape

FONT = "Inter, 'DejaVu Sans', Arial, Helvetica, sans-serif"
MONO = "'DejaVu Sans Mono', Consolas, monospace"

C = {
    "ink": "#1B2733", "muted": "#5B6875", "line": "#8A96A3", "grid": "#E3E8EE",
    "paper": "#FFFFFF", "panel": "#F5F7FA",
    "payload": "#E8F0F8", "payload_edge": "#2F5D8A",
    "ground": "#EEF6EE", "ground_edge": "#3C7A47",
    "data": "#1F5F99", "control": "#6B4FA0", "power": "#C0571B", "rf": "#0F7C83",
    "error": "#B3261E", "error_fill": "#FDECEA", "ok": "#2E7D32", "warn": "#B26A00",
    "box": "#FFFFFF", "box_edge": "#5B6875", "hl": "#FFF4D6",
}

STYLES = {
    # kind: (colour, width, dasharray, marker)
    "data": (C["data"], 1.8, None, "arrow-data"),
    "control": (C["control"], 1.4, "6 4", "arrow-control"),
    "power": (C["power"], 2.6, None, "arrow-power"),
    "rf": (C["rf"], 1.8, "2 3", "arrow-rf"),
    "plain": (C["line"], 1.2, None, "arrow-plain"),
    "error": (C["error"], 1.4, "4 3", "arrow-error"),
}


class SVG:
    def __init__(self, w, h, title="", desc=""):
        self.w, self.h = w, h
        self.items = []
        self.title, self.desc = title, desc

    def add(self, s):
        self.items.append(s)

    # -- primitives ----------------------------------------------------------
    def rect(self, x, y, w, h, fill="#fff", stroke=C["box_edge"], sw=1.2, rx=6, dash=None, extra=""):
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" '
                 f'stroke="{stroke}" stroke-width="{sw}"{d} {extra}/>')

    def text(self, x, y, s, size=12, weight=400, fill=C["ink"], anchor="start", family=FONT,
             italic=False, extra=""):
        st = ' font-style="italic"' if italic else ""
        self.add(f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" '
                 f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" xml:space="preserve"{st} {extra}>'
                 f'{escape(str(s))}</text>')

    def lines(self, x, y, rows, size=11, lh=None, **kw):
        lh = lh or size * 1.35
        for i, r in enumerate(rows):
            self.text(x, y + i * lh, r, size=size, **kw)

    def line(self, x1, y1, x2, y2, stroke=C["line"], sw=1, dash=None):
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{sw}"{d}/>')

    def path(self, pts, kind="data", label=None, label_pos=None, label_size=10, both=False):
        col, sw, dash, mk = STYLES[kind]
        d = "M " + " L ".join(f"{x} {y}" for x, y in pts)
        da = f' stroke-dasharray="{dash}"' if dash else ""
        ms = f' marker-start="url(#{mk}-rev)"' if both else ""
        self.add(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{sw}"{da} '
                 f'marker-end="url(#{mk})"{ms} stroke-linejoin="round"/>')
        if label:
            lx, ly = label_pos if label_pos else ((pts[0][0] + pts[-1][0]) / 2, (pts[0][1] + pts[-1][1]) / 2 - 5)
            self.label(lx, ly, label, col, label_size)

    def label(self, x, y, s, col=C["ink"], size=10, anchor="middle"):
        w = len(str(s)) * size * 0.56 + 8
        x0 = x - w / 2 if anchor == "middle" else (x if anchor == "start" else x - w)
        self.add(f'<rect x="{x0:.1f}" y="{y - size}" width="{w:.1f}" height="{size + 5}" rx="3" '
                 f'fill="#FFFFFF" fill-opacity="0.92"/>')
        self.text(x, y, s, size=size, fill=col, anchor=anchor, weight=500)

    def block(self, x, y, w, h, title, sub=(), fill=C["box"], edge=C["box_edge"], tsize=12.5,
              ssize=10, dash=None, tag=None, tagcol=None):
        self.rect(x, y, w, h, fill=fill, stroke=edge, sw=1.4, dash=dash)
        self.text(x + w / 2, y + 18, title, size=tsize, weight=650, anchor="middle")
        for i, s in enumerate(sub):
            self.text(x + w / 2, y + 18 + 15 + i * (ssize * 1.32), s, size=ssize, fill=C["muted"], anchor="middle")
        if tag:
            tw = len(tag) * 6.2 + 10
            self.rect(x + w - tw - 4, y - 9, tw, 16, fill=tagcol or C["warn"], stroke="none", rx=8)
            self.text(x + w - tw / 2 - 4, y + 3, tag, size=9, weight=650, fill="#fff", anchor="middle")

    def err(self, x, y, n):
        """Numbered error-point marker (diamond)."""
        s = 9
        self.add(f'<path d="M {x} {y - s} L {x + s} {y} L {x} {y + s} L {x - s} {y} Z" '
                 f'fill="{C["error_fill"]}" stroke="{C["error"]}" stroke-width="1.4"/>')
        self.text(x, y + 3.5, f"E{n}", size=8.5, weight=700, fill=C["error"], anchor="middle")

    def det(self, x, y, n):
        """Numbered detection-point marker (circle)."""
        self.add(f'<circle cx="{x}" cy="{y}" r="9" fill="#E8F5E9" stroke="{C["ok"]}" stroke-width="1.4"/>')
        self.text(x, y + 3.5, f"D{n}", size=8.5, weight=700, fill=C["ok"], anchor="middle")

    # -- output --------------------------------------------------------------
    def defs(self):
        out = ["<defs>"]
        for kind, (col, sw, dash, mk) in STYLES.items():
            for rev, ref in ((False, ""), (True, "-rev")):
                pts = "0 0, 10 4, 0 8" if not rev else "10 0, 0 4, 10 8"
                out.append(f'<marker id="{mk}{ref}" viewBox="0 0 10 8" refX="{0 if rev else 9}" refY="4" '
                           f'markerWidth="{7 if kind != "power" else 6}" markerHeight="{6 if kind != "power" else 5}" '
                           f'orient="auto"><polygon points="{pts}" fill="{col}"/></marker>')
        out.append("</defs>")
        return "\n".join(out)

    def render(self):
        head = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" '
                f'viewBox="0 0 {self.w} {self.h}">')
        meta = f"<title>{escape(self.title)}</title><desc>{escape(self.desc)}</desc>"
        bg = f'<rect width="{self.w}" height="{self.h}" fill="{C["paper"]}"/>'
        return "\n".join([head, meta, self.defs(), bg] + self.items + ["</svg>"])

    def save(self, path_svg, path_png=None, scale=2.5):
        with open(path_svg, "w", encoding="utf-8") as f:
            f.write(self.render())
        if path_png:
            import cairosvg
            cairosvg.svg2png(url=path_svg, write_to=path_png, scale=scale)


def legend(svg: SVG, x, y, kinds, title="Legend", extra=()):
    names = {"data": "Measurement / data flow", "control": "Control / command flow",
             "power": "Power distribution", "rf": "Radio link (866 MHz GFSK)",
             "error": "Error path"}
    h = 26 + 18 * (len(kinds) + len(extra))
    svg.rect(x, y, 250, h, fill=C["panel"], stroke=C["grid"], rx=6)
    svg.text(x + 10, y + 17, title, size=11, weight=650)
    for i, k in enumerate(kinds):
        yy = y + 34 + i * 18
        col, sw, dash, mk = STYLES[k]
        da = f' stroke-dasharray="{dash}"' if dash else ""
        svg.add(f'<path d="M {x + 10} {yy - 4} L {x + 52} {yy - 4}" stroke="{col}" stroke-width="{sw}"{da} '
                f'marker-end="url(#{mk})" fill="none"/>')
        svg.text(x + 62, yy, names[k], size=10.5)
    for j, (draw, txt) in enumerate(extra):
        yy = y + 34 + (len(kinds) + j) * 18
        draw(svg, x + 30, yy - 4)
        svg.text(x + 62, yy, txt, size=10.5)
