"""Render STRATOS_Ground_Station_Mockup.png from the prototype software state.

The ground-station tracker is fed the SIMULATED serial capture up to the frame
of packet 123, and the screen below is drawn from that tracker state. It shows
what the proposed interface would display; it is not connected to hardware.
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "software"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch
from stratos_gs.tracker import GroundTracker
from stratos_gs.packet import to_engineering

SIM, OUT = sys.argv[1], sys.argv[2]
STOP_AT = 123
for f in ("Inter", "DejaVu Sans"):
    if any(f in x.name for x in font_manager.fontManager.ttflist):
        plt.rcParams["font.family"] = f; break

INK, INK2, MUTED, GRID, SURF = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e1", "#fcfcfb"
BLUE, ORANGE = "#2a78d6", "#eb6834"
GOOD, WARN, CRIT = "#008300", "#b26a00", "#c62828"

tr = GroundTracker()
for raw in open(os.path.join(SIM, "rx_serial_capture.txt")):
    if raw.startswith("#"):
        continue
    utc, _, line = raw.strip().partition(" ")
    ev = tr.feed_line(line, utc)
    if ev and ev.accepted and ev.packet.pkt_seq == STOP_AT:
        break
acc = [e for e in tr.events if e.accepted]
last = acc[-1]
s = tr.summary()
st = tr.sessions[last.packet.session]
missing = sorted(set(q for a, b in st.gaps for q in range(a, b + 1)) - st.received)

fig = plt.figure(figsize=(16, 10), dpi=150, facecolor=SURF)
def box(x, y, w, h, fc="#ffffff", ec=GRID, lw=1.2):
    fig.add_artist(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.008",
                                  transform=fig.transFigure, fc=fc, ec=ec, lw=lw))
def t(x, y, s, **kw):
    kw.setdefault("color", INK); fig.text(x, y, s, transform=fig.transFigure, **kw)

# banner
box(0.02, 0.925, 0.96, 0.06, fc="#fff4d6", ec=WARN, lw=1.5)
t(0.035, 0.952, "SIMULATED DATA  •  Proposed ground-station interface — not yet connected to physical hardware",
  fontsize=15, weight="bold", color="#7a4a00", va="center")
t(0.965, 0.952, "replaying sim capture (seed 2026)", fontsize=10.5, color="#7a4a00", va="center", ha="right")
t(0.02, 0.895, f"STRATOS Ground Station  ·  session {last.packet.session}  ·  receiver: serial replay  ·  "
  f"logging to ground_accepted.csv / ground_rejected.csv / ground_gaps.csv", fontsize=11, color=INK2)

# status tiles
tiles = [
    ("Last packet", f"#{last.packet.pkt_seq}", f"rec_seq {last.packet.rec_seq} · t = {last.packet.t_ms / 1000:.1f} s", INK),
    ("Reception", "RECEIVING", f"RSSI {last.rssi:.0f} dBm (GFSK: no SNR)", GOOD),
    ("Last integrity check", "CRC OK", "CRC-16/CCITT-FALSE verified", GOOD),
    ("Packets accepted", f"{s['accepted']}", f"duplicates flagged: {s['duplicates']}", INK),
    ("Frames rejected", f"{s['rejected']}", "reason: CRC mismatch ×1", CRIT),
    ("Missing packets", f"{len(missing)}", "seq " + ", ".join(str(m) for m in missing[:2]) + ", 120–122", WARN),
    ("Recording", "● REC ON", f"{s['accepted']} rows · 1 reject row", GOOD),
]
tw = 0.96 / len(tiles)
for i, (lab, val, sub, col) in enumerate(tiles):
    x = 0.02 + i * tw
    box(x + 0.003, 0.74, tw - 0.006, 0.13)
    t(x + 0.012, 0.845, lab, fontsize=10, color=INK2)
    t(x + 0.012, 0.79, val, fontsize=21, weight="bold", color=col)
    t(x + 0.012, 0.755, sub, fontsize=8.8, color=MUTED)

# charts
tt = [e.packet.t_ms / 1000 for e in acc]
P = [to_engineering(e.packet)["press_hPa"] for e in acc]
T = [to_engineering(e.packet)["temp_C"] for e in acc]
gap_t = []
for a, b in st.gaps:
    prev = max((e.packet.t_ms for e in acc if e.packet.pkt_seq < a), default=0) / 1000
    nxt = min((e.packet.t_ms for e in acc if e.packet.pkt_seq > b), default=prev * 1000) / 1000
    gap_t.append((prev, nxt, a, b))

def chart(rect, y, title, unit, col, inv=False):
    ax = fig.add_axes(rect, facecolor="#ffffff")
    for (x0, x1, a, b) in gap_t:
        ax.axvspan(x0, x1, color="#fdecea", lw=0, zorder=0)
    ax.plot(tt, y, color=col, lw=2, zorder=3)
    ax.set_title(title, loc="left", fontsize=12, color=INK, weight="bold", pad=8)
    ax.set_xlabel("payload elapsed time t_ms (s)", fontsize=9.5, color=INK2)
    ax.set_ylabel(unit, fontsize=9.5, color=INK2)
    ax.grid(True, color=GRID, lw=0.8); ax.set_axisbelow(True)
    for sp in ax.spines.values(): sp.set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=9)
    if inv: ax.invert_yaxis()
    return ax
ax1 = chart([0.045, 0.40, 0.42, 0.28], P, "Pressure (received packets)", "hPa  (axis inverted: up = higher altitude)", BLUE, inv=True)
ax2 = chart([0.53, 0.40, 0.42, 0.28], T, "Temperature (received packets)", "°C", ORANGE)
labels = []
for (x0, x1, a, b) in gap_t:
    lab = f"{a}" if a == b else f"{a}–{b}"
    if labels and x0 - labels[-1][1] < 15:      # merge labels of nearby gaps
        labels[-1] = (labels[-1][0], x1, labels[-1][2] + ", " + lab)
    else:
        labels.append((x0, x1, lab))
for (x0, x1, lab) in labels:
    ax1.annotate("missing pkt " + lab, xy=(x1, ax1.get_ylim()[1]), xytext=(4, -14), textcoords="offset points",
                 ha="left" if x1 < 100 else "right", fontsize=8.5, color=CRIT)

# reception strip
ax3 = fig.add_axes([0.045, 0.27, 0.905, 0.06], facecolor="#ffffff")
for q in range(1, last.packet.pkt_seq + 1):
    c = GOOD if q in st.received else CRIT
    ax3.add_patch(plt.Rectangle((q - 0.5, 0), 0.8, 1, color=c, lw=0))
ax3.set_xlim(0.5, last.packet.pkt_seq + 0.5); ax3.set_ylim(0, 1); ax3.set_yticks([])
ax3.tick_params(colors=INK2, labelsize=9)
for sp in ax3.spines.values(): sp.set_visible(False)
ax3.set_title("Packet sequence map (each bar = one pkt_seq):  green = accepted, red = missing", loc="left",
              fontsize=11, color=INK, weight="bold", pad=6)

# event log
box(0.02, 0.03, 0.96, 0.19)
t(0.035, 0.195, "Event log (most recent last)", fontsize=11.5, weight="bold")
events = []
for e in tr.events:
    if not e.accepted:
        events.append(f"{e.rx_utc[11:23]}  REJECTED  reason={e.reason}  len={len(e.raw)}  raw frame kept in ground_rejected.csv")
    elif e.seq_event:
        events.append(f"{e.rx_utc[11:23]}  #{e.packet.pkt_seq:<4} {e.seq_event:<12} "
                      + ("missing sequence number(s) logged to ground_gaps.csv" if "GAP" in e.seq_event
                         else "second copy flagged, not double-counted"))
events.append(f"{last.rx_utc[11:23]}  #{last.packet.pkt_seq:<4} accepted   T={to_engineering(last.packet)['temp_C']:.2f} °C  "
              f"P={to_engineering(last.packet)['press_hPa']:.2f} hPa  RH={to_engineering(last.packet)['rh_pct']:.1f} %  "
              f"Vbat={to_engineering(last.packet)['vbat_V']:.2f} V")
for i, ev in enumerate(events[-6:]):
    col = CRIT if "REJECTED" in ev or "GAP" in ev else INK2
    t(0.035, 0.165 - i * 0.022, ev, fontsize=9.6, family="DejaVu Sans Mono", color=col)
t(0.965, 0.04, "Times shown are synthetic (base date 2000-01-01). STRATOS • proposed design",
  fontsize=8.5, color=MUTED, ha="right")
fig.savefig(os.path.join(OUT, "STRATOS_Ground_Station_Mockup.png"), facecolor=SURF)
print("ok", s, missing)
