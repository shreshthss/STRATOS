"""Generate STRATOS_Telemetry_Architecture.svg/.png and STRATOS_Telemetry_Sequence.svg/.png."""
import os, sys, csv
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "design"))
sys.path.insert(0, os.path.join(HERE, "..", "software"))
from svgkit import SVG, C, MONO, legend
from baseline import RADIO, RECORD_PERIOD_MS, TX_EVERY_N
from stratos_gs.radio import fsk_time_on_air_ms

OUT, SIM = sys.argv[1], sys.argv[2]
air = fsk_time_on_air_ms(RADIO["payload_bytes"], RADIO["bitrate_bps"], RADIO["preamble_bytes"], RADIO["sync_bytes"])["t_total_ms"]
ex_hex = open(os.path.join(SIM, "rx_serial_capture.txt")).read().split("\n")[1].split(",")[-1]

# =============================================================================
# 1. Telemetry architecture
# =============================================================================
W, H = 1500, 1060
s = SVG(W, H, "STRATOS telemetry architecture (proposed)",
        "Onboard logging, packet construction, radio link, ground validation, ground logging and reconciliation.")
s.text(30, 36, "STRATOS — Telemetry, onboard logging and reconciliation architecture", size=21, weight=700)
s.text(30, 59, f"Proposed design. Records every {RECORD_PERIOD_MS} ms (10 Hz); every {TX_EVERY_N}th record is also transmitted "
       f"(1 Hz). GFSK {RADIO['freq_mhz']:.1f} MHz, {RADIO['bitrate_bps']/1000:.1f} kb/s, ±{RADIO['fdev_khz']:.0f} kHz: "
       f"{RADIO['payload_bytes']}-byte frame ≈ {air:.1f} ms on air ({air/10:.2f} % duty cycle).", size=12, fill=C["muted"])

# panels
s.rect(25, 80, 640, 640, fill=C["payload"], stroke=C["payload_edge"], sw=1.6, rx=12)
s.text(45, 106, "PAYLOAD (ESP32-WROOM-32E firmware)", size=14, weight=700, fill=C["payload_edge"])
s.rect(835, 80, 640, 640, fill=C["ground"], stroke=C["ground_edge"], sw=1.6, rx=12)
s.text(855, 106, "GROUND STATION (receiver + laptop software)", size=14, weight=700, fill=C["ground_edge"])

ACQ = (60, 130, 270, 74); s.block(*ACQ, "1  Sensor acquisition", ["BME280 (T, RH, P) · IMU (acc, gyro)", "battery voltage (ADC)"])
REC = (60, 250, 270, 92); s.block(*REC, "2  Structured record", ["session · rec_seq · t_ms", "10 measurement fields · status flags", "absent value → flag + sentinel"])
LOG = (370, 250, 270, 92); s.block(*LOG, "3  Onboard log (every record)", ["RAM ring buffer → microSD", "CSV line + line CRC-16", "LOG_<session>.CSV, flush 1 s"],
                                   fill=C["hl"], edge=C["warn"])
PKT = (60, 400, 270, 92); s.block(*PKT, "4  Packet construction", ["1 record in 10 (rec_seq mod 10 = 1)", "pkt_seq + 1 · 44-byte binary frame", "CRC-16/CCITT-FALSE (bytes 0–41)"])
TXB = (60, 545, 270, 92); s.block(*TXB, "5  Radio transmission", [f"{RADIO['module']} ({RADIO['chip']})", f"+{RADIO['tx_power_dbm']} dBm, non-blocking", "PacketSent (DIO0) or 50 ms timeout"])
OUTC = (370, 545, 270, 92); s.block(*OUTC, "Radio outcome → log", ["tx = 'T' (PacketSent seen)", "tx = 'F' (timeout) + RADIO_ERR", "written into the same CSV line"])

RX = (870, 130, 270, 92); s.block(*RX, "6  Reception", [f"{RADIO['module']} + ESP32 receiver", "USB serial: RX,ms,rssi,snr,len,hex", "host adds UTC reception time"])
VAL = (870, 270, 270, 92); s.block(*VAL, "7  Validation", ["length = 44 bytes", "CRC-16 verified before any field", "magic 'ST', version, type"])
REJ = (1180, 270, 265, 92); s.block(*REJ, "Reject log", ["ground_rejected.csv", "reason + raw bytes kept", "counted, never silently dropped"],
                                    fill=C["error_fill"], edge=C["error"])
SEQ = (870, 410, 270, 92); s.block(*SEQ, "8  Sequence tracking", ["per-session expected pkt_seq", "GAP / DUPLICATE / OUT_OF_ORDER", "SESSION_CHANGE (payload reboot)"])
GLOG = (870, 550, 270, 92); s.block(*GLOG, "9  Ground logs", ["ground_accepted.csv (+ rx_utc,", "rssi, snr, seq_event)", "ground_gaps.csv · raw capture"],
                                     fill=C["hl"], edge=C["warn"])
DISP = (1180, 550, 265, 92); s.block(*DISP, "Live display", ["reads the logged stream", "shows gaps and rejects", "(not the record of truth)"])

def R(b, f=0.5): return b[0] + b[2], b[1] + b[3] * f
def L(b, f=0.5): return b[0], b[1] + b[3] * f
def T(b, f=0.5): return b[0] + b[2] * f, b[1]
def B(b, f=0.5): return b[0] + b[2] * f, b[1] + b[3]

s.path([B(ACQ), T(REC)], "data", "I2C reads, plausibility checks", (195, 232))
s.path([R(REC), L(LOG)], "data", "every record", (350, 288))
s.path([B(REC), T(PKT)], "data", "1 in 10", (195, 378))
s.path([B(PKT), T(TXB)], "data", "SPI → radio FIFO", (195, 524))
s.path([R(TXB), L(OUTC)], "control")
s.label(350, 612, "PacketSent", C["control"], 9.5)
s.label(350, 626, "/ timeout", C["control"], 9.5)
s.path([T(OUTC), B(LOG)], "control", "outcome", (530, 445))
# radio link
s.path([B(TXB, 0.5), (195, 685), (760, 685), (760, 176), L(RX)], "rf")
s.label(750, 380, "GFSK frame", C["rf"], 11)
s.label(750, 398, f"{RADIO['freq_mhz']:.1f} MHz · {air:.1f} ms", C["rf"], 10)
s.label(750, 415, "1 per second", C["rf"], 10)
s.err(760, 470, 1)
s.path([B(RX), T(VAL)], "data", "frame bytes", (1005, 252))
s.path([R(VAL), L(REJ)], "error", "fails", (1160, 306))
s.path([B(VAL), T(SEQ)], "data", "valid packet", (1005, 392))
s.path([B(SEQ), T(GLOG)], "data", "accepted + event", (1005, 532))
s.path([R(GLOG), L(DISP)], "data")

# error / detection markers
s.err(345, 140, 2); s.det(366, 140, 1)
s.err(625, 238, 3); s.det(646, 238, 2)
s.det(1160, 342, 3)
s.det(1150, 440, 4)
s.det(645, 545, 5)

# reconciliation band
RECON = (25, 745, 1450, 110)
s.rect(*RECON, fill="#F6F1FB", stroke=C["control"], sw=1.6, rx=12)
s.text(45, 771, "10  Post-mission reconciliation (stratos_gs.reconcile) — after the payload is recovered", size=14, weight=700, fill=C["control"])
s.lines(45, 795, [
    "Inputs: recovered LOG_<session>.CSV + ground_accepted.csv + ground_rejected.csv.   Per session: verify every onboard line CRC; check onboard rec_seq continuity;",
    "match each transmitted record (tx = 'T') to the ground packet with the same pkt_seq and compare 13 fields; classify MISSING (no frame / corrupted frame observed),",
    "NOT_TRANSMITTED (tx = 'F'), MISMATCH, GROUND_ONLY.   Output: counts of onboard records, packets received, invalid packets, missing sequence numbers, matches, unresolved items.",
], size=11.2, lh=19)
s.path([R(LOG, 0.7), (690, 314), (690, 745)], "data")
s.path([B(GLOG, 0.5), (1005, 700), (1005, 745)], "data")
s.det(1290, 775, 6)

# three distinct objects
s.text(30, 885, "Three different data objects (kept distinct throughout the design)", size=13, weight=700)
log1 = [l.strip() for l in open(os.path.join(SIM, "LOG_0007.CSV")) if l.startswith("7,1,")][0]
acc1 = open(os.path.join(SIM, "ground_accepted.csv")).read().splitlines()[1]
objs = [("Local record (onboard CSV line)", log1,
         "integers in packet units; empty field = absent; line CRC"),
        ("Telemetry packet (binary, 44 bytes)", ex_hex[:44] + "…", "little-endian fields; CRC-16 in bytes 42–43"),
        ("Received record (ground CSV row)", acc1, "adds rx UTC, receiver ms, RSSI, SNR, seq_event")]
for i, (t, ex, note) in enumerate(objs):
    x = 30 + i * 345
    s.rect(x, 897, 335, 82, fill=C["panel"], stroke=C["grid"], rx=8)
    s.text(x + 10, 918, t, size=11.5, weight=650)
    s.text(x + 10, 941, ex if len(ex) <= 54 else ex[:53] + "…", size=9.2, family=MONO)
    s.text(x + 10, 963, note, size=10, fill=C["muted"])
s.text(30, 1000, "Example values are from the SIMULATION (session 7, packet 1; synthetic base date 2000-01-01) — not STRATOS measurements.",
       size=11, fill=C["warn"], weight=600)

# legend & marker key
legend(s, 30, 1010 - 0, [], "", extra=[]) if False else None
s.rect(1080, 880, 395, 165, fill="#fff", stroke=C["grid"], rx=8)
s.text(1094, 900, "Where errors occur (E) and are detected (D)", size=11.5, weight=700)
s.lines(1094, 920, [
    "E1 packet lost/corrupted on link → D3 CRC reject, D4 seq gap",
    "E2 sensor read fails/implausible → D1 status flag + sentinel",
    "E3 SD write fails / power cut → D2 SD_WRITE_ERR, line CRC",
    "D5 radio timeout → tx='F' logged onboard",
    "D6 reconciliation explains every gap or reports it",
    "Arrows: solid = data · dashed = control · dotted = radio",
], size=10.2, lh=17)
s.save(os.path.join(OUT, "STRATOS_Telemetry_Architecture.svg"), os.path.join(OUT, "STRATOS_Telemetry_Architecture.png"))

# =============================================================================
# 2. Sequence diagram (one transmit cycle + flush + reconciliation)
# =============================================================================
W2, H2 = 1500, 960
q = SVG(W2, H2, "STRATOS telemetry sequence diagram (proposed)",
        "Order of interactions between sensors, controller, storage, radio, receiver and ground software.")
q.text(30, 36, "STRATOS — Data-flow sequence for one telemetry cycle (proposed)", size=21, weight=700)
q.text(30, 59, "Times are design targets relative to the start of a transmit cycle (t = 0 ms); not measured.", size=12, fill=C["muted"])
parts = ["Sensors\n(BME280, IMU, ADC)", "Controller\n(ESP32 firmware)", "RAM buffer /\nmicroSD log", f"Radio TX\n({RADIO['module']})",
         f"Radio RX\n(ground {RADIO['module']})", "Ground software\n(laptop)", "Reconciliation\n(post-mission)"]
xs = [110 + i * 210 for i in range(len(parts))]
for x, p in zip(xs, parts):
    a, b = p.split("\n")
    q.rect(x - 90, 78, 180, 50, fill=C["payload"] if x < 800 else C["ground"],
           stroke=C["payload_edge"] if x < 800 else C["ground_edge"], rx=8)
    q.text(x, 99, a, size=12.5, weight=700, anchor="middle")
    q.text(x, 116, b, size=10, fill=C["muted"], anchor="middle")
    q.line(x, 128, x, 925, stroke=C["line"], dash="4 4")

def msg(y, i, j, text, kind="data", tlabel=None):
    x1, x2 = xs[i], xs[j]
    off = 6 if x2 > x1 else -6
    q.path([(x1 + off * 0, y), (x2 - off, y)], kind)
    q.label((x1 + x2) / 2, y - 6, text, C["ink"], 10.5)
    if tlabel:
        q.text(22, y + 4, tlabel, size=10, fill=C["muted"], family=MONO)
def selfmsg(y, i, text, tlabel=None, kind="control"):
    x = xs[i]
    if i < 5:
        q.path([(x + 4, y - 8), (x + 40, y - 8), (x + 40, y + 8), (x + 6, y + 8)], kind)
        q.text(x + 48, y + 4, text, size=10.5)
    else:
        q.path([(x - 4, y - 8), (x - 40, y - 8), (x - 40, y + 8), (x - 6, y + 8)], kind)
        q.text(x - 48, y + 4, text, size=10.5, anchor="end")
    if tlabel:
        q.text(22, y + 4, tlabel, size=10, fill=C["muted"], family=MONO)

y = 165
msg(y, 1, 0, "read T, RH, P · acc, gyro · VBAT", "control", "t=0"); y += 38
msg(y, 0, 1, "raw values (I2C / ADC)", "data", "~3"); y += 38
selfmsg(y, 1, "build record: rec_seq+1, t_ms, plausibility → status flags"); y += 40
msg(y, 1, 2, "append record to RAM ring buffer", "data", "~4"); y += 40
selfmsg(y, 1, "rec_seq mod 10 = 1 → pkt_seq+1, encode 44 B, CRC-16"); y += 40
msg(y, 1, 3, "write FIFO, start TX (SPI, non-blocking)", "data", "~5"); y += 40
msg(y, 3, 4, f"GFSK frame on air ≈ {air:.1f} ms", "rf", "5–17"); y += 40
msg(y, 3, 1, "DIO0 PacketSent interrupt", "control", "~17"); y += 40
msg(y, 1, 2, "mark buffered record tx = 'T'", "control"); y += 40
msg(y, 4, 5, "USB serial: RX,ms,rssi,snr,44,hex", "data", "~20"); y += 40
selfmsg(y, 5, "stamp UTC · CRC check · seq tracking · append ground log"); y += 46
q.rect(xs[1] - 70, y - 20, xs[3] - xs[1] + 150, 70, fill="none", stroke=C["error"], dash="5 3", rx=6)
q.text(xs[1] - 62, y - 4, "alt: no PacketSent within 50 ms", size=10.5, weight=650, fill=C["error"])
msg(y + 26, 1, 2, "mark tx = 'F', set RADIO_ERR; reset radio (RST)", "error", "55"); y += 86
msg(y, 1, 2, "flush slot: format CSV lines + line CRC, write + flush", "data", "500"); y += 38
msg(y, 2, 1, "flush result (OK / SD_WRITE_ERR)", "control"); y += 46
q.line(30, y, W2 - 30, y, stroke=C["grid"], sw=1.5)
q.text(40, y + 18, "After recovery of the payload", size=11.5, weight=700, fill=C["control"]); y += 42
msg(y, 2, 6, "recovered LOG_<session>.CSV", "data"); y += 38
msg(y, 5, 6, "ground_accepted.csv + ground_rejected.csv", "data"); y += 38
selfmsg(y, 6, "compare, classify, write report")
q.save(os.path.join(OUT, "STRATOS_Telemetry_Sequence.svg"), os.path.join(OUT, "STRATOS_Telemetry_Sequence.png"))
print("ok", round(air, 2))
