"""Generate STRATOS_Firmware_State_Diagram.svg/.png (proposed firmware behaviour)."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from svgkit import SVG, C, legend

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
W, H = 1420, 900
s = SVG(W, H, "STRATOS firmware state diagram (proposed)",
        "Proposed payload firmware states, transitions and error handling. Design only; not implemented on hardware.")

s.text(30, 34, "STRATOS — Payload firmware state diagram", size=20, weight=700)
s.text(30, 56, "Proposed design (firmware draft not yet run on hardware). 10 Hz record cycle; 1 Hz telemetry; SD flush once per second.",
       size=12, fill=C["muted"])

N = dict(fill="#FFFFFF", edge=C["payload_edge"])
E = dict(fill=C["error_fill"], edge=C["error"])
def st(x, y, w, h, t, sub, **kw): s.block(x, y, w, h, t, sub, **kw); return (x, y, w, h)

# --- start-up row -------------------------------------------------------------
s.add(f'<circle cx="62" cy="118" r="11" fill="{C["ink"]}"/>')
s.text(62, 148, "Power-on / reset", size=10.5, anchor="middle", fill=C["muted"])
INIT = st(130, 86, 230, 66, "INIT", ["serial, ADC, NVS: session = counter + 1", "elapsed time t_ms restarts at 0"], **N)
SELF = st(450, 86, 290, 66, "SELF-TEST", ["probe BME280, IMU, microSD, SX1276 radio", "open LOG_<session>.CSV, write header"], **N)
FAULT = st(860, 86, 270, 66, "FAULT — RETRY", ["no data path (no SD and no radio)", "beeper error code; retry in 5 s"], **E)

# --- main loop --------------------------------------------------------------
READY = st(520, 240, 230, 70, "READY (wait for tick)", ["idle until next 100 ms tick", "background checks run here"], **N)
ACQ = st(900, 240, 260, 70, "ACQUIRE", ["read BME280, IMU, VBAT (ADC)", "plausibility / range checks"], **N)
BUF = st(900, 410, 260, 70, "BUFFER RECORD (local log)", ["rec_seq + 1, t_ms = millis()", "append to RAM ring buffer (50 records)"], **N)
PREP = st(520, 410, 230, 70, "PREPARE PACKET", ["pkt_seq + 1, 44-byte frame", "CRC-16/CCITT-FALSE"], **N)
TX = st(130, 410, 250, 70, "TRANSMIT", ["start FSK TX (non-blocking)", "await PacketSent on DIO0 (≈11.5 ms)"], **N)
FLUSH = st(130, 240, 250, 70, "FLUSH LOG", ["format CSV lines + line CRC", "write, then flush to microSD"], **N)

# --- error handling ------------------------------------------------------------
SENS = st(1200, 240, 195, 84, "SENSOR FAULT", ["field ← sentinel, *_INVALID", "flag set; re-init every 10 s", "(record still logged)"], **E)
SDR = st(130, 600, 250, 84, "SD RECOVERY", ["SD_WRITE_ERR flag; keep buffering", "remount + reopen every 5 s", "buffer full → LOG_OVERFLOW"], **E)
RADR = st(470, 600, 270, 84, "RADIO RECOVERY", ["tx = 'F' in log, RADIO_ERR flag", "reset radio via RST, re-init", "telemetry resumes next slot"], **E)
SHUT = st(860, 600, 280, 84, "SAFE SHUTDOWN", ["VBAT < 3.30 V for 10 samples:", "flush + close file, radio sleep,", "ESP32 deep sleep (until power cycle)"],
          fill="#FFF7E6", edge=C["warn"])

def R(b): x, y, w, h = b; return x + w, y + h / 2
def L(b): x, y, w, h = b; return x, y + h / 2
def T(b, f=0.5): x, y, w, h = b; return x + w * f, y
def B(b, f=0.5): x, y, w, h = b; return x + w * f, y + h

s.path([(73, 118), L(INIT)], "control")
s.path([R(INIT), L(SELF)], "control", "session ID set", (405, 110))
s.path([R(SELF), L(FAULT)], "error", "no SD and no radio", (800, 110))
s.path([B(FAULT, 0.5), (995, 175), (700, 175), (700, 152)], "control", "retry after 5 s", (850, 170))
s.path([B(SELF, 0.3), (537, 240)], "control")
s.label(470, 200, "≥1 data path OK", C["control"], 10)
s.text(470, 216, "(absent devices flagged)", size=9.5, fill=C["muted"], anchor="middle")

s.path([R(READY), L(ACQ)], "control", "100 ms tick", (825, 268))
s.path([B(ACQ, 0.4), T(BUF, 0.4)], "data", "record built", (1004, 368))
s.path([L(BUF), R(PREP)], "data", "rec_seq mod 10 = 1", (842, 432))
s.path([T(BUF, 0.15), (939, 355), (700, 355), (700, 310)], "control", "otherwise", (860, 350))
s.path([L(PREP), R(TX)], "data", "frame + CRC", (450, 438))
s.path([T(TX, 0.75), (317, 370), (575, 370), (575, 310)], "control", "TX started", (445, 365))
s.path([(520, 258), (380, 258)], "control", "rec_seq mod 10 = 6", (450, 252))
s.path([(380, 292), (520, 292)], "control", "flushed OK", (450, 309))

s.path([R(ACQ, ), L(SENS)], "error", "read error", (1180, 268))
s.path([B(SENS, 0.5), (1297, 445), R(BUF)], "data", "flagged record", (1230, 438))
s.path([(130, 260), (92, 260), (92, 625), (130, 625)], "error")
s.label(122, 515, "↓ write / flush fails", C["error"], 10, anchor="start")
s.path([(130, 665), (112, 665), (112, 300), (130, 300)], "control")
s.label(122, 535, "↑ remount OK (records kept in buffer)", C["control"], 10, anchor="start")
s.path([B(TX, 0.8), (330, 560), (560, 560), (560, 600)], "error", "no PacketSent within 50 ms", (445, 555))
s.path([(740, 642), (768, 642), (768, 300), (750, 300)], "control")
s.label(774, 520, "radio re-initialised", C["control"], 10, anchor="start")
s.text(1000, 735 - 160 + 10, "", size=1)
s.text(1000, 586, "from ANY state", size=10.5, weight=650, fill=C["warn"], anchor="middle")
s.path([(1000, 590), (1000, 600)], "error")
# --- notes ------------------------------------------------------------------------
s.rect(30, 720, 820, 160, fill=C["panel"], stroke=C["grid"])
s.text(45, 744, "Global transitions and checks", size=12.5, weight=700)
s.lines(45, 766, [
    "• Any state → brown-out or watchdog reset → power-on/reset: a NEW session ID is issued and t_ms restarts at 0.",
    "   The payload has no real-time clock; absolute (UTC) time is added only by the ground station on reception.",
    "   A time discontinuity is therefore always visible as a session change in both the onboard log and the ground log.",
    "• Background checks in READY every cycle: VBAT-low counter, cycle-time overrun (> 100 ms → CYCLE_OVERRUN flag),",
    "   pressure-based landing detector (altitude stable ±2 m for 60 s after ≥ 30 m descent → recovery beeper chirps).",
    "• Logging never waits for the radio: records are buffered and written whether or not a packet is ever received.",
], size=10.8, lh=18)
legend(s, 880, 720, ["control", "data", "error"], "Legend",
       extra=[(lambda sv, x, y: sv.rect(x - 16, y - 7, 30, 14, fill=C["error_fill"], stroke=C["error"], rx=3),
               "Error-handling state"),
              (lambda sv, x, y: sv.rect(x - 16, y - 7, 30, 14, fill="#fff", stroke=C["payload_edge"], rx=3),
               "Normal operating state")])
s.text(1395, 890, "STRATOS • Team Nothingburger • Rev A • proposed design", size=9, fill=C["muted"], anchor="end")
s.save(os.path.join(OUT, "STRATOS_Firmware_State_Diagram.svg"), os.path.join(OUT, "STRATOS_Firmware_State_Diagram.png"))
print("ok")
