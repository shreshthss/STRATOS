"""Static charts for the dossier (PNG), computed from the same design modules as the workbooks."""
import os, sys, math, datetime as dt
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "design"))
sys.path.insert(0, os.path.join(HERE, "..", "software"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import power as PW
import mass as MS
from registers import RISKS
from stratos_gs.radio import fspl_db

OUT = sys.argv[1]
for f in ("Inter", "DejaVu Sans"):
    if any(f in x.name for x in font_manager.fontManager.ttflist):
        plt.rcParams["font.family"] = f; break
INK, INK2, MUTED, GRID, SURF = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e1", "#fcfcfb"
S1, S2, S3 = "#2a78d6", "#eb6834", "#1baf7a"
plt.rcParams.update({"axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
                     "axes.titleweight": "bold", "axes.titlesize": 12, "axes.titlelocation": "left", "font.size": 10})


def style(ax):
    ax.grid(True, axis="x", color=GRID, lw=0.8); ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)


def save(fig, name):
    fig.savefig(os.path.join(OUT, name), dpi=200, facecolor="white", bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------- power contributors
c = PW.compute()
rows = sorted(c["rows"], key=lambda r: r["avg"])
labels = [r["ref"] + "  " + r["name"].split(",")[0].split("(")[0].strip()[:34] for r in rows]
fig, axs = plt.subplots(1, 2, figsize=(12, 4.2))
for ax, key, col, ttl in ((axs[0], "avg", S1, f"Average current at +3V3 (total {c['rail_avg']:.1f} mA)"),
                          (axs[1], "ip", S2, f"Peak current at +3V3 (all coincident: {c['rail_peak']:.0f} mA)")):
    vals = [r[key] for r in rows]
    ax.barh(labels, vals, color=col, height=0.62)
    for y, v in enumerate(vals):
        ax.text(v + max(vals) * 0.01, y, f"{v:.2f}" if v < 10 else f"{v:.0f}", va="center", fontsize=8.5, color=INK2)
    ax.set_title(ttl); ax.set_xlabel("mA"); style(ax)
axs[1].set_yticklabels([])
fig.text(0.01, -0.04, "Values marked ASSUMED in the power budget (board overhead, SD idle/write time, buzzer) must be measured. "
         "Source: STRATOS_Power_Budget.xlsx.", fontsize=8.5, color=MUTED)
fig.tight_layout()
save(fig, "chart_power.png")

# ---------------------------------------------------------------- mass breakdown
mrows, mtot = MS.budget()
groups = {"Battery + holder": 0, "Printed structure": 0, "Electronics (boards, modules)": 0, "Harness, connectors, passives": 0,
          "Fasteners, rods, yoke": 0, "Recovery system": 0}
for n, q, m, s in mrows:
    w = q * m
    if "18650" in n or "holder" in n.lower():
        groups["Battery + holder"] += w
    elif "PETG" in n:
        groups["Printed structure"] += w
    elif any(k in n for k in ("rod", "nuts", "screws", "yoke")):
        groups["Fasteners, rods, yoke"] += w
    elif "Parachute" in n:
        groups["Recovery system"] += w
    elif any(k in n for k in ("JST", "headers", "Passives", "Buzzer", "switch", "Carrier")):
        groups["Harness, connectors, passives"] += w
    else:
        groups["Electronics (boards, modules)"] += w
items = sorted(groups.items(), key=lambda t: t[1])
fig, ax = plt.subplots(figsize=(8.5, 3.6))
ax.barh([k for k, _ in items], [v for _, v in items], color=S1, height=0.6)
for y, (_, v) in enumerate(items):
    ax.text(v + 1.5, y, f"{v:.0f} g", va="center", fontsize=9, color=INK2)
ax.axvline(0, color=GRID)
ax.set_title(f"Estimated mass by group — total {mtot:.0f} g before ballast"); ax.set_xlabel("g"); style(ax)
fig.text(0.01, -0.05, "Most entries are estimates (EST) to be replaced by weighing; if ESA-style rules apply, ≈82 g of ballast brings the payload to the 325 g design target.",
         fontsize=8.5, color=MUTED)
fig.tight_layout(); save(fig, "chart_mass.png")

# ---------------------------------------------------------------- descent speed
D = 0.33
masses = [m / 1000 for m in range(220, 371, 5)]
fig, ax = plt.subplots(figsize=(8.5, 4.0))
ax.axhspan(8, 11, color="#e8f0f8", lw=0)
ax.text(0.372, 10.85, "ESA recommended 8–11 m/s", fontsize=8.5, color=INK2, ha="right", va="top")
for cd, col, dash in ((0.60, S2, (0, (5, 2))), (0.75, S1, "-"), (0.90, S3, (0, (1, 1.5)))):
    v = [MS.descent_speed(m, D, cd=cd) for m in masses]
    ax.plot(masses, v, color=col, lw=2, ls=dash)
    ax.text(masses[-1] + 0.002, v[-1], f"C_D {cd:.2f}", color=INK, fontsize=8.5, va="center")
ax.axvline(mtot / 1000, color=MUTED, lw=1, ls=":"); ax.text(mtot / 1000 + 0.002, 5.3, "unballasted\nestimate", fontsize=8, color=MUTED)
ax.axvline(0.325, color=MUTED, lw=1, ls=":"); ax.text(0.327, 5.3, "design\ntarget", fontsize=8, color=MUTED)
ax.set_xlim(0.22, 0.395); ax.set_ylim(5, 12)
ax.set_xlabel("payload mass (kg)"); ax.set_ylabel("steady descent speed (m/s)")
ax.set_title(f"Descent speed with a Ø{D:.2f} m flat circular canopy (sea-level air)")
ax.grid(True, color=GRID, lw=0.8)
for s in ("top", "right"):
    ax.spines[s].set_visible(False)
fig.tight_layout(); save(fig, "chart_descent.png")

# ---------------------------------------------------------------- link margin
d = [100 * 1.12 ** k for k in range(0, 48)]
d = [x for x in d if x <= 6000]
pr = [14 - 2 + 1 - 1 - fspl_db(x, 866e6) for x in d]
fig, ax = plt.subplots(figsize=(8.5, 4.0))
ax.plot([x / 1000 for x in d], [p + 105 for p in pr], color=S1, lw=2)
ax.plot([x / 1000 for x in d], [p + 123 for p in pr], color=S2, lw=2, ls=(0, (5, 2)))
ax.axhline(15, color=MUTED, lw=1, ls=":")
ax.text(5.9, 16, "15 dB planning fade margin", ha="right", fontsize=8.5, color=INK2)
ax.text(0.15, pr[2] + 105 + 2.5, "GFSK 38.4 kb/s (baseline; sensitivity −105 dBm ASSUMED)", fontsize=8.5, color=INK)
ax.text(0.15, pr[2] + 123 + 2.5, "LoRa SF7/125 kHz option (−123 dBm, datasheet)", fontsize=8.5, color=INK)
ax.set_xlabel("distance (km)"); ax.set_ylabel("free-space link margin (dB)")
ax.set_title("Link margin vs distance, 866 MHz, +14 dBm, −2 dBi payload / +1 dBi ground, 1 dB losses")
ax.set_xlim(0, 6); ax.grid(True, color=GRID, lw=0.8)
for s in ("top", "right"):
    ax.spines[s].set_visible(False)
fig.tight_layout(); save(fig, "chart_link.png")

# ---------------------------------------------------------------- storage
fig, ax = plt.subplots(figsize=(8.5, 3.2))
usable = 16e9 * 0.93
cases = [("one 4 h session (worst-case lines)", 144000 * 124 + 200), ("ten 4 h sessions", 10 * (144000 * 124 + 200)),
         ("72 h continuous", 2592000 * 124 + 200)]
for y, (lab, b) in enumerate(cases):
    pct = b / usable * 100
    ax.barh(y, pct, color=S1, height=0.55)
    ax.text(pct + 0.15, y, f"{b / 1e6:,.1f} MB = {pct:.2f} % of the usable 16 GB card", va="center", fontsize=9, color=INK2)
ax.set_yticks(range(len(cases))); ax.set_yticklabels([c[0] for c in cases])
ax.set_xlim(0, 4); ax.set_xlabel("% of usable card capacity"); style(ax)
ax.set_title("Onboard storage requirement vs card capacity")
fig.tight_layout(); save(fig, "chart_storage.png")

# ---------------------------------------------------------------- risk heat map
import numpy as np
grid = np.zeros((5, 5), int); names = {}
for rid, t, cause, eff, L, C, *_ in RISKS:
    grid[L - 1, C - 1] += 1; names.setdefault((L, C), []).append(rid)
fig, ax = plt.subplots(figsize=(7.2, 5.4))
cols = {"Low": "#d9ead3", "Medium": "#fce8b2", "High": "#f4c7c3", "Critical": "#e06666"}
for L in range(1, 6):
    for C in range(1, 6):
        sc = L * C
        band = "Critical" if sc >= 17 else "High" if sc >= 10 else "Medium" if sc >= 5 else "Low"
        ax.add_patch(plt.Rectangle((C - 0.5, L - 0.5), 1, 1, fc=cols[band], ec="white", lw=2))
        if (L, C) in names:
            ax.text(C, L, "\n".join(", ".join(names[(L, C)][i:i + 2]) for i in range(0, len(names[(L, C)]), 2)),
                    ha="center", va="center", fontsize=8.5, color=INK)
ax.set_xlim(0.5, 5.5); ax.set_ylim(0.5, 5.5)
ax.set_xticks(range(1, 6)); ax.set_yticks(range(1, 6))
ax.set_xticklabels(["1 Negligible", "2 Minor", "3 Moderate", "4 Major", "5 Severe"], fontsize=8.5)
ax.set_yticklabels(["1 Rare", "2 Unlikely", "3 Possible", "4 Likely", "5 Almost\ncertain"], fontsize=8.5)
ax.set_xlabel("Consequence"); ax.set_ylabel("Likelihood")
ax.set_title("Risk matrix before any test (risk IDs from the register)")
for s in ax.spines.values():
    s.set_visible(False)
fig.text(0.01, -0.02, "Bands: Low 1–4, Medium 5–9, High 10–16, Critical 17–25. No mitigation has yet been verified by a hardware test.",
         fontsize=8.5, color=MUTED)
fig.tight_layout(); save(fig, "chart_risk.png")

# ---------------------------------------------------------------- roadmap gantt
D_ = dt.date
M = [("M01 Design dossier Rev A (draft)", D_(2026, 10, 24), D_(2026, 10, 24), "done"),
     ("M02 Software prototype (simulation)", D_(2026, 10, 24), D_(2026, 10, 24), "done"),
     ("M03 Confirm entry route & deadline", D_(2026, 10, 24), D_(2026, 10, 27), "urgent"),
     ("M04 Design review, component freeze", D_(2026, 10, 26), D_(2026, 10, 28), "plan"),
     ("M05 Procurement", D_(2026, 10, 28), D_(2026, 11, 7), "plan"),
     ("M06 Mechanical fabrication", D_(2026, 10, 29), D_(2026, 11, 8), "plan"),
     ("M07 Firmware development", D_(2026, 10, 28), D_(2026, 11, 20), "plan"),
     ("M08 Sensor testing", D_(2026, 11, 3), D_(2026, 11, 8), "plan"),
     ("M09 Storage verification", D_(2026, 11, 5), D_(2026, 11, 11), "plan"),
     ("M10 Telemetry verification", D_(2026, 11, 8), D_(2026, 11, 16), "plan"),
     ("M11 System integration", D_(2026, 11, 17), D_(2026, 11, 22), "plan"),
     ("M12 Integrated ground testing", D_(2026, 11, 23), D_(2026, 11, 26), "plan"),
     ("M13 Recovery (drop) testing", D_(2026, 11, 18), D_(2026, 11, 26), "plan"),
     ("M14 Final validation & docs (Rev B)", D_(2026, 11, 27), D_(2026, 11, 30), "plan")]
fig, ax = plt.subplots(figsize=(11, 5.4))
base = D_(2026, 10, 19)
for i, (n, s, e, st) in enumerate(M):
    y = len(M) - i
    col = {"done": S3, "urgent": S2, "plan": S1}[st]
    ax.barh(y, (e - s).days + 1, left=(s - base).days, color=col, height=0.55, edgecolor="white")
    ax.text(-0.5, y, n, ha="right", va="center", fontsize=9, color=INK)
for x0, x1, lab in (((D_(2026, 11, 30) - base).days, (D_(2026, 12, 16) - base).days, "Finale window per portal\n30 Nov – 15 Dec (if shortlisted)"),):
    ax.axvspan(x0, x1, color="#f3f0fa", lw=0)
    ax.text(x0 + 0.5, len(M) + 0.6, lab, fontsize=8.5, color=INK2, va="top")
for d_, lab in ((D_(2026, 10, 24), "24 Oct (portal home page)"), (D_(2026, 11, 6), "6 Nov (portal timeline)")):
    x = (d_ - base).days + 0.5
    ax.axvline(x, color=S2, lw=1.2, ls=(0, (4, 2)))
    ax.text(x + 0.3, 0.35, lab, fontsize=8, color=INK2, rotation=0)
ticks = [base + dt.timedelta(days=7 * k) for k in range(9)]
ax.set_xticks([(t - base).days for t in ticks]); ax.set_xticklabels([t.strftime("%d %b") for t in ticks], fontsize=8.5)
ax.set_yticks([]); ax.set_xlim(0, (D_(2026, 12, 16) - base).days); ax.set_ylim(0, len(M) + 1)
ax.grid(True, axis="x", color=GRID, lw=0.8); ax.set_axisbelow(True)
for s in ("top", "right", "left"):
    ax.spines[s].set_visible(False)
ax.set_title("Proposed development roadmap (green = drafted, document/simulation only; orange = urgent; blue = planned)")
fig.tight_layout(); save(fig, "chart_roadmap.png")

# ---------------------------------------------------------------- cost by category
sys.path.insert(0, os.path.join(HERE, "..", "design"))
import bom as B
cats = {}
for row in B.BOM:
    iid, cat, ref, name, model, qty, price, cur, gst = row[:9]
    if price is None:
        continue
    unit = price * B.FX_USD_INR if cur == "USD" else (price * (1 + B.GST_RATE) if gst == "excl" else price)
    cats[cat] = cats.get(cat, 0) + unit * qty
cats["Allowances"] = sum(a[2] for a in B.ALLOWANCES)
it = sorted(cats.items(), key=lambda t: t[1])
fig, ax = plt.subplots(figsize=(8.5, 4.0))
ax.barh([k for k, _ in it], [v for _, v in it], color=S1, height=0.6)
for y, (_, v) in enumerate(it):
    ax.text(v + 60, y, f"₹{v:,.0f}", va="center", fontsize=9, color=INK2)
sub = sum(cats.values())
ax.set_title(f"Procurement cost by category, incl. GST — subtotal ₹{sub:,.0f} + 15 % contingency = ₹{sub * 1.15:,.0f}")
ax.set_xlabel("INR"); style(ax)
fig.text(0.01, -0.05, "Prices read 24 Oct 2026 (see BOM). Allowances are assumptions, not quotations; USD converted at an assumed ₹88/USD.",
         fontsize=8.5, color=MUTED)
fig.tight_layout(); save(fig, "chart_cost.png")
print("ok", round(sub), round(sub * 1.15))
