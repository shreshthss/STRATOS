"""Generate STRATOS_Data_Integrity_Demonstration.svg/.png from the SIMULATION output.

The values shown are read from the files written by stratos_gs.simulate
(seed 2026); nothing is typed in by hand.
"""
import csv, os, sys, struct
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "software"))
from svgkit import SVG, C, MONO
from stratos_gs.onboard_log import parse_lines
from stratos_gs.packet import crc16_ccitt_false

SIM = sys.argv[1]
OUT = sys.argv[2]
onb = {ln.pkt_seq: ln for ln in parse_lines(open(os.path.join(SIM, "LOG_0007.CSV"))) if ln.valid and ln.pkt_seq}
acc = {int(r["pkt_seq"]): r for r in csv.DictReader(open(os.path.join(SIM, "ground_accepted.csv")))}
rej = list(csv.DictReader(open(os.path.join(SIM, "ground_rejected.csv"))))
bad = bytes.fromhex(rej[0]["hex"])
stored = struct.unpack_from("<H", bad, 42)[0]
computed = crc16_ccitt_false(bad[:42])

W, H = 1500, 975
s = SVG(W, H, "STRATOS data-integrity demonstration (simulated)",
        "Onboard record vs received telemetry vs reconciliation, packets 1-10, synthetic data.")
s.text(30, 36, "STRATOS — How onboard logging and telemetry are reconciled", size=21, weight=700)
s.text(30, 60, "Packets 001–010 of a simulated session (session 7). Every value below was produced by the STRATOS software prototype "
       "running on synthetic records.", size=12.5, fill=C["muted"])

cols = [(30, 430, "A  Onboard record", "recovered microSD log (LOG_0007.CSV)", C["payload"], C["payload_edge"]),
        (500, 430, "B  Received telemetry", "ground-station log (accepted + rejected frames)", C["ground"], C["ground_edge"]),
        (970, 500, "C  Reconciliation result", "stratos_gs.reconcile output", "#F6F1FB", C["control"])]
top = 90
for x, w, t, sub, fill, edge in cols:
    s.rect(x, top, w, 745, fill=fill, stroke=edge, sw=1.5, rx=10)
    s.text(x + 16, top + 28, t, size=15, weight=700, fill=edge)
    s.text(x + 16, top + 47, sub, size=11, fill=C["muted"])

row0, rh = top + 108, 54
s.text(46, top + 76, "pkt   rec_seq   t_ms      pressure     tx", size=10.5, family=MONO, fill=C["muted"])
s.text(516, top + 76, "pkt   rx time (sim)   pressure   check", size=10.5, family=MONO, fill=C["muted"])
s.text(986, top + 76, "pkt   classification", size=10.5, family=MONO, fill=C["muted"])

for i, k in enumerate(range(1, 11)):
    y = row0 + i * rh
    r = onb[k].record
    # Column A
    s.rect(42, y - 22, 406, 44, fill="#FFFFFF", stroke=C["grid"], rx=6)
    s.text(54, y + 5, f"{k:03d}   {r.rec_seq:>5}   {r.t_ms:>6}   {r.press_dPa / 1000:7.2f} hPa   {onb[k].tx}",
           size=12, family=MONO)
    # Column B
    if k in acc:
        g = acc[k]
        s.rect(512, y - 22, 406, 44, fill="#FFFFFF", stroke=C["grid"], rx=6)
        s.text(524, y + 5, f"{k:03d}   {g['rx_utc'][11:23]}   {int(g['press_dPa']) / 1000:7.2f}", size=12, family=MONO)
        s.text(900, y + 5, "CRC OK", size=11, weight=650, fill=C["ok"], anchor="end")
    elif k == 9:
        s.rect(512, y - 22, 406, 44, fill=C["error_fill"], stroke=C["error"], rx=6, dash="5 3")
        s.text(524, y - 3, f"???   frame received, rejected: CRC mismatch", size=11.5, family=MONO, fill=C["error"])
        s.text(524, y + 14, f"      stored 0x{stored:04X} ≠ computed 0x{computed:04X} — fields untrusted",
               size=10.5, family=MONO, fill=C["error"])
    else:
        s.rect(512, y - 22, 406, 44, fill="#FFFFFF", stroke=C["error"], rx=6, dash="5 3")
        s.text(524, y + 5, f"---   no frame received", size=12, family=MONO, fill=C["error"])
        s.text(900, y + 5, "GAP", size=11, weight=700, fill=C["error"], anchor="end")
    # Column C
    if k in acc:
        s.rect(982, y - 22, 476, 44, fill="#FFFFFF", stroke=C["grid"], rx=6)
        s.text(994, y + 5, f"{k:03d}   MATCH", size=12, family=MONO, fill=C["ok"], weight=650)
        s.text(1446, y + 5, "all 13 compared fields identical", size=10.5, fill=C["muted"], anchor="end")
    else:
        s.rect(982, y - 22, 476, 44, fill=C["hl"], stroke=C["warn"], rx=6)
        cls = "MISSING – corrupted frame observed" if k == 9 else "MISSING – no frame observed"
        s.text(994, y - 3, f"{k:03d}   {cls}", size=11.5, family=MONO, fill=C["error"], weight=650)
        s.text(994, y + 14, f"      record recovered from onboard log (rec_seq {r.rec_seq})", size=10.5,
               family=MONO, fill=C["ink"])
    if k not in acc:
        s.path([(448, y), (512, y)], "error")
        s.path([(918, y), (982, y)], "plain")

# summary
n_acc = sum(1 for k in range(1, 11) if k in acc)
sy = top + 668
s.rect(982, sy - 26, 476, 98, fill="#FFFFFF", stroke=C["control"], rx=8)
s.lines(996, sy - 8, [f"Expected (TX complete logged onboard): 10",
                      f"Accepted at ground: {n_acc}    Rejected (CRC): 1",
                      f"Missing sequence numbers: 2  (006, 009)",
                      f"Matching records: {n_acc}    Unresolved discrepancies: 0"], size=11.5, lh=19, family=MONO)
s.lines(46, sy - 8, ["Every record carries session, rec_seq and t_ms.",
                     "Every 10th record is also sent; its pkt_seq and",
                     "the radio outcome (T = sent, F = failed) are",
                     "written into the same CSV line, protected by a",
                     "per-line CRC."], size=11.5, lh=19)
s.lines(516, sy - 8, ["The receiver keeps only frames whose CRC-16",
                      "verifies. A sequence jump (005 → 007) is logged",
                      "as a gap; a CRC failure is logged separately,",
                      "with its raw bytes, because its sequence number",
                      "cannot be trusted."], size=11.5, lh=19)

s.rect(30, 852, 1428, 96, fill=C["hl"], stroke=C["warn"], rx=8)
s.text(48, 880, "Illustrative example using synthetic records; hardware validation pending.", size=15, weight=700, fill="#7A4A00")
s.lines(48, 904, [
    "Generated by stratos_gs.simulate (seed 2026) with faults injected on purpose: packet 006 dropped, one bit flipped in packet 009. "
    "Timestamps use the synthetic base date 2000-01-01.",
    "This is a software demonstration only. It is not a STRATOS sensor, radio or flight test, and no STRATOS hardware has been built."],
    size=11.5, lh=19)
s.save(os.path.join(OUT, "STRATOS_Data_Integrity_Demonstration.svg"),
       os.path.join(OUT, "STRATOS_Data_Integrity_Demonstration.png"))
print("ok", stored, computed)
