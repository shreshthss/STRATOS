/*
 * STRATOS telemetry packet and onboard-log line formatting (format v1).
 * See stratos_packet.h. STATUS: host-tested only; not yet run on ESP32.
 */
#include "stratos_packet.h"
#include <stdio.h>
#include <string.h>

uint16_t stratos_crc16(const uint8_t *data, size_t len)
{
    /* CRC-16/CCITT-FALSE: poly 0x1021, init 0xFFFF, no reflection, xorout 0 */
    uint16_t crc = 0xFFFFu;
    for (size_t i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i] << 8;
        for (int b = 0; b < 8; b++) {
            crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
        }
    }
    return crc;
}

static uint8_t *put_u16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); return p + 2; }
static uint8_t *put_u32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
    return p + 4;
}

uint16_t stratos_encode_packet(const stratos_record_t *r, uint32_t pkt_seq, uint8_t *out)
{
    uint8_t *p = out;
    *p++ = 'S'; *p++ = 'T';
    *p++ = STRATOS_FMT_VERSION;
    *p++ = STRATOS_PKT_TELEMETRY;
    p = put_u16(p, r->session);
    p = put_u32(p, pkt_seq);
    p = put_u32(p, r->rec_seq);
    p = put_u32(p, r->t_ms);
    p = put_u16(p, (uint16_t)r->temp_cC);
    p = put_u16(p, r->rh_cpct);
    p = put_u32(p, r->press_dPa);
    for (int i = 0; i < 3; i++) p = put_u16(p, (uint16_t)r->acc_mg[i]);
    for (int i = 0; i < 3; i++) p = put_u16(p, (uint16_t)r->gyr_ddps[i]);
    p = put_u16(p, r->vbat_mV);
    p = put_u16(p, r->status);
    uint16_t crc = stratos_crc16(out, STRATOS_PKT_CRC_LEN);
    put_u16(p, crc);
    return crc;
}

/* Append helpers: write a value or an empty field for a sentinel. */
static int fmt_i16(char *b, size_t n, int16_t v) { return v == STRATOS_SENT_I16 ? snprintf(b, n, ",") : snprintf(b, n, ",%d", (int)v); }
static int fmt_u16(char *b, size_t n, uint16_t v) { return v == STRATOS_SENT_U16 ? snprintf(b, n, ",") : snprintf(b, n, ",%u", (unsigned)v); }
static int fmt_u32(char *b, size_t n, uint32_t v) { return v == STRATOS_SENT_U32 ? snprintf(b, n, ",") : snprintf(b, n, ",%lu", (unsigned long)v); }

size_t stratos_format_log_line(const stratos_record_t *r, uint32_t pkt_seq, char tx,
                               char *buf, size_t buflen)
{
    size_t len = 0;
    int w;
#define APPEND(expr) do { w = (expr); if (w < 0 || (size_t)w >= buflen - len) return 0; len += (size_t)w; } while (0)
    APPEND(snprintf(buf + len, buflen - len, "%u,%lu,%lu", (unsigned)r->session,
                    (unsigned long)r->rec_seq, (unsigned long)r->t_ms));
    APPEND(fmt_i16(buf + len, buflen - len, r->temp_cC));
    APPEND(fmt_u16(buf + len, buflen - len, r->rh_cpct));
    APPEND(fmt_u32(buf + len, buflen - len, r->press_dPa));
    for (int i = 0; i < 3; i++) APPEND(fmt_i16(buf + len, buflen - len, r->acc_mg[i]));
    for (int i = 0; i < 3; i++) APPEND(fmt_i16(buf + len, buflen - len, r->gyr_ddps[i]));
    APPEND(fmt_u16(buf + len, buflen - len, r->vbat_mV));
    APPEND(snprintf(buf + len, buflen - len, ",%04X", (unsigned)r->status));
    if (pkt_seq) APPEND(snprintf(buf + len, buflen - len, ",%lu", (unsigned long)pkt_seq));
    else APPEND(snprintf(buf + len, buflen - len, ","));
    if (tx) APPEND(snprintf(buf + len, buflen - len, ",%c", tx));
    else APPEND(snprintf(buf + len, buflen - len, ","));
    uint16_t lcrc = stratos_crc16((const uint8_t *)buf, len);
    APPEND(snprintf(buf + len, buflen - len, ",%04X", (unsigned)lcrc));
#undef APPEND
    return len;
}
