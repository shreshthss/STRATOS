/*
 * STRATOS telemetry packet and onboard-log line formatting (format v1).
 *
 * Portable C99, no dynamic memory, explicit little-endian packing so the
 * byte layout does not depend on compiler struct padding or CPU endianness.
 * Mirrors software/stratos_gs/packet.py and onboard_log.py exactly; the host
 * test (test_packet_host.c) checks this code against golden vectors produced
 * by the Python implementation.
 *
 * STATUS: host-compiled and tested against the Python reference. Not yet
 * built for or run on ESP32 hardware.
 */
#ifndef STRATOS_PACKET_H
#define STRATOS_PACKET_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define STRATOS_PKT_LEN        44u
#define STRATOS_PKT_CRC_LEN    42u
#define STRATOS_FMT_VERSION    1u
#define STRATOS_PKT_TELEMETRY  0x01u

#define STRATOS_SENT_I16  ((int16_t)-32768)
#define STRATOS_SENT_U16  ((uint16_t)0xFFFFu)
#define STRATOS_SENT_U32  ((uint32_t)0xFFFFFFFFu)

/* status bit field */
#define ST_BME_PRESENT   (1u << 0)
#define ST_IMU_PRESENT   (1u << 1)
#define ST_SD_OK         (1u << 2)
#define ST_T_INVALID     (1u << 3)
#define ST_RH_INVALID    (1u << 4)
#define ST_P_INVALID     (1u << 5)
#define ST_ACC_INVALID   (1u << 6)
#define ST_GYR_INVALID   (1u << 7)
#define ST_SD_WRITE_ERR  (1u << 8)
#define ST_LOG_OVERFLOW  (1u << 9)
#define ST_VBAT_LOW      (1u << 10)
#define ST_RADIO_ERR     (1u << 11)
#define ST_CYCLE_OVERRUN (1u << 12)

typedef struct {
    uint16_t session;
    uint32_t rec_seq;
    uint32_t t_ms;
    int16_t  temp_cC;     /* 0.01 degC */
    uint16_t rh_cpct;     /* 0.01 %RH  */
    uint32_t press_dPa;   /* 0.1 Pa    */
    int16_t  acc_mg[3];   /* mg        */
    int16_t  gyr_ddps[3]; /* 0.1 deg/s */
    uint16_t vbat_mV;     /* mV        */
    uint16_t status;
} stratos_record_t;

/* tx column values in the onboard log */
#define STRATOS_TX_NONE '\0'
#define STRATOS_TX_DONE 'T'
#define STRATOS_TX_FAIL 'F'

uint16_t stratos_crc16(const uint8_t *data, size_t len);

/* Encode a record as a telemetry packet. out must hold STRATOS_PKT_LEN bytes.
 * Returns the CRC written into bytes 42..43. */
uint16_t stratos_encode_packet(const stratos_record_t *r, uint32_t pkt_seq, uint8_t *out);

/* Format one onboard CSV line (without line terminator) including its line
 * CRC. pkt_seq == 0 means "not scheduled for transmission".
 * Returns number of characters written, or 0 if buf is too small.
 * Worst case length is 122 characters; use a buffer of at least 128 bytes. */
size_t stratos_format_log_line(const stratos_record_t *r, uint32_t pkt_seq, char tx,
                               char *buf, size_t buflen);

#ifdef __cplusplus
}
#endif
#endif /* STRATOS_PACKET_H */
