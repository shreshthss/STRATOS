/*
 * STRATOS payload firmware — DRAFT (Rev A, 24 Oct 2026)
 *
 * STATUS: NOT COMPILED AND NOT RUN ON HARDWARE. This sketch shows the intended
 * structure (state machine, scheduling, error handling). The packet and log-line
 * code it calls (../common/stratos_packet.c) IS host-compiled and checked
 * byte-for-byte against the Python ground-station software.
 *
 * Target: ESP32-DevKitC V4 (ESP32-WROOM-32E), Arduino-ESP32 core.
 * Libraries (to be pinned when first built): Adafruit BME280, Adafruit LSM6DS,
 * RadioLib (SX1276 FSK), SD (ESP32 core), Preferences (ESP32 core).
 * Copy common/stratos_packet.{h,c} into this sketch folder before building.
 *
 * Pin map: see STRATOS_Pin_Mapping.csv (generated from design/baseline.py).
 */
#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>
#include <SD.h>
#include <Preferences.h>
#include <WiFi.h>
#include <Adafruit_BME280.h>
#include <Adafruit_LSM6DSOX.h>
#include <RadioLib.h>
extern "C" {
#include "stratos_packet.h"
}

// ---------------- pins (baseline.PINS) ----------------
#define PIN_SDA 21
#define PIN_SCL 22
#define PIN_IMU_INT1 39
#define PIN_SD_SCK 18
#define PIN_SD_MISO 19
#define PIN_SD_MOSI 23
#define PIN_SD_CS 5
#define PIN_RADIO_SCK 14
#define PIN_RADIO_MISO 27
#define PIN_RADIO_MOSI 13
#define PIN_RADIO_NSS 33
#define PIN_RADIO_RST 32
#define PIN_RADIO_DIO0 26
#define PIN_RADIO_DIO1 35
#define PIN_VBAT 34
#define PIN_BUZZER 4
#define PIN_LED 25

// ---------------- schedule (baseline) ----------------
static const uint32_t RECORD_PERIOD_MS = 100;  // 10 Hz records
static const uint32_t TX_EVERY_N = 10;         // 1 Hz telemetry (rec_seq % 10 == 1)
static const uint32_t FLUSH_SLOT = 6;          // flush when rec_seq % 10 == 6
static const uint32_t TX_TIMEOUT_MS = 50;      // ≈11.5 ms on air at 38.4 kb/s
static const uint16_t VBAT_LOW_MV = 3400;
static const uint16_t VBAT_SHUTDOWN_MV = 3300;
static const char *FW_VERSION = "draft-0.1";

// ---------------- radio configuration (dossier §4.6) ----------------
static const float RF_FREQ_MHZ = 866.0;
static const float RF_BITRATE_KBPS = 38.4;
static const float RF_FDEV_KHZ = 40.0;
static const float RF_RXBW_KHZ = 125.0;  // receiver only
static const int8_t RF_POWER_DBM = 14;
static const uint16_t RF_PREAMBLE_BITS = 40;  // 5 bytes
static uint8_t RF_SYNC[4] = {0x53, 0x54, 0x52, 0x41};  // "STRA"

SPIClass spiSD(VSPI);
SPIClass spiRadio(HSPI);
SX1276 radio = new Module(PIN_RADIO_NSS, PIN_RADIO_DIO0, PIN_RADIO_RST, PIN_RADIO_DIO1, spiRadio);
Adafruit_BME280 bme;
Adafruit_LSM6DSOX imu;
Preferences prefs;
File logFile;

// ---------------- state ----------------
enum State { ST_INIT, ST_SELF_TEST, ST_FAULT_RETRY, ST_READY, ST_ACQUIRE, ST_BUFFER, ST_PREPARE, ST_TRANSMIT,
             ST_FLUSH, ST_SD_RECOVERY, ST_RADIO_RECOVERY, ST_SAFE_SHUTDOWN };
static State state = ST_INIT;
static uint16_t session = 0;
static uint32_t recSeq = 0, pktSeq = 0;
static bool bmeOk = false, imuOk = false, sdOk = false, radioOk = false;
static uint16_t stickyFlags = 0;          // SD_WRITE_ERR, LOG_OVERFLOW, RADIO_ERR carried to the next packet
static uint32_t nextTick = 0, lastReinit = 0, lastRemount = 0;
static uint8_t lowBattCount = 0;

// ring buffer of binary records; lines are formatted at flush time so the
// radio outcome (tx = 'T' / 'F') is known when the line is written
struct BufEntry { stratos_record_t r; uint32_t pkt; char tx; };
static const int RING = 50;
static BufEntry ring[RING];
static int ringHead = 0, ringCount = 0;

static volatile bool txDoneFlag = false;
static bool txPending = false;
static uint32_t txStartMs = 0;
static int txRingIndex = -1;
static uint8_t frame[STRATOS_PKT_LEN];

#if defined(ESP8266) || defined(ESP32)
ICACHE_RAM_ATTR
#endif
void onPacketSent(void) { txDoneFlag = true; }

// ---------------- helpers ----------------
static void beep(int n, int ms) {
  for (int i = 0; i < n; i++) { digitalWrite(PIN_BUZZER, HIGH); delay(ms); digitalWrite(PIN_BUZZER, LOW); delay(ms); }
}

static bool initRadio() {
  int st = radio.beginFSK(RF_FREQ_MHZ, RF_BITRATE_KBPS, RF_FDEV_KHZ, RF_RXBW_KHZ, RF_POWER_DBM, RF_PREAMBLE_BITS, false);
  if (st != RADIOLIB_ERR_NONE) return false;
  radio.setSyncWord(RF_SYNC, sizeof(RF_SYNC));
  radio.fixedPacketLengthMode(STRATOS_PKT_LEN);
  radio.setCRC(true);
  radio.setDataShaping(RADIOLIB_SHAPING_0_5);
  radio.setEncoding(RADIOLIB_ENCODING_WHITENING);
  radio.setPacketSentAction(onPacketSent);
  return true;
}

static bool openLog() {
  if (!SD.begin(PIN_SD_CS, spiSD, 4000000)) return false;
  char name[20];
  snprintf(name, sizeof name, "/LOG_%04u.CSV", (unsigned)session);
  logFile = SD.open(name, FILE_APPEND);
  if (!logFile) return false;
  if (logFile.size() == 0) {
    logFile.printf("# STRATOS onboard log v1\r\n# session=%u fw=%s record_period_ms=%lu tx_every_n=%lu\r\n",
                   (unsigned)session, FW_VERSION, (unsigned long)RECORD_PERIOD_MS, (unsigned long)TX_EVERY_N);
    logFile.print("session,rec_seq,t_ms,temp_cC,rh_cpct,press_dPa,ax_mg,ay_mg,az_mg,gx_ddps,gy_ddps,gz_ddps,vbat_mV,status,pkt_seq,tx,lcrc\r\n");
    logFile.flush();
  }
  return true;
}

static uint16_t readVbat() {
  uint32_t mv = analogReadMilliVolts(PIN_VBAT) * 2;   // 100k/100k divider; calibrate against a multimeter
  return (uint16_t)mv;
}

static void acquire(stratos_record_t &r) {
  r.session = session;
  r.rec_seq = ++recSeq;
  r.t_ms = millis();
  uint16_t st = 0;
  if (bmeOk) st |= ST_BME_PRESENT;
  if (imuOk) st |= ST_IMU_PRESENT;
  if (sdOk) st |= ST_SD_OK;
  // BME280 with plausibility limits (absent value → sentinel + flag, never 0)
  r.temp_cC = STRATOS_SENT_I16; r.rh_cpct = STRATOS_SENT_U16; r.press_dPa = STRATOS_SENT_U32;
  if (bmeOk) {
    float t = bme.readTemperature(), h = bme.readHumidity(), p = bme.readPressure();
    if (!isnan(t) && t > -40 && t < 85) r.temp_cC = (int16_t)lroundf(t * 100); else st |= ST_T_INVALID;
    if (!isnan(h) && h >= 0 && h <= 100) r.rh_cpct = (uint16_t)lroundf(h * 100); else st |= ST_RH_INVALID;
    if (!isnan(p) && p > 30000 && p < 110000) r.press_dPa = (uint32_t)lroundf(p * 10); else st |= ST_P_INVALID;
  } else {
    st |= ST_T_INVALID | ST_RH_INVALID | ST_P_INVALID;
  }
  for (int i = 0; i < 3; i++) { r.acc_mg[i] = STRATOS_SENT_I16; r.gyr_ddps[i] = STRATOS_SENT_I16; }
  sensors_event_t a, g, temp;
  if (imuOk && imu.getEvent(&a, &g, &temp)) {
    r.acc_mg[0] = (int16_t)lroundf(a.acceleration.x / 9.80665f * 1000);
    r.acc_mg[1] = (int16_t)lroundf(a.acceleration.y / 9.80665f * 1000);
    r.acc_mg[2] = (int16_t)lroundf(a.acceleration.z / 9.80665f * 1000);
    r.gyr_ddps[0] = (int16_t)lroundf(g.gyro.x * 57.29578f * 10);
    r.gyr_ddps[1] = (int16_t)lroundf(g.gyro.y * 57.29578f * 10);
    r.gyr_ddps[2] = (int16_t)lroundf(g.gyro.z * 57.29578f * 10);
  } else {
    st |= ST_ACC_INVALID | ST_GYR_INVALID;
  }
  r.vbat_mV = readVbat();
  if (r.vbat_mV < VBAT_LOW_MV) st |= ST_VBAT_LOW;
  r.status = st;
}

static int pushRecord(const stratos_record_t &r, uint32_t pkt) {
  if (ringCount == RING) {            // buffer full: record is lost from the log, flag the next one
    stickyFlags |= ST_LOG_OVERFLOW;
    return -1;
  }
  int idx = (ringHead + ringCount) % RING;
  ring[idx].r = r; ring[idx].pkt = pkt; ring[idx].tx = pkt ? 'P' : STRATOS_TX_NONE;   // 'P' = pending outcome
  ringCount++;
  return idx;
}

static bool flushLog() {
  if (!sdOk) return false;
  char line[128];
  bool ok = true;
  while (ringCount > 0) {
    BufEntry &e = ring[ringHead];
    if (e.tx == 'P') break;           // radio outcome not yet known: leave for next flush
    size_t n = stratos_format_log_line(&e.r, e.pkt, e.tx, line, sizeof line);
    if (n == 0 || logFile.write((const uint8_t *)line, n) != n || logFile.write((const uint8_t *)"\r\n", 2) != 2) { ok = false; break; }
    ringHead = (ringHead + 1) % RING; ringCount--;
  }
  logFile.flush();
  return ok;
}

// ---------------- setup / loop ----------------
void setup() {
  setCpuFrequencyMhz(80);          // power budget assumes 80 MHz (modem-sleep figures, dossier §6.1)
  WiFi.mode(WIFI_OFF);             // Wi-Fi and Bluetooth are never used on the payload
  btStop();
  pinMode(PIN_BUZZER, OUTPUT); pinMode(PIN_LED, OUTPUT); pinMode(PIN_IMU_INT1, INPUT);
  Serial.begin(115200);
  analogSetPinAttenuation(PIN_VBAT, ADC_11db);
  state = ST_INIT;
}

void loop() {
  static stratos_record_t rec;
  static int recIdx = -1;
  switch (state) {
    case ST_INIT:
      prefs.begin("stratos", false);
      session = prefs.getUShort("boot", 0) + 1;      // new session at every power-up/reset
      prefs.putUShort("boot", session);
      prefs.end();
      state = ST_SELF_TEST;
      break;

    case ST_SELF_TEST:
      Wire.begin(PIN_SDA, PIN_SCL, 400000);
      bmeOk = bme.begin(0x76, &Wire) || bme.begin(0x77, &Wire);   // begin() checks chip ID 0x60
      imuOk = imu.begin_I2C(0x6A, &Wire);
      if (imuOk) { imu.setAccelRange(LSM6DS_ACCEL_RANGE_16_G); imu.setGyroRange(LSM6DS_GYRO_RANGE_2000_DPS);
                   imu.setAccelDataRate(LSM6DS_RATE_104_HZ); imu.setGyroDataRate(LSM6DS_RATE_104_HZ); }
      spiSD.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
      sdOk = openLog();
      spiRadio.begin(PIN_RADIO_SCK, PIN_RADIO_MISO, PIN_RADIO_MOSI, PIN_RADIO_NSS);
      radioOk = initRadio();
      if (!sdOk && !radioOk) { state = ST_FAULT_RETRY; break; }
      beep(bmeOk + imuOk + sdOk + radioOk, 80);       // 4 beeps = all subsystems present
      nextTick = millis();
      state = ST_READY;
      break;

    case ST_FAULT_RETRY:
      beep(3, 300);
      delay(5000);
      state = ST_SELF_TEST;
      break;

    case ST_READY: {
      uint32_t now = millis();
      // radio outcome of an in-flight transmission
      if (txPending && (txDoneFlag || now - txStartMs > TX_TIMEOUT_MS)) {
        bool ok = txDoneFlag;
        if (ok) radio.finishTransmit();
        if (txRingIndex >= 0) ring[txRingIndex].tx = ok ? STRATOS_TX_DONE : STRATOS_TX_FAIL;
        txPending = false; txDoneFlag = false;
        if (!ok) { stickyFlags |= ST_RADIO_ERR; state = ST_RADIO_RECOVERY; break; }
      }
      if ((int32_t)(now - nextTick) >= 0) {
        if (now - nextTick > RECORD_PERIOD_MS) stickyFlags |= ST_CYCLE_OVERRUN;
        nextTick += RECORD_PERIOD_MS;
        state = ST_ACQUIRE;
      } else if (!bmeOk || !imuOk) {
        if (now - lastReinit > 10000) {               // periodic re-initialisation of absent sensors
          lastReinit = now;
          if (!bmeOk) bmeOk = bme.begin(0x76, &Wire) || bme.begin(0x77, &Wire);
          if (!imuOk) imuOk = imu.begin_I2C(0x6A, &Wire);
        }
      }
      break;
    }

    case ST_ACQUIRE:
      acquire(rec);
      if (rec.vbat_mV < VBAT_SHUTDOWN_MV) { if (++lowBattCount >= 10) { state = ST_SAFE_SHUTDOWN; break; } }
      else lowBattCount = 0;
      state = ST_BUFFER;
      break;

    case ST_BUFFER: {
      bool scheduled = ((rec.rec_seq - 1) % TX_EVERY_N) == 0 && radioOk && !txPending;
      rec.status |= stickyFlags;
      if (scheduled) stickyFlags = 0;                  // sticky flags are reported in the next packet
      recIdx = pushRecord(rec, scheduled ? pktSeq + 1 : 0);
      if (scheduled && recIdx >= 0) state = ST_PREPARE;
      else if ((rec.rec_seq % TX_EVERY_N) == FLUSH_SLOT) state = ST_FLUSH;
      else state = ST_READY;
      break;
    }

    case ST_PREPARE:
      pktSeq++;
      stratos_encode_packet(&rec, pktSeq, frame);
      state = ST_TRANSMIT;
      break;

    case ST_TRANSMIT:
      txDoneFlag = false;
      if (radio.startTransmit(frame, STRATOS_PKT_LEN) == RADIOLIB_ERR_NONE) {
        txPending = true; txStartMs = millis(); txRingIndex = recIdx;
      } else {
        ring[recIdx].tx = STRATOS_TX_FAIL; stickyFlags |= ST_RADIO_ERR;
      }
      state = ST_READY;
      break;

    case ST_FLUSH:
      if (!flushLog()) { stickyFlags |= ST_SD_WRITE_ERR; sdOk = false; state = ST_SD_RECOVERY; }
      else state = ST_READY;
      digitalWrite(PIN_LED, !digitalRead(PIN_LED));     // heartbeat
      break;

    case ST_SD_RECOVERY:
      if (millis() - lastRemount > 5000) {
        lastRemount = millis();
        SD.end();
        sdOk = openLog();                              // records stay in the ring buffer meanwhile
      }
      state = ST_READY;
      break;

    case ST_RADIO_RECOVERY:
      radioOk = initRadio();                           // RadioLib pulses RST during begin
      state = ST_READY;
      break;

    case ST_SAFE_SHUTDOWN:
      flushLog();
      if (logFile) logFile.close();
      radio.sleep();
      beep(1, 1000);
      esp_deep_sleep_start();                          // stays asleep until power is cycled
      break;
  }
}
