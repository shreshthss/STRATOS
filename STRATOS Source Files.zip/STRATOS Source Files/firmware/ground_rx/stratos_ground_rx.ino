/*
 * STRATOS ground receiver firmware — DRAFT (Rev A, 24 Oct 2026)
 *
 * STATUS: NOT COMPILED AND NOT RUN ON HARDWARE.
 *
 * Receives STRATOS telemetry frames (SX1276 GFSK, same settings as the payload) and
 * forwards every frame to the laptop over USB serial as one line:
 *
 *     RX,<receiver_ms>,<rssi_dBm>,nan,<length>,<HEX bytes>
 *
 * SNR is "nan" because the SX1276 reports SNR only in LoRa mode. The laptop software
 * (stratos_gs.ground_station --serial) adds the UTC reception time, checks length,
 * CRC-16 and header, tracks sequence numbers and writes the ground logs. This firmware
 * deliberately does NOT decode or filter: frames the radio flags as CRC-failed are
 * still forwarded so the ground software can log them as rejected frames.
 *
 * Hardware: ESP32-DevKitC V4 + Ra-01H wired exactly like the payload radio
 * (RADIO_SCK IO14, RADIO_MISO IO27, RADIO_MOSI IO13, RADIO_NSS IO33,
 *  RADIO_RST IO32, RADIO_DIO0 IO26, RADIO_DIO1 IO35), powered from USB.
 * Library: RadioLib (pin the version when first built).
 */
#include <Arduino.h>
#include <SPI.h>
#include <RadioLib.h>

#define PIN_RADIO_SCK 14
#define PIN_RADIO_MISO 27
#define PIN_RADIO_MOSI 13
#define PIN_RADIO_NSS 33
#define PIN_RADIO_RST 32
#define PIN_RADIO_DIO0 26
#define PIN_RADIO_DIO1 35
#define PIN_LED 25

static const uint8_t PKT_LEN = 44;
static const float RF_FREQ_MHZ = 866.0;
static const float RF_BITRATE_KBPS = 38.4;
static const float RF_FDEV_KHZ = 40.0;
static const float RF_RXBW_KHZ = 125.0;
static const int8_t RF_POWER_DBM = 14;          // receiver does not transmit
static const uint16_t RF_PREAMBLE_BITS = 40;    // 5 bytes
static uint8_t RF_SYNC[4] = {0x53, 0x54, 0x52, 0x41};  // "STRA"

SPIClass spiRadio(HSPI);
SX1276 radio = new Module(PIN_RADIO_NSS, PIN_RADIO_DIO0, PIN_RADIO_RST, PIN_RADIO_DIO1, spiRadio);

static volatile bool rxFlag = false;
#if defined(ESP8266) || defined(ESP32)
ICACHE_RAM_ATTR
#endif
void onPacketReceived(void) { rxFlag = true; }

void setup() {
  Serial.begin(115200);
  pinMode(PIN_LED, OUTPUT);
  spiRadio.begin(PIN_RADIO_SCK, PIN_RADIO_MISO, PIN_RADIO_MOSI, PIN_RADIO_NSS);
  int st = radio.beginFSK(RF_FREQ_MHZ, RF_BITRATE_KBPS, RF_FDEV_KHZ, RF_RXBW_KHZ, RF_POWER_DBM, RF_PREAMBLE_BITS, false);
  if (st != RADIOLIB_ERR_NONE) {
    Serial.printf("# RADIO_INIT_FAILED,%d\n", st);   // '#' lines are ignored by the ground software
    while (true) { digitalWrite(PIN_LED, !digitalRead(PIN_LED)); delay(100); }
  }
  radio.setSyncWord(RF_SYNC, sizeof(RF_SYNC));
  radio.fixedPacketLengthMode(PKT_LEN);
  radio.setCRC(true);
  radio.setDataShaping(RADIOLIB_SHAPING_0_5);
  radio.setEncoding(RADIOLIB_ENCODING_WHITENING);
  radio.setPacketReceivedAction(onPacketReceived);
  radio.startReceive();
  Serial.println("# STRATOS ground receiver draft-0.1 ready (GFSK 866.0 MHz, 38.4 kb/s)");
}

void loop() {
  if (!rxFlag) return;
  rxFlag = false;
  uint8_t buf[PKT_LEN];
  int st = radio.readData(buf, PKT_LEN);
  uint32_t ms = millis();
  if (st == RADIOLIB_ERR_NONE || st == RADIOLIB_ERR_CRC_MISMATCH) {
    // forward everything; the ground software decides what is valid
    Serial.printf("RX,%lu,%.0f,nan,%u,", (unsigned long)ms, radio.getRSSI(), (unsigned)PKT_LEN);
    for (uint8_t i = 0; i < PKT_LEN; i++) Serial.printf("%02X", buf[i]);
    Serial.println();
    digitalWrite(PIN_LED, !digitalRead(PIN_LED));
  } else {
    Serial.printf("# RX_ERROR,%lu,%d\n", (unsigned long)ms, st);
  }
  radio.startReceive();
}
