"""Produce the same vectors as test_packet_host.c using the Python reference."""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "software"))
from stratos_gs.packet import Record, Packet, crc16_ccitt_false, SENT_I16 as I, SENT_U16 as U, SENT_U32 as L
from stratos_gs.onboard_log import format_line

recs = [Record(7, 1, 412, 2348, 6021, 8455812, 3, -7, 1004, -2, 4, 1, 3951, 0x0007),
        Record(7, 801, 80412, 2512, U, 8730203, 150, 90, 1012, -120, 88, 351, 3920, 0x0017),
        Record(65535, 4294967294, 4294967295, -32767, 0, 0, -32767, 32767, 0, 0, 0, 0, 0, 0x1FFF),
        Record(7, 1501, 150412, I, U, L, I, I, I, I, I, I, U, 0x0FF8)]
pseq = [1, 81, 4294967295, 0]
tx = ["T", "T", "F", ""]
print(f"CRCCHECK {crc16_ccitt_false(b'123456789'):04X}")
for r, p, t in zip(recs, pseq, tx):
    print("PKT " + Packet.from_record(r, p if p else 1).encode().hex().upper())
    line = format_line(r, p if p else None, t)
    print(f"LOG {line} ({len(line)})")
print("SMALLBUF 0")
