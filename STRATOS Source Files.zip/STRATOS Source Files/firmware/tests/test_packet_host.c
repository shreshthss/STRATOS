/* Host test: prints packets and log lines for fixed records so they can be
 * compared byte-for-byte with the Python reference (golden_vectors.py). */
#include <stdio.h>
#include "../common/stratos_packet.h"

int main(void)
{
    stratos_record_t v[4] = {
        {7, 1, 412, 2348, 6021, 8455812, {3, -7, 1004}, {-2, 4, 1}, 3951, 0x0007},
        {7, 801, 80412, 2512, STRATOS_SENT_U16, 8730203, {150, 90, 1012}, {-120, 88, 351}, 3920, 0x0017},
        {65535, 4294967294u, 4294967295u, -32767, 0, 0, {-32767, 32767, 0}, {0, 0, 0}, 0, 0x1FFF},
        {7, 1501, 150412, STRATOS_SENT_I16, STRATOS_SENT_U16, STRATOS_SENT_U32,
         {STRATOS_SENT_I16, STRATOS_SENT_I16, STRATOS_SENT_I16},
         {STRATOS_SENT_I16, STRATOS_SENT_I16, STRATOS_SENT_I16}, STRATOS_SENT_U16, 0x0FF8},
    };
    uint32_t pseq[4] = {1, 81, 4294967295u, 0};
    char txc[4] = {STRATOS_TX_DONE, STRATOS_TX_DONE, STRATOS_TX_FAIL, STRATOS_TX_NONE};
    printf("CRCCHECK %04X\n", stratos_crc16((const uint8_t *)"123456789", 9));
    for (int i = 0; i < 4; i++) {
        uint8_t pkt[STRATOS_PKT_LEN];
        stratos_encode_packet(&v[i], pseq[i] ? pseq[i] : 1, pkt);
        printf("PKT ");
        for (unsigned j = 0; j < STRATOS_PKT_LEN; j++) printf("%02X", pkt[j]);
        printf("\n");
        char line[128];
        size_t n = stratos_format_log_line(&v[i], pseq[i], txc[i], line, sizeof line);
        printf("LOG %s (%u)\n", line, (unsigned)n);
    }
    char small[20];
    printf("SMALLBUF %u\n", (unsigned)stratos_format_log_line(&v[0], 1, 'T', small, sizeof small));
    return 0;
}
