"""Risk register, requirements and verification-matrix content (Rev A).

Single source for the spreadsheets and the dossier tables. Owners are ROLES:
the team has not supplied member names, so each role must be assigned to a
named member before the register is used.
"""

LIKELIHOOD = [
    (1, "Rare", "< 5 % chance during the project"),
    (2, "Unlikely", "5–20 %"),
    (3, "Possible", "20–50 %"),
    (4, "Likely", "50–80 %"),
    (5, "Almost certain", "> 80 %"),
]
CONSEQUENCE = [
    (1, "Negligible", "minutes of rework; no data lost"),
    (2, "Minor", "hours of rework, or a few seconds of telemetry lost but recoverable onboard"),
    (3, "Moderate", "days of rework, or part of one data product lost"),
    (4, "Major", "a mission objective lost, or weeks of schedule"),
    (5, "Severe", "injury or property-damage hazard, payload lost, or project cannot be completed"),
]
BANDS = [(1, 4, "Low"), (5, 9, "Medium"), (10, 16, "High"), (17, 25, "Critical")]

MIT_STATUS_PROPOSED = "Proposed — not yet verified"
MIT_STATUS_SIM = "Partly demonstrated in software simulation (synthetic data); hardware test pending"

# id, title, cause, effect, L, C, mitigation, verification, owner, mitigation status
RISKS = [
    ("R01", "Power interruption",
     "Connector shake-out, switch knocked, cell contact bounce in holder, brown-out during radio TX peak",
     "Reset → new session; up to 1 s of buffered records lost; possible truncated log line",
     3, 4,
     "Locking JST-XH connectors; cell retained by holder + zip tie; DPDT switch recessed in bottom cap; 100 µF bulk capacitor; "
     "1 s flush limits loss; line CRC detects truncation; new session ID makes the reset visible",
     "Bench power-cut test (10 cuts at random times): log recoverable, loss ≤ 10 records per cut, every truncated line flagged",
     "Electronics lead", MIT_STATUS_PROPOSED),
    ("R02", "Sensor malfunction",
     "I2C fault, damaged or counterfeit module, loose wire",
     "Missing measurement fields",
     3, 3,
     "Boot self-test with chip-ID check (BME280 ID 0x60 distinguishes it from a BMP280); per-field INVALID flags and sentinels; "
     "re-initialisation attempt every 10 s; spare modules",
     "Disconnect each sensor during a bench run: flags set, logging continues, sensor recovers on reconnection",
     "Firmware lead", MIT_STATUS_PROPOSED),
    ("R03", "Invalid (biased) measurements",
     "Self-heating from ESP32/regulator, poor ventilation, sensor lag, uncalibrated offsets",
     "Temperature/RH biased; pressure-derived altitude offset",
     4, 3,
     "BME280 on the opposite face of the spine from the ESP32, beside shell vent slots; low BME280 duty; plausibility limits; "
     "comparison against reference instruments before use",
     "Side-by-side comparison with a reference thermometer/hygrometer and barometer, inside the closed shell, for 30 min; "
     "record offset and settling time",
     "Systems lead", MIT_STATUS_PROPOSED),
    ("R04", "Storage failure",
     "microSD corruption on power loss, card shaken loose, worn or counterfeit card",
     "Onboard record incomplete or unreadable",
     3, 4,
     "Test every card on receipt (full-capacity write/read check) and reject counterfeits; industrial-grade card preferred when one "
     "can be sourced (none in stock on 24 Oct 2026, so the BOM lists a consumer card); card secured with polyimide tape; one file per session; 1 s flush; line CRC; "
     "telemetry provides an independent second copy of 1 record in 10",
     "4 h soak test, power-cut test and drop test with the card installed; card readable and all lines CRC-valid",
     "Firmware lead", MIT_STATUS_PROPOSED),
    ("R05", "Packet loss",
     "Range, antenna orientation, payload tumbling, body shadowing, ground antenna placement",
     "Gaps in live telemetry (data still on microSD)",
     4, 2,
     "Large link margin (see link budget); LoRa SF7 at 1 packet per 4 s as a longer-range fall-back that stays within the 2.5 % duty limit; elevated ground antenna; sequence numbers make every gap visible; "
     "onboard log recovers missing records",
     "Range test at increasing distances: log packet-error rate, RSSI and SNR; reconciliation explains every gap",
     "Ground-station lead", MIT_STATUS_SIM),
    ("R06", "Corrupted packets",
     "Noise or interference flips bits; partial frames",
     "Wrong values accepted if undetected",
     3, 2,
     "Radio packet-engine CRC plus application CRC-16 checked before any field is trusted; rejected frames logged with raw bytes",
     "Software: every single-bit error in a frame rejected (unit test, synthetic). Hardware: inject corrupted frames from a test transmitter",
     "Ground-station lead", MIT_STATUS_SIM),
    ("R07", "Radio interference",
     "Other 865–867 MHz users (RFID readers, LoRaWAN devices, meters)",
     "Higher packet loss; foreign frames received",
     3, 2,
     "Listen on the channel before each test and choose the quietest; private sync word; magic bytes, length and CRC reject foreign frames",
     "Channel survey log before every radio test",
     "Ground-station lead", MIT_STATUS_PROPOSED),
    ("R08", "Mechanical damage",
     "Landing impact, PETG cracking, board or battery shifting, rod nut loosening",
     "Broken parts, disconnected wires, lost data",
     3, 4,
     "Load path through two M3 stainless rods; ballast and battery low in the can; threadlocker / nyloc nuts; zip-tie retention; "
     "descent rate limited by parachute sizing",
     "Drop and shake tests at increasing severity; inspection checklist after each test",
     "Mechanical lead", MIT_STATUS_PROPOSED),
    ("R09", "Recovery-system failure",
     "Parachute tangles or fails to open, bridle or shroud line breaks, attachment pulls out",
     "High-speed impact; hazard to people and property; payload destroyed",
     3, 5,
     "Parachute sized by calculation with margin; swivel to prevent line twist; bridle and yoke rated far above opening load; "
     "packing procedure; no flight until drop tests pass and permission is held",
     "Repeated drop tests from a controlled height measuring descent rate; pull test of yoke and bridle to ≥ 10× estimated opening load",
     "Mechanical lead", MIT_STATUS_PROPOSED),
    ("R10", "Loss of the payload",
     "Wind drift, landing in vegetation or water, no locating aid",
     "Onboard record lost; hardware lost",
     2, 4,
     "Recovery beeper after landing detection; last RSSI and descent data from telemetry; high-visibility parachute; "
     "contact label; wind limit for tests; optional GNSS (deferred, pins reserved)",
     "Beeper audibility test at 30 m; recovery drill",
     "Systems lead", MIT_STATUS_PROPOSED),
    ("R11", "Component procurement delay",
     "Stock-outs, slow shipping, counterfeit parts needing replacement",
     "Schedule slip",
     3, 3,
     "Order all long-lead items in the first week; two suppliers identified per critical part; spares in BOM; listed alternatives",
     "Procurement tracker reviewed weekly",
     "Project manager", MIT_STATUS_PROPOSED),
    ("R12", "Insufficient time for integration and validation",
     "Late parts, underestimated firmware effort, competing coursework",
     "Untested system at submission",
     4, 4,
     "Staged plan with exit criteria; software pipeline built first (done in simulation); weekly milestone review; "
     "agreed de-scope order (GNSS, landing beeper, IMU) if behind",
     "Milestone review against roadmap each week",
     "Project manager", MIT_STATUS_PROPOSED),
    ("R13", "Li-ion battery hazard",
     "Short circuit, over-discharge, crushed cell, charging inside the can",
     "Fire or toxic gas; injury",
     2, 5,
     "Genuine cell from reputable seller; DW01A/FS8205A protection; 2.5 A-hold resettable PTC fuse; insulated holder; "
     "cell charged outside the can (external charger) or, supervised, through the module USB-C with the shell removed; "
     "firmware safe shutdown at 3.30 V",
     "Inspection before each use; short-circuit test of protection on the bench with current limit",
     "Electronics lead", MIT_STATUS_PROPOSED),
    ("R14", "Regulatory non-compliance",
     "Radio parameters outside the licence-exempt limits; no adaptive power control on the one-way link (GSR 853(E) Table II asks for it); "
     "type-approval (ETA) status of a one-off student prototype unknown; flight or drop without permission",
     "Test stopped; legal exposure",
     3, 4,
     "Radio configured inside 865–867 MHz within notified limits (GFSK, 1.15 % duty, ≈10 mW ERP); lowest power that gives an adequate margin in the range test; "
     "confirm ETA / prototype status with the institution before any outdoor transmission; ground tests only until written permissions exist; "
     "no drone drops without compliance with Drone Rules",
     "Configuration review and sign-off before each radio or flight test",
     "Systems lead", MIT_STATUS_PROPOSED),
    ("R15", "Competition rules differ from assumed envelope",
     "SEVA FIRST rules not yet obtained; ESA CanSat envelope assumed",
     "Redesign of enclosure or mass budget",
     3, 3,
     "Parametric CAD driven by one baseline file; obtain official rules before fabrication",
     "Rules compliance checklist completed before fabrication",
     "Project manager", MIT_STATUS_PROPOSED),
    ("R16", "Counterfeit or mislabelled parts",
     "Fake 18650 capacity, BMP280 sold as BME280, clone boards",
     "Lower runtime, missing humidity, unexpected behaviour",
     3, 3,
     "Reputable suppliers; chip-ID checks in self-test; capacity test of each cell before use",
     "Incoming inspection: chip IDs read, cell capacity measured",
     "Electronics lead", MIT_STATUS_PROPOSED),
]

def band(score):
    for lo, hi, name in BANDS:
        if lo <= score <= hi:
            return name
    return "?"

# ---------------------------------------------------------------------------
# Requirements (Chapter 1) and verification matrix (Chapter 8)
# id, requirement, rationale/source, method, procedure, acceptance, evidence, status
# ---------------------------------------------------------------------------
ST_NOT = "Not started"
ST_AN = "Analysis complete (this dossier, Rev A) — hardware test not started"
ST_SIM = "Demonstrated in software simulation (synthetic data) — hardware test not started"

REQUIREMENTS = [
    ("FR-01", "Measure air temperature, relative humidity and pressure", "Mission objective 1",
     "Test", "Bench run of BME280 through the firmware; compare with reference instruments",
     "Valid readings every record for 30 min; offsets vs reference recorded (no pass/fail on accuracy until calibration plan agreed)",
     "Serial log + comparison sheet", ST_NOT),
    ("FR-02", "Measure 3-axis acceleration and angular rate", "Mission objective 1 (motion)",
     "Test", "Static six-orientation test and rotation on a turntable",
     "|a| = 1.00 ± 0.05 g at rest in each orientation; gyro sign and axis correct", "Test log", ST_NOT),
    ("FR-03", "Record every 100 ms with session, rec_seq, t_ms and status", "Mission objective 2",
     "Test", "Run 10 min; analyse rec_seq and t_ms",
     "rec_seq continuous; 95 % of intervals within 100 ± 5 ms; overruns flagged", "Log file + analysis script output", ST_NOT),
    ("FR-04", "Store every record onboard independently of telemetry", "Mission objective 3",
     "Test", "Run 4 h with the radio disabled for part of the run",
     "All records present on microSD; flush interval ≤ 1 s", "Log file, record count", ST_NOT),
    ("FR-05", "Detect incomplete or corrupted onboard lines", "Mission objective 3",
     "Test", "Cut power during writes (10 times); run reconciliation",
     "Every damaged line reported (ONBOARD_LINE_INVALID); no damaged line accepted",
     "Reconciliation reports", "Demonstrated in software simulation (truncated line, synthetic) — hardware test not started"),
    ("FR-06", "Transmit one 44-byte packet per second with pkt_seq, rec_seq and CRC-16", "Mission objective 4",
     "Test", "Bench link, 30 min, receiver at 2 m",
     "≥ 99 % of packets received; every packet CRC-valid; pkt_seq continuous", "Transmitter + receiver logs", ST_NOT),
    ("FR-07", "Ground station validates frames and logs accepted and rejected frames with UTC time", "Mission objective 7",
     "Test", "Replay capture + live link; inject corrupted frames",
     "Every corrupted frame rejected and logged with raw bytes; every accepted row has rx_utc", "ground_*.csv files", ST_SIM),
    ("FR-08", "Ground station detects missing, duplicate and out-of-order packets and session changes", "Mission objective 5",
     "Test", "Drop packets deliberately (transmitter skips sequence numbers); reboot payload",
     "Every skipped pkt_seq listed in ground_gaps.csv; reboot flagged SESSION_CHANGE", "Test output", ST_SIM),
    ("FR-09", "Reconcile onboard and ground records and classify every discrepancy", "Mission objective 5",
     "Test", "Integrated ground test with induced losses",
     "All induced losses classified correctly; zero unexplained discrepancies", "Reconciliation report", ST_SIM),
    ("FR-10", "Distinguish an unavailable measurement from a valid zero", "Project brief §4.3",
     "Test", "Disconnect a sensor; inspect packet and log",
     "INVALID flag set and sentinel/empty field written; zero values never used for absent data", "Packet + log excerpt", ST_SIM),
    ("FR-11", "Operate for the design logging window of 4 h on one charge with ≥ 50 % margin", "Assumed operating requirement",
     "Analysis + Test", "Power budget; then measured current and a full discharge run",
     "Measured average current × 4 h ≤ 50 % of measured usable capacity", "Power budget + measured run", ST_AN),
    ("FR-12", "Fit the reference envelope (Ø 66 × 115 mm) and the competition mass limit", "Assumed envelope (rules TBC)",
     "Analysis + Inspection", "CAD envelope check; weigh the built payload",
     "All rigid parts inside Ø 66 × 115 mm; mass within the published limit", "CAD report + scale reading", ST_AN),
    ("FR-13", "Descend under a parachute within the target descent-rate band", "Assumed (rules TBC)",
     "Analysis + Test", "Parachute sizing; drop tests with timing over a measured height",
     "Mean of 3 drops within the target band", "Calculation + drop-test video and timing", ST_AN),
    ("FR-14", "Provide an audible recovery aid after landing", "Recovery objective",
     "Demonstration", "Simulate a landing on the bench; listen at distance",
     "Beeper audible at 30 m outdoors", "Test note", ST_NOT),
    ("FR-15", "Keep radio emissions within the India licence-exempt 865–867 MHz limits", "Regulatory",
     "Inspection + Analysis", "Review radio configuration against the notification",
     "Frequency, bandwidth and power inside the notified limits", "Signed configuration checklist", ST_AN),
    ("FR-16", "Retain all components under handling, drop and landing loads", "Mission objective 6",
     "Test + Inspection", "Shake test and drop tests; post-test inspection",
     "No part detached or loosened; no connector unseated", "Inspection record + photos of the actual assembly", ST_NOT),
    ("FR-17", "Protect the Li-ion cell against short circuit and over-discharge", "Safety",
     "Test + Inspection", "Bench short-circuit test through current-limited supply; under-voltage cut-off check",
     "Protection opens; PTC trips; firmware enters safe shutdown at 3.30 V", "Test log", ST_NOT),
    ("FR-18", "Close the log cleanly before battery cut-off", "Mission objective 3",
     "Test", "Discharge on the bench to below 3.30 V",
     "Log file closed; final line CRC-valid; SAFE SHUTDOWN logged", "Log file", ST_NOT),
]
