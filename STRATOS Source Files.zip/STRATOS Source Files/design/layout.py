"""
STRATOS internal layout — component envelope placements (Rev A, PROPOSED).

All dimensions in mm. Coordinates: Z up from the bottom face of the bottom
cap; spine in the X–Z plane; face A = +Y (controller), face B = −Y (battery,
sensors, radio). Each module is an axis-aligned envelope block:
  x0, y0, z0 = minimum corner; w = size in X; t = size in Y; h = size in Z.
`dim_src` says where the outline dimensions come from (VERIFIED datasheet /
SUPPLIER listing / PRELIMINARY estimate to be measured on the real part).
"""
from baseline import GEOM as G

Z_SHELL0 = G["cap_t"] + 0.2                       # 4.2  (0.2 mm float each end)
Z_SPINE0 = G["cap_t"] + G["spigot_h"]             # 7.0  spine sits on bottom spigot
Z_TOP_SPIGOT = Z_SPINE0 + G["spine_h"]            # 97.0
Z_TOP_FACE = Z_TOP_SPIGOT + G["spigot_h"] + G["cap_t"]   # 104.0
Z_YOKE0 = Z_TOP_FACE + 0.5                        # M3 washer under the yoke
Z_ROD0 = 0.5
WEB_Y = G["spine_t"] / 2                          # 1.5
CARRIER_Y0 = WEB_Y + 5.0                          # M2.5 x 5 mm standoffs → 6.5
CARRIER_TOP = CARRIER_Y0 + 1.6                    # 8.1
HDR_H = 8.5                                       # female header height
FACEB_PCB = -(WEB_Y + 4.0)                        # M2.5 x 4 mm standoffs → -5.5

def P(cat, x0, y0, z0, w, t, h, label, dim_src, **kw):
    d = dict(cat=cat, x0=x0, y0=y0, z0=z0, w=w, t=t, h=h, label=label, dim_src=dim_src)
    d.update(kw)
    return d

PLACE = {
    # ---------------- face A (+Y): controller carrier ------------------------
    "Carrier": P("PCB", -25.0, CARRIER_Y0, 26.0, 50.0, 1.6, 70.0,
                 "Carrier board: 50 × 70 mm double-sided perfboard", "SUPPLIER (standard 5 × 7 cm perfboard)"),
    "ESP32_Headers_L": P("Connector", -11.43 - 1.25, CARRIER_TOP, 44.65, 2.5, HDR_H, 48.3,
                         "Female header 1×19, 2.54 mm", "PRELIMINARY"),
    "ESP32_Headers_R": P("Connector", 11.43 - 1.25, CARRIER_TOP, 44.65, 2.5, HDR_H, 48.3,
                         "Female header 1×19, 2.54 mm", "PRELIMINARY"),
    "ESP32_DevKitC": P("Controller", -13.95, CARRIER_TOP + HDR_H, 41.6, 27.9, 1.6, 54.4,
                       "U1 ESP32-DevKitC V4 (ESP32-WROOM-32E)", "VERIFIED (Espressif DevKitC V4 dimension figure: 54.4 × 27.9)"),
    "ESP32_Module": P("Controller", -9.0, CARRIER_TOP + HDR_H + 1.6, 70.5, 18.0, 3.1, 25.5,
                      "ESP32-WROOM-32E module (18 × 25.5 × 3.1 mm)", "PRELIMINARY (module datasheet value to confirm)"),
    "ESP32_USB": P("Connector", -4.0, CARRIER_TOP + HDR_H + 1.6, 41.6, 8.0, 3.0, 5.0,
                   "Micro-USB (programming; reached with shell removed)", "PRELIMINARY"),
    "SD_Breakout": P("Storage", -21.3, WEB_Y + 1.0, 33.0, 22.8, 3.5, 25.4,
                     "U5 microSD breakout (3 V, SPI) under the carrier, card slot at −X edge", "VERIFIED (Adafruit 4682: 25.4 × 22.8 × 3.5)"),
    "Regulator": P("Power", -24.5, CARRIER_TOP, 49.0, 11.0, 3.0, 17.0,
                   "U6 Pololu S7V8F3 3.3 V buck-boost", "VERIFIED (Pololu: 11 × 17 × 3)"),
    "C1_Bulk": dict(cat="Passive", shape="cyl_y", cx=-20.0, cz=71.0, y0=CARRIER_TOP, t=7.7, d=6.3,
                    label="C1 100 µF bulk capacitor", dim_src="PRELIMINARY"),
    "LED": dict(cat="Passive", shape="cyl_y", cx=-20.0, cz=90.0, y0=CARRIER_TOP, t=8.0, d=5.0,
                label="D2 status LED", dim_src="PRELIMINARY"),
    "BUZZER": dict(cat="Passive", shape="cyl_y", cx=17.5, cz=33.0, y0=CARRIER_TOP, t=9.5, d=12.0,
                   label="BZ1 active buzzer Ø12 mm", dim_src="PRELIMINARY"),
    "J1_BATT": P("Connector", -24.5, CARRIER_TOP, 27.0, 5.75, 7.0, 7.4, "J1 battery in (JST-XH 2p)", "PRELIMINARY"),
    "J4_SWITCH": P("Connector", -24.5, CARRIER_TOP, 35.5, 5.75, 7.0, 12.4, "J4 power switch (JST-XH 4p)", "PRELIMINARY"),
    "J2_SENS": P("Connector", 14.5, CARRIER_TOP, 41.5, 5.75, 7.0, 14.9, "J2 sensor bus (JST-XH 5p)", "PRELIMINARY"),
    "J3_RADIO": P("Connector", 14.5, CARRIER_TOP, 58.0, 5.75, 7.0, 14.9, "J3 radio SPI (JST-XH 5p)", "PRELIMINARY"),
    "J5_RADIO": P("Connector", 14.5, CARRIER_TOP, 74.0, 5.75, 7.0, 12.4, "J5 radio control (JST-XH 4p)", "PRELIMINARY"),
    "U7_Protection": P("Power", -21.0, WEB_Y, 8.0, 26.0, 4.0, 17.0,
                       "U7 TP4056 + DW01A protection module (USB-C toward −X)", "PRELIMINARY"),
    # ---------------- face B (−Y): battery, sensors, radio ---------------------
    "Batt_Holder": P("Power", -21.0, -WEB_Y - 18.5, 8.0, 21.0, 18.5, 77.0,
                     "BT1 holder, 1 × 18650", "PRELIMINARY"),
    "Cell_18650": dict(cat="Battery", shape="cyl_z", cx=-10.5, cy=-WEB_Y - 9.3, z0=14.0, h=65.25, d=18.55,
                       label="BT1 18650 Li-ion cell", dim_src="VERIFIED (Samsung INR18650-35E max Ø18.55 × 65.25)"),
    "IMU": P("Sensor", 4.0, FACEB_PCB - 4.6, 9.0, 17.8, 4.6, 25.6,
             "U3 Adafruit 4438 LSM6DSOX breakout", "VERIFIED (Adafruit: 25.6 × 17.8 × 4.6)"),
    "LoRa": P("Radio", 2.0, FACEB_PCB - 4.8, 38.0, 22.0, 4.8, 25.0,
              "U4 Ra-01H (17 × 16 × 3.2, verified) on hand-made 22 × 25 adapter", "PRELIMINARY (adapter)"),
    "BME280": P("Sensor", 2.0, FACEB_PCB - 3.5, 68.0, 15.0, 3.5, 11.5,
                "U2 BME280 breakout (beside shell vents)", "PRELIMINARY"),
    "Antenna": dict(cat="Radio", shape="cyl_z", cx=20.0, cy=-8.0, z0=63.0, h=22.0, d=6.0,
                    label="E1 868 MHz helical antenna, soldered to radio adapter ANT pad", dim_src="PRELIMINARY"),
    # ---------------- bottom cap ------------------------------------------------
    "Switch": P("Connector", -8.5, 10.25, Z_SPINE0, 17.0, 6.0, 6.5,
                "SW1 DPDT slide switch (pen-tip operated through cap)", "PRELIMINARY"),
}

# standoffs (cylinders along Y)
STANDOFFS = []
for (x, z) in [(-18.0, 29.0), (18.0, 29.0), (-18.0, 93.0), (18.0, 93.0)]:
    STANDOFFS.append(dict(cat="Hardware", shape="cyl_y", cx=x, cz=z, y0=WEB_Y, t=5.0, d=4.5,
                          label="M2.5 × 5 standoff", dim_src="SUPPLIER"))
for name in ("IMU", "LoRa", "BME280"):
    p = PLACE[name]
    for (fx, fz) in ((0.15, 0.12), (0.75, 0.88)):
        STANDOFFS.append(dict(cat="Hardware", shape="cyl_y", cx=round(p["x0"] + fx * p["w"], 2),
                              cz=round(p["z0"] + fz * p["h"], 2), y0=FACEB_PCB, t=4.0, d=4.5,
                              label="M2.5 × 4 standoff", dim_src="SUPPLIER"))
for i, s in enumerate(STANDOFFS):
    PLACE[f"Standoff{i + 1}"] = s

STANDOFF_HOLES = [(s["cx"], s["cz"]) for s in STANDOFFS]
CABLE_SLOTS = [(-11.0, 91.5, 14.0, 6.0), (-8.0, 11.0, 10.0, 5.0)]     # (cx, cz, width X, height Z)
ZIP_SLOTS = [(-22.5 + 0.0, 30.0), (0.8, 30.0), (-22.5 + 0.0, 66.0), (0.8, 66.0)]

SWITCH = dict(x=0.0, y=13.25, slot_w=8.0, slot_l=3.0, hole_pitch=15.0)

MATERIAL = {"BottomCap": ("PETG (printed)", 1.27), "TopCap": ("PETG (printed)", 1.27),
            "Shell": ("PETG (printed)", 1.27), "Spine": ("PETG (printed)", 1.27),
            "Yoke": ("Aluminium 6061 flat bar", 2.70)}

COLORS = {
    "BottomCap": (0.62, 0.68, 0.76, 1), "TopCap": (0.62, 0.68, 0.76, 1),
    "Shell": (0.85, 0.88, 0.92, 0.35), "Spine": (0.93, 0.93, 0.90, 1), "Yoke": (0.72, 0.74, 0.77, 1),
    "Hardware": (0.55, 0.56, 0.58, 1), "PCB": (0.20, 0.45, 0.30, 1), "Controller": (0.15, 0.30, 0.55, 1),
    "Connector": (0.95, 0.95, 0.92, 1), "Storage": (0.55, 0.30, 0.55, 1), "Power": (0.85, 0.45, 0.15, 1),
    "Battery": (0.20, 0.55, 0.75, 1), "Sensor": (0.15, 0.55, 0.45, 1), "Radio": (0.70, 0.20, 0.20, 1),
    "Passive": (0.25, 0.25, 0.25, 1),
}

# Only genuine by-design overlaps are listed; touching faces have zero intersection volume.
ALLOWED_CONTACT = {("Cell_18650", "Batt_Holder"), ("Batt_Holder", "Cell_18650")}
