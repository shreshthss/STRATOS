"""
STRATOS electrical netlist — Rev A (PROPOSED). Single source for the schematic
drawing, the KiCad-format netlist, the pin-mapping CSV and the component list.

Each component: refdes -> dict(value, part, location, pins={pin_id: (pin_name, net)}).
A net of None means "not connected". Net names for ESP32 GPIO signals are the
`signal` names in baseline.PINS, and a consistency check below enforces that.
"""
from baseline import PINS

NC = None
DEVKIT_LEFT = [  # ESP32-DevKitC V4 header J2 (pin 1 at the 3V3 end)
    ("3V3", "+3V3"), ("EN", NC), ("SENSOR_VP (IO36)", NC), ("SENSOR_VN (IO39)", "IMU_INT1"),
    ("IO34", "VBAT_SENSE"), ("IO35", "RADIO_DIO1"), ("IO32", "RADIO_RST"), ("IO33", "RADIO_NSS"),
    ("IO25", "STATUS_LED"), ("IO26", "RADIO_DIO0"), ("IO27", "RADIO_MISO"), ("IO14", "RADIO_SCK"),
    ("IO12", NC), ("GND", "GND"), ("IO13", "RADIO_MOSI"), ("SD2", NC), ("SD3", NC), ("CMD", NC), ("5V", NC)]
DEVKIT_RIGHT = [  # header J3 (pin 1 at the GND end, opposite 3V3)
    ("GND", "GND"), ("IO23", "SD_MOSI"), ("IO22", "I2C_SCL"), ("TX (IO1)", NC), ("RX (IO3)", NC),
    ("IO21", "I2C_SDA"), ("GND", "GND"), ("IO19", "SD_MISO"), ("IO18", "SD_SCK"), ("IO5", "SD_CS"),
    ("IO17", NC), ("IO16", NC), ("IO4", "BUZZER_EN"), ("IO0", NC), ("IO2", NC), ("IO15", NC),
    ("SD1", NC), ("SD0", NC), ("CLK", NC)]

COMP = {}
def add(ref, value, part, loc, pins):
    COMP[ref] = dict(value=value, part=part, location=loc, pins=pins)

add("U1", "ESP32-DevKitC V4", "Espressif ESP32-DevKitC V4 (ESP32-WROOM-32E)", "Carrier (face A), on female headers",
    {**{f"L{i + 1}": p for i, p in enumerate(DEVKIT_LEFT)}, **{f"R{i + 1}": p for i, p in enumerate(DEVKIT_RIGHT)}})
add("U2", "BME280", "BME280 breakout, 3.3 V, I2C", "Face B, beside shell vents",
    {"1": ("VIN", "+3V3"), "2": ("GND", "GND"), "3": ("SCL", "I2C_SCL"), "4": ("SDA", "I2C_SDA")})
add("U3", "LSM6DSOX", "Adafruit LSM6DSOX 6-DoF breakout (4438)", "Face B, low on spine",
    {"1": ("VIN", "+3V3"), "2": ("GND", "GND"), "3": ("SCL", "I2C_SCL"), "4": ("SDA", "I2C_SDA"), "5": ("INT1", "IMU_INT1"),
     "6": ("3Vo", NC), "7": ("DO/SA0", NC), "8": ("CS", NC), "9": ("INT2", NC)})
add("U4", "Ra-01H", "Ai-Thinker Ra-01H (SX1276) on 2.54 mm adapter", "Face B, middle",
    {"1": ("3.3V", "+3V3"), "2": ("GND", "GND"), "3": ("SCK", "RADIO_SCK"), "4": ("MISO", "RADIO_MISO"),
     "5": ("MOSI", "RADIO_MOSI"), "6": ("NSS", "RADIO_NSS"), "7": ("RESET", "RADIO_RST"), "8": ("DIO0", "RADIO_DIO0"),
     "9": ("DIO1", "RADIO_DIO1"), "10": ("DIO2", NC), "11": ("DIO3", NC), "12": ("DIO4", NC), "13": ("DIO5", NC),
     "14": ("ANT (IPEX)", "RF_ANT")})
add("E1", "868 MHz", "868 MHz helical antenna, direct solder (≈1.5 dBi per supplier listing)", "Face B, on radio adapter", {"1": ("FEED", "RF_ANT")})
add("U5", "microSD 3V", "microSD SPI breakout, 3 V only (no regulator/level shifter)", "Carrier (face A), below U1",
    {"1": ("3V", "+3V3"), "2": ("GND", "GND"), "3": ("CLK", "SD_SCK"), "4": ("SO", "SD_MISO"), "5": ("SI", "SD_MOSI"),
     "6": ("CS", "SD_CS"), "7": ("DET", NC)})
add("U6", "S7V8F3", "Pololu S7V8F3 3.3 V step-up/step-down regulator", "Carrier (face A)",
    {"1": ("VIN", "VSYS"), "2": ("GND", "GND"), "3": ("VOUT", "VREG"), "4": ("EN", NC)})
add("U7", "TP4056 + DW01A", "TP4056 USB-C charger module with DW01A/FS8205A protection (used for cell protection; USB-C only for supervised bench charging)", "Face A, below carrier",
    {"1": ("B+", "CELL_P"), "2": ("B-", "CELL_N"), "3": ("OUT+", "VBAT_PROT"), "4": ("OUT-", "GND"), "5": ("USB-C VBUS", NC)})
add("BT1", "18650", "18650 Li-ion cell in single-cell holder", "Face B",
    {"1": ("+", "CELL_P"), "2": ("-", "CELL_N")})
add("F1", "PTC 2.5 A", "Resettable PTC fuse, 2.5 A hold, 16 V (Littelfuse/Raychem RGEF250)", "Carrier, at J1",
    {"1": ("1", "VBAT_PROT"), "2": ("2", "VBAT_P")})
add("SW1", "DPDT", "DPDT slide switch (master switch)", "Bottom cap",
    {"1": ("A_COM", "VBAT_P"), "2": ("A_NO", "VSYS"), "3": ("A_NC", NC),
     "4": ("B_COM", "VREG"), "5": ("B_NO", "+3V3"), "6": ("B_NC", NC)})
add("J1", "JST-XH 2p", "Battery input connector (from U7 OUT±)", "Carrier", {"1": ("1", "VBAT_PROT"), "2": ("2", "GND")})
add("J2", "JST-XH 5p", "Sensor-bus connector (to U2, U3)", "Carrier",
    {"1": ("1", "+3V3"), "2": ("2", "GND"), "3": ("3", "I2C_SDA"), "4": ("4", "I2C_SCL"), "5": ("5", "IMU_INT1")})
add("J3", "JST-XH 5p", "Radio SPI connector (to U4)", "Carrier",
    {"1": ("1", "+3V3"), "2": ("2", "GND"), "3": ("3", "RADIO_SCK"), "4": ("4", "RADIO_MISO"), "5": ("5", "RADIO_MOSI")})
add("J5", "JST-XH 4p", "Radio control connector (to U4)", "Carrier",
    {"1": ("1", "RADIO_NSS"), "2": ("2", "RADIO_RST"), "3": ("3", "RADIO_DIO0"), "4": ("4", "RADIO_DIO1")})
add("J4", "JST-XH 4p", "Master-switch connector (to SW1)", "Carrier",
    {"1": ("1", "VBAT_P"), "2": ("2", "VSYS"), "3": ("3", "VREG"), "4": ("4", "+3V3")})
add("R1", "100 kΩ", "Resistor 1 %, 0.25 W", "Carrier", {"1": ("1", "VSYS"), "2": ("2", "VBAT_SENSE")})
add("R2", "100 kΩ", "Resistor 1 %, 0.25 W", "Carrier", {"1": ("1", "VBAT_SENSE"), "2": ("2", "GND")})
add("C3", "100 nF", "Ceramic capacitor", "Carrier", {"1": ("1", "VBAT_SENSE"), "2": ("2", "GND")})
add("R4", "10 kΩ", "Resistor, SD_CS pull-up", "Carrier", {"1": ("1", "+3V3"), "2": ("2", "SD_CS")})
add("R5", "10 kΩ", "Resistor, RADIO_NSS pull-up", "Carrier", {"1": ("1", "+3V3"), "2": ("2", "RADIO_NSS")})
add("R6", "1 kΩ", "Resistor, Q1 base", "Carrier", {"1": ("1", "BUZZER_EN"), "2": ("2", "Q1_B")})
add("Q1", "BC547", "NPN transistor, TO-92", "Carrier", {"B": ("B", "Q1_B"), "C": ("C", "BZ_N"), "E": ("E", "GND")})
add("BZ1", "Buzzer", "Active electromagnetic buzzer, 5 V rated, Ø12 mm (audibility at 3.3 V to be tested)", "Carrier", {"1": ("+", "+3V3"), "2": ("-", "BZ_N")})
add("D1", "1N4148", "Flyback diode across BZ1 (electromagnetic buzzer)", "Carrier", {"A": ("A", "BZ_N"), "K": ("K", "+3V3")})
add("R7", "1 kΩ", "Resistor, LED series", "Carrier", {"1": ("1", "STATUS_LED"), "2": ("2", "LED_A")})
add("D2", "LED", "5 mm LED", "Carrier", {"A": ("A", "LED_A"), "K": ("K", "GND")})
add("C1", "100 µF", "Electrolytic capacitor 16 V, +3V3 bulk", "Carrier", {"+": ("+", "+3V3"), "-": ("-", "GND")})
add("C2", "10 µF", "Ceramic/electrolytic 16 V, VSYS input", "Carrier", {"+": ("+", "VSYS"), "-": ("-", "GND")})
add("R8", "4.7 kΩ DNP", "I2C SDA pull-up — fit only if breakouts lack pull-ups", "Carrier", {"1": ("1", "+3V3"), "2": ("2", "I2C_SDA")})
add("R9", "4.7 kΩ DNP", "I2C SCL pull-up — fit only if breakouts lack pull-ups", "Carrier", {"1": ("1", "+3V3"), "2": ("2", "I2C_SCL")})


def nets():
    out = {}
    for ref, c in COMP.items():
        for pid, (pname, net) in c["pins"].items():
            if net:
                out.setdefault(net, []).append((ref, pid, pname))
    return out


def check():
    """Consistency: every assigned ESP32 GPIO in baseline.PINS has the same net in U1."""
    u1 = {pname: net for _pid, (pname, net) in COMP["U1"]["pins"].items()}
    errs = []
    for ref, sig, gpio, label, d, bus, rem in PINS:
        if sig.startswith(("UART0", "GNSS")):
            continue
        hits = [p for p, n in u1.items() if n == sig]
        if not hits:
            errs.append(f"{sig}: not on U1")
            continue
        names = [p for p in hits if f"IO{gpio}" in p.replace(" ", "")]
        if not names:
            errs.append(f"{sig}: baseline GPIO{gpio} but U1 pin {hits}")
    for net, members in nets().items():
        if len(members) < 2:
            errs.append(f"net {net} has a single connection {members}")
    return errs


if __name__ == "__main__":
    e = check()
    print("consistency errors:", e or "none")
    print(len(COMP), "components,", len(nets()), "nets")
