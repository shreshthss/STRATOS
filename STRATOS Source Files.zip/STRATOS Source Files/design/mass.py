"""
STRATOS mass budget and parachute sizing — Rev A (preliminary).
src: VERIFIED (manufacturer page/datasheet) | CAD (computed from the model) |
     EST (estimate — weigh the actual part on receipt).
"""
import json, math, os

HERE = os.path.dirname(os.path.abspath(__file__))
CAD_REPORT = os.path.join(HERE, "..", "work", "cad", "cad_report.json")

# printed-part fill factor vs solid volume (ASSUMED print settings)
FILL = {"BottomCap": 0.70, "TopCap": 0.70, "Spine": 0.85, "Shell": 1.00}


def items():
    rep = json.load(open(CAD_REPORT))["fabricated_parts"]
    rows = [
        # name, qty, each_g, src
        ("ESP32-DevKitC V4 board", 1, 9.0, "EST"),
        ("BME280 breakout", 1, 1.0, "EST"),
        ("LSM6DSOX breakout (Adafruit 4438)", 1, 1.7, "VERIFIED (Adafruit)"),
        ("Ra-01H radio module", 1, 1.5, "EST"),
        ("Radio adapter (perfboard 22 × 25 mm + header)", 1, 2.5, "EST"),
        ("868 MHz helical antenna", 1, 0.5, "EST"),
        ("microSD breakout (Adafruit 4682)", 1, 2.5, "VERIFIED (Adafruit)"),
        ("microSD card", 1, 0.5, "EST"),
        ("Pololu S7V8F3 regulator", 1, 0.6, "VERIFIED (Pololu, no headers)"),
        ("TP4056 + DW01A module", 1, 2.0, "EST"),
        ("18650 cell (upper bound: 35E max)", 1, 50.0, "UPPER BOUND (Samsung 35E max 50 g, VERIFIED); weigh the BOM cell"),
        ("Single-cell holder (Keystone 1043)", 1, 8.0, "EST"),
        ("Carrier perfboard 50 × 70 mm", 1, 9.0, "EST (FR-4 1.6 mm, density 1.85 g/cm³)"),
        ("Female headers 2 × 19", 1, 3.0, "EST"),
        ("JST-XH connectors + harness wiring", 1, 8.0, "EST"),
        ("Passives, LED, Q1, D1, PTC", 1, 3.0, "EST"),
        ("Buzzer", 1, 2.0, "EST"),
        ("DPDT switch", 1, 2.0, "EST"),
    ]
    for part in ("BottomCap", "TopCap", "Shell", "Spine"):
        d = rep[part]
        rows.append((f"{part} (PETG, {int(FILL[part] * 100)} % of solid {d['mass_solid_g']} g)", 1,
                     round(d["mass_solid_g"] * FILL[part], 1), "CAD × ASSUMED fill factor"))
    rows.append(("Recovery yoke (Al 6061)", 1, rep["Yoke"]["mass_solid_g"], "CAD"))
    rod = math.pi * 1.5 ** 2 * 112.5 * 7.9e-3 * 0.85
    rows += [("M3 A2 threaded rod × 112.5 mm", 2, round(rod, 2), "COMPUTED (steel 7.9 g/cm³, 85 % of gross section)"),
             ("M3 nuts, nyloc nuts, washers", 1, 2.0, "EST"),
             ("M2.5 screws (14)", 1, 5.0, "EST"),
             ("Parachute canopy Ø0.33 m ripstop + lines + Y-bridle + swivel", 1, 16.0, "EST")]
    return rows


def budget():
    rows = items()
    total = sum(q * m for _, q, m, _ in rows)
    return rows, total


def parachute(mass_kg, v, cd=0.75, rho=1.225, g=9.81):
    """Return canopy area (m²) and nominal diameter (m) for steady descent speed v."""
    A = 2 * mass_kg * g / (rho * cd * v * v)
    return A, math.sqrt(4 * A / math.pi)


def descent_speed(mass_kg, d_m, cd=0.75, rho=1.225, g=9.81):
    A = math.pi * d_m ** 2 / 4
    return math.sqrt(2 * mass_kg * g / (rho * cd * A))


if __name__ == "__main__":
    rows, total = budget()
    for r in rows:
        print(r)
    print("total g", round(total, 1))
    for m in (total / 1000, 0.300, 0.325, 0.350):
        A, D = parachute(m, 9.0)
        print(f"m={m:.3f} kg: D for 9 m/s = {D:.3f} m; with D=0.40 m v = {descent_speed(m, 0.40):.2f} m/s")
