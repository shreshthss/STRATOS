"""
STRATOS baseline design — single source of truth (Rev A, 24 Oct 2026).

Every generated deliverable (CAD, drawings, schematic, pin map, diagrams,
power/storage/mass budgets, BOM, dossier tables) imports its names and numbers
from this file, so the documents describe one system. Change a value here and
regenerate; do not edit the generated outputs by hand.

Status vocabulary used throughout:
  VERIFIED  value taken from a manufacturer datasheet / official page (cited)
  SUPPLIER  value from a supplier listing (cited), not a manufacturer document
  ASSUMED   engineering assumption, to be measured or confirmed
  PROPOSED  design decision made in this dossier, not yet built or tested
"""

REV = "A"
DATE = "2026-10-24"
TEAM = "Nothingburger"
COMPETITION = "SEVA FIRST Innovation Challenge 2026 — Diploma & Higher Education track"

# ---------------------------------------------------------------------------
# Operating schedule (PROPOSED)
# ---------------------------------------------------------------------------
RECORD_PERIOD_MS = 100          # 10 Hz onboard records
TX_EVERY_N = 10                 # 1 Hz telemetry (records with rec_seq % 10 == 1)
FLUSH_EVERY_N = 10              # SD flush once per second, offset 5 cycles from TX
FLUSH_OFFSET = 5
MISSION_LOG_H = 4.0             # design logging window (ASSUMED requirement, see dossier §1.4)
RING_BUFFER_RECORDS = 50        # 5 s of records held in RAM

# ---------------------------------------------------------------------------
# Radio configuration (PROPOSED; band limits per WPC notification, see dossier)
# ---------------------------------------------------------------------------
RADIO = dict(
    chip="Semtech SX1276", module="Ai-Thinker Ra-01H",
    freq_mhz=866.0, band="865–867 MHz licence-exempt band (India, GSR 853(E) 2021)",
    modulation="GFSK (SX1276 FSK packet engine)",
    bitrate_bps=38400, fdev_khz=40.0, gaussian_bt=0.5,
    preamble_bytes=5, sync_bytes=4, sync_word="0x53 0x54 0x52 0x41 ('STRA')",
    length_mode="fixed 44 bytes", phy_crc="CRC-16 (packet engine) on", whitening="on",
    tx_power_dbm=14, payload_bytes=44, tx_timeout_ms=50,
    # LoRa alternative kept as an option (not baseline): SF7 / 125 kHz / CR 4/5,
    # max 1 packet per 4 s to respect the 2.5 % duty-cycle limit.
    lora_alt=dict(sf=7, bw_khz=125, cr="4/5", preamble=8, interval_s=4.0),
    duty_limit_pct=2.5, erp_limit_mw=500, bw_limit_khz=200,
    reg_class="GSR 853(E) Table II (tracking, tracing and data acquisition)",
)

# ---------------------------------------------------------------------------
# Electrical: ESP32-DevKitC V4 pin assignment (PROPOSED)
# (ref, signal, esp32_gpio, devkit_pin_label, direction from ESP32, bus, remarks)
# ---------------------------------------------------------------------------
PINS = [
    # I2C bus: BME280 + IMU
    ("U2/U3", "I2C_SDA", 21, "IO21", "bidir", "I2C0", "400 kHz; pull-ups on breakout boards (check total value)"),
    ("U2/U3", "I2C_SCL", 22, "IO22", "out", "I2C0", "400 kHz"),
    ("U3", "IMU_INT1", 39, "SVN (IO39)", "in", "GPIO", "IMU data-ready interrupt; input-only pin, no internal pull"),
    # microSD on VSPI (native IOMUX pins)
    ("U5", "SD_SCK", 18, "IO18", "out", "VSPI", "native VSPI pin"),
    ("U5", "SD_MISO", 19, "IO19", "in", "VSPI", "native VSPI pin"),
    ("U5", "SD_MOSI", 23, "IO23", "out", "VSPI", "native VSPI pin"),
    ("U5", "SD_CS", 5, "IO5", "out", "VSPI", "strapping pin, must be HIGH at boot: R4 10 kΩ pull-up holds card deselected"),
    # SX1276 radio on HSPI, routed through GPIO matrix where needed
    ("U4", "RADIO_SCK", 14, "IO14", "out", "HSPI", "native HSPI CLK; toggles at boot while NSS is held high (harmless)"),
    ("U4", "RADIO_MISO", 27, "IO27", "in", "HSPI", "GPIO matrix (avoids strapping pin IO12)"),
    ("U4", "RADIO_MOSI", 13, "IO13", "out", "HSPI", "native HSPI MOSI"),
    ("U4", "RADIO_NSS", 33, "IO33", "out", "HSPI", "chip select; R5 10 kΩ pull-up keeps radio deselected at boot"),
    ("U4", "RADIO_RST", 32, "IO32", "out", "GPIO", "active-low reset, used for radio recovery"),
    ("U4", "RADIO_DIO0", 26, "IO26", "in", "GPIO", "PacketSent / PayloadReady interrupt (FSK); TxDone/RxDone (LoRa)"),
    ("U4", "RADIO_DIO1", 35, "IO35", "in", "GPIO", "FIFO level / spare; input-only pin"),
    # Analogue, indicators
    ("R1/R2", "VBAT_SENSE", 34, "IO34", "in", "ADC1_CH6", "VSYS via 100k/100k divider + 100 nF; ADC1 so Wi-Fi state does not matter"),
    ("Q1", "BUZZER_EN", 4, "IO4", "out", "GPIO", "drives Q1 base through R6 1 kΩ"),
    ("D2", "STATUS_LED", 25, "IO25", "out", "GPIO", "LED via R7 1 kΩ (≈1 mA)"),
    # Reserved / not used
    ("—", "UART0_TX", 1, "TX (IO1)", "out", "UART0", "USB programming/debug only"),
    ("—", "UART0_RX", 3, "RX (IO3)", "in", "UART0", "USB programming/debug only"),
    ("(J7)", "GNSS_RX (reserved)", 16, "IO16", "in", "UART2", "reserved for optional GNSS; not populated in baseline"),
    ("(J7)", "GNSS_TX (reserved)", 17, "IO17", "out", "UART2", "reserved for optional GNSS; not populated in baseline"),
]

# Pins that must NOT be used (ESP32-WROOM-32E)
PINS_AVOIDED = {
    "GPIO6–11": "connected to the module's internal SPI flash",
    "GPIO0": "strapping (boot mode); used by the BOOT button",
    "GPIO2": "strapping (boot mode)",
    "GPIO12": "strapping (flash voltage, MTDI) — must be LOW at boot",
    "GPIO15": "strapping (boot log, MTDO)",
}

# ---------------------------------------------------------------------------
# Mechanical envelope and geometry (mm) — PROPOSED unless noted
# ---------------------------------------------------------------------------
ENVELOPE = dict(d_max=66.0, h_max=115.0, source="ESA CanSat reference envelope — ASSUMED pending SEVA FIRST rules")
GEOM = dict(
    shell_od=65.0, shell_wall=1.6, shell_len=95.6,          # non-structural sleeve, 0.4 mm axial float
    cap_d=65.0, cap_t=4.0, spigot_d=61.6, spigot_h=3.0,
    spine_w_web=43.0, spine_t=3.0, spine_h=90.0,            # spine between cap spigots
    rib_w=7.0, rib_t=7.0, rod_x=25.0,                        # two edge ribs carry the M3 rods
    rod_d=3.0, rod_len=112.5,
    yoke_l=58.0, yoke_w=10.0, yoke_t=4.0, bridle_x=16.0,     # aluminium recovery yoke, Y-bridle holes
    z_bottom=0.0,
)
OVERALL_H = 0.5 + 112.5            # rod top (bottom nut pocket offset + rod length) = 113.0 mm
PROOF_LOAD_N = 500                 # recovery attachment proof load (Belgium 2026–27 / Malta 2025–26); ESA 2022–23: 50 N


# ---------------------------------------------------------------------------
# Short part names used on diagrams (full BOM in design/bom.py)
# ---------------------------------------------------------------------------
NAMES = dict(
    mcu="ESP32-DevKitC V4 (ESP32-WROOM-32E)",
    env="Bosch BME280 breakout",
    imu="ST LSM6DSOX 6-DoF IMU breakout",
    sd="microSD breakout (3 V, SPI) + industrial microSD",
    radio="Ai-Thinker Ra-01H (SX1276), 866 MHz GFSK",
    batt="1 × 18650 Li-ion cell",
    prot="TP4056 module with DW01A + FS8205A protection",
    fuse="2.5 A-hold PTC resettable fuse (RGEF250)",
    switch="DPDT slide switch",
    reg="Pololu S7V8F3 3.3 V buck-boost",
    gs_radio="Ra-01H + ESP32-DevKitC receiver",
    gs_host="Laptop: Python stratos_gs software",
)
