"""
STRATOS power budget data — Rev A. Currents at the +3V3 rail unless noted.
src: VERIFIED (manufacturer datasheet/page, cited in the dossier references) |
     ASSUMED (engineering assumption, to be replaced by bench measurement with the INA219).
Duty cycle is the fraction of time at the 'active' current; the remainder is at the
'idle' current. Average = I_active·D + I_idle·(1 − D).
"""
from baseline import RADIO, RECORD_PERIOD_MS, TX_EVERY_N

FSK_AIRTIME_MS = (RADIO["preamble_bytes"] + RADIO["sync_bytes"] + RADIO["payload_bytes"] + 2) * 8 / RADIO["bitrate_bps"] * 1000
TX_DUTY = FSK_AIRTIME_MS / (RECORD_PERIOD_MS * TX_EVERY_N)

# name, ref, rail_V, I_active_mA, I_idle_mA, duty, I_peak_mA, src_active, src_idle, note
LOADS = [
    ("ESP32-WROOM-32E, modem-sleep 80 MHz, Wi-Fi/BT off", "U1", 3.3, 31.0, 31.0, 1.0, 68.0,
     "VERIFIED: ESP32 datasheet Table 4-2, modem-sleep 80 MHz 20–31 mA (upper value used)",
     "Peak = 240 MHz modem-sleep upper value 68 mA (if the clock is left at 240 MHz)",
     "Firmware must call setCpuFrequencyMhz(80) and keep Wi-Fi/BT off; Wi-Fi TX would add ≈239 mA (WROOM-32E Table 16)"),
    ("DevKitC board overhead (USB-UART, power LED, regulator back-feed)", "U1 board", 3.3, 10.0, 10.0, 1.0, 10.0,
     "ASSUMED: no official board-level figure exists", "ASSUMED", "Largest uncertainty: measure first with the INA219"),
    ("BME280 breakout (10 Hz normal mode)", "U2", 3.3, 1.0, 0.05, 0.10, 1.0,
     "ASSUMED active ≈1 mA during conversion (datasheet 3.6 µA at 1 Hz scales ≈10× at 10 Hz)", "VERIFIED order: 0.1–0.2 µA sleep; board LED/regulator unknown",
     "Breakout overhead unknown; 7Semi board to be measured"),
    ("LSM6DSOX breakout, accel + gyro high-performance 104 Hz", "U3", 3.3, 1.05, 1.05, 1.0, 1.05,
     "VERIFIED 0.55 mA (DS12814) + ASSUMED 0.5 mA board regulator/pull-up overhead", "same", "Adafruit 4438"),
    ("microSD card + 3 V breakout (1 flush per second)", "U5", 3.3, 100.0, 1.0, 0.02, 100.0,
     "VERIFIED limit: SD spec ≤100 mA in SPI mode (used as write current)", "ASSUMED 1 mA idle; ASSUMED 20 ms busy per 1 s flush",
     "Card-dependent; measure write bursts"),
    ("SX1276 radio (Ra-01H), GFSK +14 dBm on PA_BOOST", "U4", 3.3, 87.0, 1.6, TX_DUTY, 105.0,
     "VERIFIED 87 mA at +17 dBm PA_BOOST used as upper bound for +14 dBm (SX1276 Table 6)",
     "VERIFIED standby 1.6 mA; peak = Ra-01H max current 105 mA (Ai-Thinker spec)",
     f"Duty = {FSK_AIRTIME_MS:.2f} ms on air per 1 s"),
    ("Status LED (1 kΩ, toggles at 1 Hz)", "D2", 3.3, 1.4, 0.0, 0.5, 1.4,
     "COMPUTED (3.3 V − ≈1.9 V LED drop) / 1 kΩ", "—", ""),
    ("Recovery buzzer (off during flight)", "BZ1", 3.3, 30.0, 0.0, 0.0, 30.0,
     "ASSUMED 30 mA (5 V-rated electromagnetic buzzer; not measured at 3.3 V)", "—",
     "Landed mode: 100 ms per 2 s → 5 % duty (separate scenario)"),
]
# battery-side items (not on the 3.3 V rail)
BATT_SIDE = [
    ("Pololu S7V8F3 quiescent current", "U6", 0.1, "VERIFIED: < 0.1 mA no-load (Pololu page)"),
    ("Battery-sense divider 100 k + 100 k at 4.2 V", "R1/R2", 4.2 / 200000 * 1000, "COMPUTED"),
    ("DW01A protection IC operating current", "U7", 0.003, "SUPPLIER (DW01+G listing: 3 µA); TP4056 drain with no input NOT CONFIRMED"),
]
REG_EFF = 0.85            # ASSUMED within Pololu's stated 80–95 % typical range
V_BATT_NOM = 3.6          # nominal voltage (VERIFIED for Samsung INR18650-35E; typical of both candidate cells)
V_BATT_MIN = 3.3          # firmware safe-shutdown threshold (PROPOSED)
CELL_CAP_MIN_MAH = 2800   # design basis = BOM cell P10 (Molicel INR18650-P28A): SUPPLIER listing value; datasheet minimum NOT CONFIRMED
CELL_CAP_REF_MAH = 3350   # reference: VERIFIED minimum capacity of a genuine Samsung INR18650-35E (0.2C to 2.65 V)
USABLE_FRACTION = 0.80    # ASSUMED: capacity above 3.30 V, temperature, ageing
CONSERVATIVE_CAP_MAH = 2000  # ASSUMED fallback: unverified/counterfeit-risk cell
MISSION_H = 4.0
GNSS_OPTION = ("u-blox NEO-M8N (optional, not baseline), continuous tracking GPS+GLONASS", 30.0, 67.0,
               "VERIFIED: NEO-M8 data sheet Table 11")


def compute():
    rows = []
    for (n, ref, v, ia, ii, d, ip, sa, si, note) in LOADS:
        avg = ia * d + ii * (1 - d)
        rows.append(dict(name=n, ref=ref, v=v, ia=ia, ii=ii, d=d, ip=ip, avg=avg, p_mw=avg * v, sa=sa, si=si, note=note))
    rail_avg = sum(r["avg"] for r in rows)
    rail_peak = sum(r["ip"] for r in rows)
    rail_p = rail_avg * 3.3
    batt_extra = sum(b[2] for b in BATT_SIDE)
    i_batt = rail_p / REG_EFF / V_BATT_NOM + batt_extra
    usable = CELL_CAP_MIN_MAH * USABLE_FRACTION
    return dict(rows=rows, rail_avg=rail_avg, rail_peak=rail_peak, rail_p=rail_p, i_batt=i_batt,
                runtime_h=usable / i_batt, runtime_cons_h=CONSERVATIVE_CAP_MAH * USABLE_FRACTION / i_batt,
                runtime_ref_h=CELL_CAP_REF_MAH * USABLE_FRACTION / i_batt,
                ideal_h=CELL_CAP_MIN_MAH / i_batt,
                peak_batt=rail_peak * 3.3 / REG_EFF / 3.0)


if __name__ == "__main__":
    c = compute()
    for r in c["rows"]:
        print(f"{r['name'][:50]:50s} avg {r['avg']:7.3f} mA peak {r['ip']:6.1f}")
    print({k: round(v, 2) for k, v in c.items() if k != "rows"})
