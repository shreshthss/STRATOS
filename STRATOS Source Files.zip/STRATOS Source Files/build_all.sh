#!/usr/bin/env bash
# Regenerate every STRATOS deliverable from the design sources (Rev A).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-$ROOT/out}"; SRC="${2:-$ROOT/work/src}"; W="$ROOT/work"
mkdir -p "$OUT" "$SRC" "$W/sim" "$W/cad" "$W/charts"
cd "$ROOT/software"  && python3 -m stratos_gs.simulate --out "$W/sim" >/dev/null && python3 -m unittest discover -s tests
cd "$ROOT/firmware"  && gcc -std=c99 -Wall -Wextra -Werror -O2 -o "$W/test_packet_host" tests/test_packet_host.c common/stratos_packet.c \
                     && "$W/test_packet_host" > "$W/c_vectors.txt" && python3 tests/golden_vectors.py > "$W/py_vectors.txt" \
                     && diff "$W/c_vectors.txt" "$W/py_vectors.txt" && echo "C == Python vectors"
cd "$ROOT/design"    && python3 netlist.py
cd "$ROOT/cad"       && python3 stratos_cad.py "$W/cad" >/dev/null 2>&1 && python3 render_views.py "$OUT" \
                     && python3 mech_drawings.py "$OUT" "$SRC" "$W/cad/cad_report.json"
cd "$ROOT/schematic" && python3 stratos_schematic.py "$OUT" "$SRC" && python3 export_netlist.py "$OUT" "$SRC"
cd "$ROOT/diagrams"  && python3 make_architecture.py "$OUT" && python3 make_telemetry.py "$OUT" "$W/sim" \
                     && python3 make_state_diagram.py "$OUT" && python3 make_integrity_demo.py "$W/sim" "$OUT" \
                     && python3 make_gs_mockup.py "$W/sim" "$OUT" && python3 make_charts.py "$W/charts"
cd "$ROOT/software"  && python3 make_packet_md.py "$W/sim" "$OUT"
cd "$ROOT/sheets"    && python3 build_registers.py "$OUT" && python3 build_budgets.py "$OUT" "$SRC"
echo "done"
