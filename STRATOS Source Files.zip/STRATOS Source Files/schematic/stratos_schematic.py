"""
STRATOS electronics schematic generator (Rev A, PROPOSED).

Draws the schematic from design/netlist.py with schemdraw, so every pin and
net shown is exactly the netlist used for the pin map, BOM references and the
KiCad-format netlist. Output: 3-sheet A3 PDF, one PNG and one SVG per sheet.
Net labels (flags) with the same name are electrically connected.
"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "design"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import schemdraw
import schemdraw.elements as elm
from netlist import COMP, check
from baseline import REV, DATE, TEAM

schemdraw.use("matplotlib")
plt.rcParams["font.family"] = "DejaVu Sans"
OUT = sys.argv[1]
SRC = sys.argv[2] if len(sys.argv) > 2 else OUT
assert not check(), check()

POWER_NETS = {"+3V3", "VSYS", "VBAT_P", "VBAT_PROT", "VREG", "CELL_P"}
NETCOL = lambda n: "#B3261E" if n in POWER_NETS else ("#1B2733" if n == "GND" else "#1F4E8C")


def sheet(title, number, total):
    fig = plt.figure(figsize=(16.54, 11.69))       # A3 landscape
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 42.0); ax.set_ylim(0, 29.7); ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(plt.Rectangle((0.6, 0.6), 40.8, 28.5, fill=False, lw=1.4, ec="#333"))
    # title block
    x0, y0, w, h = 27.4, 0.6, 14.0, 3.3
    ax.add_patch(plt.Rectangle((x0, y0), w, h, fill=False, lw=1.2, ec="#333"))
    for yy in (y0 + 1.1, y0 + 2.2):
        ax.plot([x0, x0 + w], [yy, yy], color="#333", lw=0.8)
    ax.text(x0 + 0.25, y0 + 2.6, f"STRATOS — {title}", fontsize=9.5, weight="bold")
    ax.text(x0 + 0.25, y0 + 1.5, f"Team {TEAM} · SEVA FIRST Innovation Challenge 2026", fontsize=8.5)
    ax.text(x0 + 0.25, y0 + 0.4, f"Rev {REV} · {DATE} · Sheet {number} of {total} · generated from design/netlist.py",
            fontsize=8)
    ax.text(0.9, 28.55, "PROPOSED DESIGN — NOT YET BUILT OR TESTED. Net labels of the same name are connected. "
            "Module outlines are breakout boards; pin numbers are this design's own connector order.",
            fontsize=8.5, color="#B26A00", weight="bold")
    d = schemdraw.Drawing(canvas=ax)
    d.config(fontsize=8.5, unit=1.6, lw=1.1)
    return fig, ax, d


TH = {"left": 180, "right": 0, "up": 90, "down": 270}


def tag(d, at, net, direction):
    """Short stub then a net flag. Vertical stubs end in a horizontal flag so text stays readable."""
    if net is None:
        d += elm.Line().at(at).length(0.35).theta(TH[direction])
        d += elm.Label().label("×", fontsize=11, color="#888")
        return
    ln = elm.Line().at(at).length(0.5).theta(TH[direction])
    d += ln
    flag_dir = direction if direction in ("left", "right") else "right"
    if direction in ("up", "down"):
        d += elm.Dot(radius=0.06).at(ln.end)
    d += elm.Tag(width=max(1.4, 0.2 * len(net) + 0.5)).at(ln.end).theta(TH[flag_dir]).label(net, fontsize=7.5, color=NETCOL(net))


def ic(d, ref, xy, left, right, width=4.2, title=None):
    c = COMP[ref]
    pins = []
    for pid in left[::-1]:      # schemdraw stacks pins bottom-up; reverse so the first pin is at the top
        pins.append(elm.IcPin(name=c["pins"][pid][0], pin=pid, side="left", anchorname=f"p{pid}"))
    for pid in right[::-1]:
        pins.append(elm.IcPin(name=c["pins"][pid][0], pin=pid, side="right", anchorname=f"p{pid}"))
    box = elm.Ic(pins=pins, pinspacing=0.75, edgepadH=0.5, w=width, lsize=7.5, plblsize=6.5, leadlen=0.6)
    box = box.at(xy).theta(0).label(f"{ref}  {title or c['value']}", "top", fontsize=9, ofst=0.25)
    d += box
    for pid in left:
        tag(d, getattr(box, f"p{pid}"), c["pins"][pid][1], "left")
    for pid in right:
        tag(d, getattr(box, f"p{pid}"), c["pins"][pid][1], "right")
    return box


def two_term(d, ref, start, direction, element, net_a, net_b, label=None, length=2.2):
    """Two-terminal part with net flags on both ends."""
    th = {"right": 0, "left": 180, "up": 90, "down": 270}[direction]
    opp = {"right": "left", "left": "right", "up": "down", "down": "up"}[direction]
    e = element.at(start).theta(th).length(length).label(label or f"{ref}\n{COMP[ref]['value']}", fontsize=7.5)
    d += e
    tag(d, e.start, net_a, opp)
    tag(d, e.end, net_b, direction)
    return e


def note(ax, x, y, lines, size=7.8, color="#333"):
    for i, s in enumerate(lines):
        ax.text(x, y - i * 0.45, s, fontsize=size, color=color)


figs = []
# ============================================================== Sheet 1: power
fig, ax, d = sheet("Power and regulation", 1, 3)
ax.text(1.5, 27.3, "Battery assembly (cell on face B; U7 on face A below the carrier)", fontsize=10, weight="bold")
two_term(d, "BT1", (3.5, 19.6), "up", elm.BatteryCell(), "CELL_N", "CELL_P", "BT1  18650 Li-ion\n3.0–4.2 V", length=2.6)
ic(d, "U7", (11.5, 20.6), ["1", "2"], ["3", "4", "5"], width=4.4, title="TP4056 + DW01A module")
note(ax, 1.5, 17.6, ["U7: DW01A over-charge / over-discharge / over-current protection with FS8205A switch.",
                     "Its TP4056 USB-C charge input is used only for supervised bench charging with the",
                     "shell removed; preferred charging is in an external 18650 charger."])

ax.text(16.5, 27.3, "Carrier power entry and fuse", fontsize=10, weight="bold")
ic(d, "J1", (20.0, 24.0), ["1", "2"], [], width=2.2, title="JST-XH 2p")
two_term(d, "F1", (20.5, 18.6), "right", elm.Fuse(), "VBAT_PROT", "VBAT_P", "F1  PTC 2.5 A hold\n(RGEF250)", length=3.0)

ax.text(26.0, 27.3, "Master switch SW1 (bottom cap) via J4", fontsize=10, weight="bold")
ic(d, "J4", (29.0, 22.6), ["1", "2", "3", "4"], [], width=2.2, title="JST-XH 4p")
two_term(d, "SW1", (34.0, 25.0), "right", elm.Switch(), "VBAT_P", "VSYS", "SW1A  (COM → NO)", length=2.4)
two_term(d, "SW1", (34.0, 22.5), "right", elm.Switch(), "VREG", "+3V3", "SW1B  (COM → NO)", length=2.4)
note(ax, 26.0, 20.6, ["DPDT: pole A connects the protected cell to VSYS;",
                      "pole B connects the regulator output to the +3V3 rail.",
                      "OFF isolates the regulator so the ESP32 USB port can",
                      "power the board for programming (one supply at a time).",
                      "NC contacts of both poles are unused."])

ax.text(1.5, 14.4, "3.3 V regulator and bulk capacitance", fontsize=10, weight="bold")
ic(d, "U6", (6.0, 10.6), ["1", "2"], ["3", "4"], width=4.0, title="Pololu S7V8F3 (3.3 V buck-boost)")
two_term(d, "C2", (14.5, 12.3), "down", elm.Capacitor(), "VSYS", "GND", "C2 10 µF", length=2.0)
two_term(d, "C1", (19.0, 12.3), "down", elm.Capacitor(polar=True), "+3V3", "GND", "C1 100 µF\n16 V", length=2.0)
note(ax, 1.5, 7.2, ["U6 EN left open (internal pull-up enables the regulator; confirm on the Pololu page).",
                    "C1 sits at the radio connector end of the +3V3 rail to supply transmit peaks."])

ax.text(24.0, 14.4, "Battery-voltage sense (ADC1_CH6)", fontsize=10, weight="bold")
two_term(d, "R1", (26.0, 12.6), "down", elm.Resistor(), "VSYS", "VBAT_SENSE", "R1 100 kΩ 1 %", length=2.0)
two_term(d, "R2", (31.0, 12.6), "down", elm.Resistor(), "VBAT_SENSE", "GND", "R2 100 kΩ 1 %", length=2.0)
two_term(d, "C3", (36.0, 12.6), "down", elm.Capacitor(), "VBAT_SENSE", "GND", "C3 100 nF", length=2.0)
note(ax, 24.0, 8.0, ["VBAT_SENSE = VSYS / 2  (2.1 V at 4.2 V).",
                     "Divider draws 21 µA at 4.2 V.",
                     "Read with 11 dB attenuation on IO34 (ADC1),",
                     "calibrated against a multimeter."])
d.draw(show=False)
figs.append(("Power", fig))

# ============================================================== Sheet 2: controller
fig, ax, d = sheet("Controller, storage, indicators", 2, 3)
ax.text(1.5, 27.3, "U1 ESP32-DevKitC V4 on two 1×19 female headers (left = 3V3 end header, right = GND end header)", fontsize=10, weight="bold")
u1 = ic(d, "U1", (8.0, 11.5), [f"L{i}" for i in range(1, 20)], [f"R{i}" for i in range(1, 20)], width=9.0,
        title="ESP32-DevKitC V4 (ESP32-WROOM-32E)")
note(ax, 1.5, 3.2, ["× = not connected. IO12 and IO15 (strapping), IO0/IO2 (boot), SD0–SD3/CMD/CLK (internal flash) are left unused.",
                    "IO16/IO17 reserved for an optional GNSS receiver (UART2), not fitted in the baseline. TX/RX = USB programming only."])
ax.text(24.0, 27.3, "microSD (VSPI)", fontsize=10, weight="bold")
ic(d, "U5", (27.0, 20.2), ["1", "2", "3", "4", "5", "6", "7"], [], width=3.6, title="microSD breakout, 3 V only")
ax.text(32.6, 27.3, "Boot-safe pull-ups", fontsize=10, weight="bold")
two_term(d, "R4", (34.0, 26.0), "down", elm.Resistor(), "+3V3", "SD_CS", "R4 10 kΩ", length=1.8)
two_term(d, "R5", (38.6, 26.0), "down", elm.Resistor(), "+3V3", "RADIO_NSS", "R5 10 kΩ", length=1.8)
two_term(d, "R8", (34.0, 21.0), "down", elm.Resistor(), "+3V3", "I2C_SDA", "R8 4.7 kΩ\nDNP*", length=1.8)
two_term(d, "R9", (38.6, 21.0), "down", elm.Resistor(), "+3V3", "I2C_SCL", "R9 4.7 kΩ\nDNP*", length=1.8)
note(ax, 32.6, 16.3, ["R4 holds IO5 (strapping pin) high at boot", "and keeps the card deselected; R5 keeps the",
                      "radio deselected. *DNP = do not populate:", "fit only if the breakouts lack I2C pull-ups."])
ax.text(24.5, 13.6, "Recovery beeper", fontsize=10, weight="bold")
two_term(d, "R6", (24.8, 11.8), "right", elm.Resistor(), "BUZZER_EN", "Q1_B", "R6 1 kΩ", length=2.0)
q1 = elm.BjtNpn(circle=True).at((31.0, 10.4)).label("Q1\nBC547", loc="right", fontsize=7.5)
d += q1
tag(d, q1.base, "Q1_B", "left")
tag(d, q1.emitter, "GND", "down")
tag(d, q1.collector, "BZ_N", "up")
ic(d, "BZ1", (36.3, 11.4), ["1", "2"], [], width=2.0, title="Buzzer")
two_term(d, "D1", (39.6, 10.4), "up", elm.Diode(), "BZ_N", "+3V3", "D1\n1N4148", length=1.8)
ax.text(24.5, 6.2, "Status LED", fontsize=10, weight="bold")
two_term(d, "R7", (24.8, 5.0), "right", elm.Resistor(), "STATUS_LED", "LED_A", "R7 1 kΩ", length=2.0)
two_term(d, "D2", (32.8, 5.0), "right", elm.LED(), "LED_A", "GND", "D2 LED", length=2.0)
d.draw(show=False)
figs.append(("Controller", fig))

# ============================================================== Sheet 3: sensors and radio
fig, ax, d = sheet("Sensors (I2C) and radio (HSPI)", 3, 3)
ax.text(1.5, 27.3, "Sensor bus (J2 on carrier → U2, U3 on face B)", fontsize=10, weight="bold")
ic(d, "J2", (5.0, 22.5), ["1", "2", "3", "4", "5"], [], width=2.2, title="JST-XH 5p")
ic(d, "U2", (12.5, 23.0), ["1", "2", "3", "4"], [], width=3.6, title="BME280 breakout")
ic(d, "U3", (21.0, 21.9), ["1", "2", "3", "4", "5"], ["6", "7", "8", "9"], width=3.6, title="Adafruit LSM6DSOX (4438)")
note(ax, 1.5, 17.8, ["I2C address: BME280 0x76 or 0x77 (set by the breakout's SDO strap — read the actual board);",
                     "LSM6DSOX 0x6A (Adafruit default). Bus at 400 kHz; total pull-up resistance to be measured (R8/R9 DNP).",
                     "INT1 = IMU data-ready, wired to input-only IO39 (no internal pull needed: push-pull output)."])
ax.text(1.5, 14.6, "Radio (J3 SPI + J5 control on carrier → U4 on face B)", fontsize=10, weight="bold")
ic(d, "J3", (5.0, 9.6), ["1", "2", "3", "4", "5"], [], width=2.2, title="JST-XH 5p")
ic(d, "J5", (5.0, 4.6), ["1", "2", "3", "4"], [], width=2.2, title="JST-XH 4p")
u4 = ic(d, "U4", (15.5, 6.2), ["1", "2", "3", "4", "5", "6", "7", "8", "9"], ["10", "11", "12", "13", "14"], width=5.2,
        title="Ai-Thinker Ra-01H (SX1276) on adapter")
ant = elm.Antenna().at((26.0, 10.3)).label("E1  868 MHz helical\n(soldered to ANT pad)", loc="right", fontsize=7.5)
d += ant
tag(d, (26.0, 10.3), "RF_ANT", "down")
note(ax, 24.0, 7.0, ["Radio configured for GFSK, 866.0 MHz, 38.4 kb/s, ±40 kHz,",
                     "+14 dBm on PA_BOOST (see dossier §4.6 for limits).",
                     "C1 (sheet 1) is placed at the J3 end of the +3V3 rail.",
                     "DIO2–DIO5 unused. Keep the RF feed short; antenna at",
                     "least 30 mm from the cell and ESP32 module."])
d.draw(show=False)
figs.append(("SensorsRadio", fig))

os.makedirs(OUT, exist_ok=True)
with PdfPages(os.path.join(OUT, "STRATOS_Electronics_Schematic.pdf")) as pdf:
    for name, f in figs:
        pdf.savefig(f)
for i, (name, f) in enumerate(figs, start=1):
    f.savefig(os.path.join(OUT, f"STRATOS_Electronics_Schematic_Sheet{i}.png"), dpi=170)
    f.savefig(os.path.join(SRC, f"STRATOS_Schematic_Sheet{i}_{name}.svg"))
print("ok")
