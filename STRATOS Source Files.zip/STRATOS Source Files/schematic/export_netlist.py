"""Export the STRATOS netlist (design/netlist.py) as
  * STRATOS_Netlist.net   KiCad-format netlist (S-expression, written directly)
  * STRATOS_Netlist.json  machine-readable netlist
  * STRATOS_Pin_Mapping.csv   ESP32 pin map with module pins and signal directions
  * STRATOS_Component_List.csv  reference list
The .net file can be imported into KiCad's PCB editor (File → Import → Netlist)
once footprints are assigned; a native .kicad_sch has not been drawn yet.
"""
import csv, json, os, sys, datetime
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "design"))
from netlist import COMP, nets, check
from baseline import PINS, REV, DATE

OUT, SRC = sys.argv[1], sys.argv[2]
assert not check()

FOOTPRINT_HINT = {
    "U1": "2 × 1×19 female header, 2.54 mm, rows 22.86 mm apart", "U2": "module (4-pin 2.54 mm header)",
    "U3": "module (2.54 mm header)", "U4": "module on adapter (2.54 mm header)", "U5": "module (2.54 mm header)",
    "U6": "module (2.54 mm header)", "U7": "module (solder pads)", "BT1": "Keystone 1043 holder",
    "J1": "JST_XH_B2B-XH-A", "J2": "JST_XH_B5B-XH-A", "J3": "JST_XH_B5B-XH-A", "J4": "JST_XH_B4B-XH-A",
    "J5": "JST_XH_B4B-XH-A", "Q1": "TO-92", "D1": "DO-35", "D2": "LED_THT_D5.0mm", "C1": "CP_Radial_D6.3mm",
    "F1": "Radial PTC", "SW1": "panel slide switch (off-board)", "BZ1": "Buzzer_D12mm", "E1": "solder pad",
}


def q(s):
    return '"' + str(s).replace('"', "'") + '"'


def kicad_net():
    L = ["(export (version \"E\")",
         f"  (design (source \"design/netlist.py\") (date {q(datetime.date.today().isoformat())}) (tool \"STRATOS generator\")",
         f"    (sheet (number \"1\") (name \"/\") (tstamps \"/\") (title_block (title \"STRATOS payload\") (rev {q(REV)}) (date {q(DATE)}))))",
         "  (components"]
    for ref, c in COMP.items():
        L.append(f"    (comp (ref {q(ref)}) (value {q(c['value'])}) (footprint {q(FOOTPRINT_HINT.get(ref, ''))})")
        L.append(f"      (fields (field (name \"Description\") {q(c['part'])}) (field (name \"Location\") {q(c['location'])})))")
    L.append("  )")
    L.append("  (nets")
    for i, (net, members) in enumerate(sorted(nets().items()), start=1):
        L.append(f"    (net (code \"{i}\") (name {q(net)})")
        for ref, pid, pname in members:
            L.append(f"      (node (ref {q(ref)}) (pin {q(pid)}) (pinfunction {q(pname)}))")
        L.append("    )")
    L.append("  )")
    L.append(")")
    return "\n".join(L)


with open(os.path.join(SRC, "STRATOS_Netlist.net"), "w") as f:
    f.write(kicad_net())
with open(os.path.join(SRC, "STRATOS_Netlist.json"), "w") as f:
    json.dump({"revision": REV, "date": DATE,
               "components": {r: {"value": c["value"], "part": c["part"], "location": c["location"],
                                  "pins": {p: {"name": n, "net": net} for p, (n, net) in c["pins"].items()}}
                              for r, c in COMP.items()},
               "nets": {n: [f"{r}.{p}" for r, p, _ in m] for n, m in sorted(nets().items())}}, f, indent=1)

# ---- pin map: one row per ESP32 signal, with the far-end pin(s) on the modules
allnets = nets()
rows = []
for ref, sig, gpio, label, direction, bus, remark in PINS:
    far = [f"{r}.{p} {n}" for r, p, n in allnets.get(sig, []) if r not in ("U1",)]
    u1pin = [p for p, (n, net) in COMP["U1"]["pins"].items() if net == sig] or \
            [p for p, (n, net) in COMP["U1"]["pins"].items() if n.replace(" ", "").startswith(label.split(" ")[0].replace(" ", ""))]
    rows.append({
        "Signal (net)": sig, "ESP32 GPIO": gpio, "DevKitC pin label": label,
        "DevKitC header position": ", ".join(("left header (3V3 end) pin " if p.startswith("L") else "right header (GND end) pin ") + p[1:] for p in u1pin),
        "Direction (from ESP32)": {"out": "Output", "in": "Input", "bidir": "Bidirectional"}[direction],
        "Bus / peripheral": bus,
        "Connects to (ref.pin name)": "; ".join(far) if far else "not connected (reserved)",
        "Via connector": ", ".join(sorted({r for r, _p, _n in allnets.get(sig, []) if r.startswith("J")})) or "on carrier",
        "Electrical level": "3.3 V CMOS" if bus not in ("ADC1_CH6",) else "analogue 0–2.1 V (11 dB attenuation)",
        "Notes": remark,
    })
# power and ground rows
for net, desc in (("+3V3", "Regulated 3.3 V rail via SW1 pole B"), ("GND", "Common ground"),
                  ("VSYS", "Switched battery 3.0–4.2 V"), ("VBAT_P", "Protected, fused cell voltage before SW1"),
                  ("VREG", "Regulator output before SW1 pole B")):
    rows.append({"Signal (net)": net, "ESP32 GPIO": "", "DevKitC pin label": "3V3 / GND" if net in ("+3V3", "GND") else "",
                 "DevKitC header position": ", ".join(("left " if p.startswith("L") else "right ") + p[1:] for p, (n, nn) in COMP["U1"]["pins"].items() if nn == net),
                 "Direction (from ESP32)": "Power", "Bus / peripheral": "Power",
                 "Connects to (ref.pin name)": "; ".join(f"{r}.{p} {n}" for r, p, n in allnets.get(net, []) if r != "U1"),
                 "Via connector": ", ".join(sorted({r for r, _p, _n in allnets.get(net, []) if r.startswith("J")})),
                 "Electrical level": "power", "Notes": desc})
with open(os.path.join(OUT, "STRATOS_Pin_Mapping.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)

with open(os.path.join(SRC, "STRATOS_Component_List.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["Ref", "Value", "Description", "Location", "Connected pins (pin: name → net)"])
    for r, c in COMP.items():
        w.writerow([r, c["value"], c["part"], c["location"],
                    "; ".join(f"{p}:{n}→{net or 'NC'}" for p, (n, net) in c["pins"].items())])
print("ok", len(rows), "pin-map rows")
