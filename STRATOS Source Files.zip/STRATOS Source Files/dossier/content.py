"""Build content.json for the STRATOS engineering dossier (rendered by render.js)."""
import json, os, re, sys
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "design"))
sys.path.insert(0, os.path.join(ROOT, "software"))
import baseline as BL
import power as PW
import mass as MS
import bom as B
import registers as RG
import netlist as NL
import layout as LY
from stratos_gs.reconcile import reconcile
from stratos_gs.packet import FIELDS, STATUS_BITS
from stratos_gs.radio import lora_time_on_air_ms, fsk_time_on_air_ms, carson_bandwidth_khz, fspl_db

OUT = os.path.join(ROOT, "out"); W = os.path.join(ROOT, "work"); CH = os.path.join(W, "charts"); SRC = os.path.join(W, "src")
cad = json.load(open(os.path.join(W, "cad", "cad_report.json")))
pw = PW.compute()
mrows, mtot = MS.budget()
sim = reconcile(os.path.join(W, "sim", "LOG_0007.CSV"), os.path.join(W, "sim", "ground_accepted.csv"), os.path.join(W, "sim", "ground_rejected.csv"))
s7 = sim["sessions"][7]
R = BL.RADIO
fsk = fsk_time_on_air_ms(44, R["bitrate_bps"], R["preamble_bytes"], R["sync_bytes"])
lora = lora_time_on_air_ms(44)
G = BL.GEOM

# cost numbers (same formulas as the workbook)
def unit(row):
    price, cur, gst = row[6], row[7], row[8]
    if price is None:
        return None
    return price * B.FX_USD_INR if cur == "USD" else (price * (1 + B.GST_RATE) if gst == "excl" else price)
cat = {}
for row in B.BOM:
    u = unit(row)
    if u is not None:
        cat[row[1]] = cat.get(row[1], 0) + u * row[5]
allow = sum(a[2] for a in B.ALLOWANCES)
subtotal = sum(cat.values()) + allow
total = subtotal * (1 + B.CONTINGENCY_PCT)
payload_core = sum(cat[k] for k in ("Payload – electronics", "Payload – power", "Payload – passives", "Payload – interconnect"))
petg_used = 902.0 / 1000 * 130
payload_prod = payload_core + petg_used + cat["Recovery"] + 300 + 150 + 2500
fmt = lambda v: f"₹{v:,.0f}"

blocks = []
TOC_ENTRIES = []
_tp = os.path.join(HERE, "toc_pages.json")
TOC_PAGES = json.load(open(_tp)) if os.path.exists(_tp) else {}
def _anchor(level, x):
    a = f"_Toc{len(TOC_ENTRIES) + 1:04d}"
    TOC_ENTRIES.append({"level": level, "text": x, "anchor": a, "page": TOC_PAGES.get(a, 0)})
    return a
CHAP = ["0"]; TABN = {}; LABELS = {}
def H1(x, pb=True):
    m = re.match(r"(\d+)\s", x) or re.match(r"Appendix ([A-Z])\s", x)
    CHAP[0] = m.group(1) if m else "0"
    blocks.append({"t": "h1", "x": x, "pb": pb, "anchor": _anchor(1, x)})
def H2(x): blocks.append({"t": "h2", "x": x, "anchor": _anchor(2, x)})
def H3(x): blocks.append({"t": "h3", "x": x})
def P(x): blocks.append({"t": "p", "x": x})
def SM(x): blocks.append({"t": "small", "x": x})
def NOTE(x): blocks.append({"t": "note", "x": x})
def BUL(*items): blocks.append({"t": "bullets", "items": list(items)})
def NUM(*items, ref="num"): blocks.append({"t": "numbers", "items": list(items), "ref": ref})
def TCAP(x, key=None):
    x = re.sub(r"^Table \S+\s+", "", x)
    TABN[CHAP[0]] = TABN.get(CHAP[0], 0) + 1
    lab = f"{CHAP[0]}-{TABN[CHAP[0]]}"
    if key:
        LABELS[key] = lab
    blocks.append({"t": "tcap", "x": f"Table {lab}  {x}"})
def TAB(header, rows, widths, size=16, highlight=None):
    blocks.append({"t": "table", "header": header, "rows": [[str(c) for c in r] for r in rows], "widths": widths, "size": size,
                   "highlight": highlight or []})
DOCX_IMG = os.path.join(W, "docx_img")
os.makedirs(DOCX_IMG, exist_ok=True)
def docx_image(path, maxw=2000):
    """Down-sample very large figures for the DOCX only (full-resolution originals are delivered separately)."""
    im = Image.open(path).convert("RGBA")
    if im.size[0] > maxw:
        im = im.resize((maxw, round(im.size[1] * maxw / im.size[0])), Image.LANCZOS)
    bg = Image.new("RGB", im.size, "white")
    bg.paste(im, mask=im.split()[3])
    out = os.path.join(DOCX_IMG, os.path.basename(path))
    if not os.path.exists(out) or os.path.getmtime(out) < os.path.getmtime(path):
        bg.quantize(colors=256, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.FLOYDSTEINBERG).save(out, optimize=True)
    return os.path.abspath(out), im.size
def IMG(path, cap, scale=1.0, alt=None, maxh=None, maxw=2000):
    p2, px = docx_image(path, maxw)
    b = {"t": "img", "path": p2, "px": list(px), "scale": scale, "alt": alt or cap}
    if maxh:
        b["maxh"] = maxh
    blocks.append(b)
    blocks.append({"t": "cap", "x": cap})
def CODE(x): blocks.append({"t": "code", "x": x})

sections = []
def new_section(orientation="portrait", title_page=False):
    global blocks
    blocks = []
    sections.append({"orientation": orientation, "titlePage": title_page, "blocks": blocks})

# =========================================================================== COVER
new_section(title_page=True)
blocks.append({"t": "cover", "subtitle": "Engineering Dossier — environmental sensing, onboard logging, telemetry and recovery payload",
               "tagline": "SEVA FIRST Innovation Challenge 2026 · Team Nothingburger",
               "image": docx_image(os.path.join(OUT, "STRATOS_Main_Assembly.png"))[0],
               "px": list(docx_image(os.path.join(OUT, "STRATOS_Main_Assembly.png"))[1]),
               "lines": ["**Team:** Nothingburger (member names to be added by the team)",
                         "**Competition:** SEVA FIRST Innovation Challenge 2026 — entry described by the team as the *Diploma & Higher Education* track; "
                         "see §1.3 for how this maps onto the official levels and tracks",
                         "**Document:** STRATOS-ED-001, Revision A, 24 October 2026",
                         "**Project type:** CanSat-inspired environmental sensing, telemetry, onboard data logging and recovery system"],
               "status": "STATUS: PROPOSED ENGINEERING DESIGN. No STRATOS hardware has been purchased, assembled, integrated or flown. "
                         "The software pipeline has been exercised with synthetic (simulated) data only. The rendered assembly above is a CAD model, not a photograph."})

# =========================================================================== FRONT MATTER
new_section()
H1("Document control", pb=False)
TCAP("Revision history")
TAB(["Revision", "Date", "Description", "Status"],
    [["A", "24 Oct 2026", "First complete engineering dossier: requirements, architecture, mechanical, electronics, firmware/telemetry, "
      "calculations, BOM, verification plan, risks, roadmap", "Draft for team review"]], [10, 14, 60, 16])
P("**How this dossier was prepared.** The dossier, its drawings, schematic, spreadsheets and the software prototype were generated from the "
  "team's project brief with AI assistance (Claude), working from manufacturer datasheets and supplier pages read on 24 October 2026. "
  "Every number is traceable to a cited source, a stated assumption or a calculation in the accompanying files. **The team must review, "
  "correct and take ownership of the content before submission**, and should check the competition's rules on declaring AI assistance.")
P("**Status vocabulary used throughout.** **VERIFIED** — taken from a manufacturer datasheet or official page (cited). **SUPPLIER** — from a "
  "retailer listing. **ASSUMED** — an engineering assumption to be measured or confirmed. **PROPOSED** — a design decision made here, not yet "
  "built or tested. **SIMULATED** — produced by software from synthetic data. **ESTIMATE / PRELIMINARY** — to be replaced by measurement.")
TCAP("Table 0-1  Deliverable files that accompany this dossier")
TAB(["File", "Contents"], [
    ["STRATOS_Engineering_Dossier.docx", "This report (editable)"],
    ["STRATOS_Main_Assembly.png", "Labelled CAD views of the proposed payload"],
    ["STRATOS_Mechanical_Drawings.pdf", "4 sheets: general arrangement, internal arrangement + section, exploded view + parts list, part details"],
    ["STRATOS_System_Architecture.svg", "Functional block diagram (editable SVG; PNG copy included)"],
    ["STRATOS_Electronics_Schematic.pdf", "3-sheet schematic generated from the netlist (PNG copies included)"],
    ["STRATOS_Pin_Mapping.csv", "Every ESP32 signal, pin, direction, bus and far-end connection"],
    ["STRATOS_Telemetry_Architecture.svg", "Onboard logging, telemetry, ground validation and reconciliation (plus sequence diagram)"],
    ["STRATOS_Packet_Format.md", "Packet and onboard-log specification with a simulated example"],
    ["STRATOS_Data_Integrity_Demonstration.png", "Onboard vs received vs reconciled records (simulated)"],
    ["STRATOS_Firmware_State_Diagram.svg", "Firmware states, transitions and error handling"],
    ["STRATOS_Power_Budget.xlsx / _Storage_Budget.xlsx", "Formula-driven budgets with sources"],
    ["STRATOS_BOM.xlsx", "Itemised BOM with sourced prices, summary, pitch table"],
    ["STRATOS_Ground_Station_Mockup.png", "Proposed interface drawn from the prototype software state (simulated data)"],
    ["STRATOS_Risk_Register.xlsx / _Development_Roadmap.xlsx / _Test_Verification_Matrix.xlsx", "Registers and plans"],
    ["STRATOS_Reference_Footage_Register.xlsx", "Attribution and recommendations for the third-party video clips"],
    ["STRATOS_Source_Files.zip", "Python/C sources, CAD (STEP/STL, CadQuery), schematic generator, KiCad-format netlist, diagram generators, calculations workbook"],
], [38, 62], size=15)

H1("Executive summary")
P("STRATOS is a proposed can-sized payload that measures air temperature, humidity, pressure and motion, keeps a complete copy of every "
  "measurement on board, sends a structured subset to a ground station by radio, and — after recovery — proves which data arrived, which "
  "did not and why. Its distinguishing idea is **data integrity as a design objective**: the payload record and the ground record are linked "
  "by session IDs, record and packet sequence numbers, CRC checks and an explicit reconciliation procedure, so that losses are measured "
  "rather than hidden behind a live graph.")
TCAP("Table 0-2  Baseline design at a glance (Rev A)")
TAB(["Item", "Baseline (PROPOSED)"], [
    ["Controller", "Espressif ESP32-DevKitC V4 (ESP32-WROOM-32E), Wi-Fi/Bluetooth off, CPU at 80 MHz"],
    ["Sensors", "Bosch BME280 (T, RH, P) and ST LSM6DSOX 6-DoF IMU on I2C; battery voltage on ADC1"],
    ["Onboard storage", "microSD (3 V SPI breakout), one CSV line per 10 Hz record, each line protected by its own CRC-16"],
    ["Telemetry", f"Ai-Thinker Ra-01H (Semtech SX1276), GFSK {R['freq_mhz']:.1f} MHz, {R['bitrate_bps']/1000:.1f} kb/s, +{R['tx_power_dbm']} dBm, 1 packet/s, "
                  f"44-byte packet with CRC-16, {fsk['t_total_ms']:.1f} ms on air ({fsk['t_total_ms']/10:.2f} % duty)"],
    ["Ground station", "Second Ra-01H + ESP32 receiver over USB to a laptop running the stratos_gs Python software"],
    ["Power", f"One 18650 Li-ion cell, DW01A protection, PTC fuse, DPDT master switch, Pololu S7V8F3 3.3 V buck-boost; "
              f"estimated {pw['i_batt']:.0f} mA average → ≈{pw['runtime_h']:.0f} h with the BOM cell (2,800 mAh listing value, 80 % usable) against a 4 h requirement"],
    ["Structure", f"PETG caps, spine and sleeve; two M3 stainless rods carry recovery loads; Ø{G['cap_d']:.0f} × {BL.OVERALL_H:.0f} mm, "
                  f"inside the assumed Ø66 × 115 mm envelope"],
    ["Recovery", f"Ø0.33 m flat circular parachute on a two-leg bridle; ≈9 m/s at the 325 g design mass (calculated, C_D assumed 0.75)"],
    ["Mass / cost", f"≈{mtot:.0f} g before ballast (estimate); payload production ≈{fmt(payload_prod)}, total procurement incl. "
                    f"ground station, spares and 15 % contingency ≈{fmt(total)} (prices read 24 Oct 2026)"],
], [22, 78], size=16)
P("**What exists today.** A complete design package generated from one set of design values, so the documents agree with each other: requirements, architecture, CAD model and dimensioned drawings, "
  "a netlist-generated schematic and pin map, power/storage/mass/link/parachute calculations, an itemised BOM with sourced prices, a risk "
  "register, a roadmap and a verification matrix. A working **software prototype** of the packet codec, ground-station validation and "
  "post-mission reconciliation has been built and tested (8 unit tests pass; a C implementation of the packet code matches the Python "
  "byte-for-byte). It has only ever processed **synthetic data**.")
P("**What does not exist yet.** No component has been purchased; no hardware has been assembled; no sensor, storage, radio, power, "
  "mechanical, recovery or flight test has been performed. The payload firmware is an uncompiled draft.")
NOTE("Three findings need the team's attention now (details in §1.3): (1) the SEVA FIRST portal's home page gives **24 October 2026** as the "
     "end of the submission window while its 'indicative' timeline says 6 November; (2) the portal found is the **South Zone** edition and "
     "its registration list does not include Madhya Pradesh; (3) no hardware rules are published, so the ESA CanSat envelope is used here "
     "as a stated assumption.")

blocks.append({"t": "toc", "entries": TOC_ENTRIES,
               "note": "Page numbers as generated for this revision. In Word, right-click the list and choose *Update Field* after editing."})

H1("Current project maturity statement")
P("Progress is stated as completed, evidenced items — not as a percentage.")
TCAP("Table 0-3  Maturity by work area (24 Oct 2026)")
TAB(["Work area", "Status", "Evidence"], [
    ["Concept, mission and requirements", "Draft complete — team review pending", "Chapter 1; TVM workbook"],
    ["System architecture and interfaces", "Draft complete", "System architecture SVG; netlist; pin map"],
    ["Mechanical concept and drawings", "Draft complete (PRELIMINARY module outlines)", "CAD model, STEP files, 4 drawing sheets, CAD check report"],
    ["Electronics schematic", "Draft complete; not reviewed by an electrical engineer; no PCB", "3-sheet schematic, KiCad-format netlist"],
    ["Firmware", "Architecture and state machine defined; packet/log code host-tested; main sketch **uncompiled**", "State diagram; firmware/ folder"],
    ["Ground-station and reconciliation software", "Prototype complete — **synthetic data only**", "8 unit tests; simulated reconciliation report"],
    ["Calculations and budgets", "Preliminary — many inputs ASSUMED", "Power, storage, mass, link, parachute workbooks"],
    ["BOM and cost", "Prices sourced 24 Oct 2026; nothing ordered", "BOM workbook (all lines 'Proposed')"],
    ["Component procurement", "Not started", "—"],
    ["Physical assembly and integration", "Not started", "—"],
    ["Sensor, storage, telemetry, integration tests", "Not started", "—"],
    ["Mechanical, recovery and flight tests", "Not started; no permissions held", "—"],
    ["Reference footage", "External material only — not STRATOS evidence", "Footage register"],
], [34, 36, 30], size=15, highlight=[8, 9, 10, 11])

# =========================================================================== CH 1
H1("1  Mission and requirements")
H2("1.1  Problem definition")
P("A small sensor payload can show convincing live graphs and still fail its purpose: readings may lack timestamps, packets may be lost "
  "without trace, the ground record may be incomplete, and the recovered payload may hold data that nobody compares with what was received. "
  "STRATOS treats measurement as a chain — measurement → acquisition → local recording → transmission → reception → verification → "
  "reconciliation — and gives every link a defined responsibility and a test.")
P("The design keeps five claims separate, because each needs different evidence:")
TCAP("The five claims kept separate")
TAB(["Claim", "Question it answers", "How STRATOS addresses it"], [
    ["Measurement validity", "Is the reading physically credible?", "Plausibility limits, status flags, calibration comparison (FR-01, FR-02)"],
    ["Record validity", "Is the stored record structurally intact?", "Per-line CRC-16 in the onboard CSV (FR-05)"],
    ["Transmission integrity", "Was the packet corrupted?", "CRC-16 checked before any field is used (FR-07)"],
    ["Reception completeness", "Did every expected packet arrive?", "Packet sequence numbers, gap log (FR-08)"],
    ["Dataset reconciliation", "Do onboard and ground records agree?", "Field-by-field comparison and classification (FR-09)"],
], [22, 32, 46], size=16)
P("A CRC only detects corruption; it says nothing about sensor accuracy. Receiving every packet does not prove calibration. These limits are "
  "stated wherever the integrity features are described.")

H2("1.2  Mission objectives")
TCAP("Mission objectives and baseline response")
TAB(["#", "Objective (from the brief)", "Baseline response"], [
    ["1", "Environmental sensing", "BME280 temperature, humidity, pressure at 10 Hz. Particulate sensing **excluded** (§4.1); GNSS **optional** (pins reserved)"],
    ["2", "Embedded data acquisition", "Fixed 100 ms cycle; session ID, rec_seq, elapsed time, status flags in every record"],
    ["3", "Independent onboard logging", "microSD CSV, written whether or not the radio works, flushed every second"],
    ["4", "Wireless telemetry", "SX1276 GFSK at 866 MHz, 1 packet/s, within the India 865–867 MHz licence-exempt limits"],
    ["5", "Data-integrity verification", "CRC-16, sequence tracking, reject log, post-mission reconciliation (software prototype exists)"],
    ["6", "Mechanical protection and recovery", "Rod-and-spine structure, removable sleeve, Ø0.33 m parachute on a two-leg bridle"],
    ["7", "Ground-station operation", "Receiver + Python software: validation, logging, gap display, export, reconciliation"],
], [5, 30, 65], size=16)

H2("1.3  Competition context and constraints")
H3("SEVA FIRST Innovation Challenge 2026 — what the official portal says [S1]")
BUL("Organised by the Ministry of Education under the Seva Sankalp Abhiyan; news reports name AICTE, UGC and IISc Bengaluru as partners and a launch on 25 Sep 2026 [S1, S2, S35].",
    "**Levels:** Junior (Classes VI–XII), **Technical** (ITI and polytechnic; Track A needs a working prototype) and **Open** (UG and above; needs a demonstrated prototype or pilot). "
    "No level or track called 'Diploma & Higher Education' was found. A diploma team would normally fall under **Technical**, a degree team under **Open** — the team must confirm.",
    "**Tracks:** A — Product or Technology; B — Business Model or Governance. STRATOS fits **Track A**.",
    "**Themes:** Swachh & Sustainable Bharat; Samriddh Annadata; Swasth & Samavesh Bharat; Shikshit & Kaushal Bharat; Surakshit Bharat. The team should choose the theme "
    "(an environmental-monitoring framing fits *Swachh & Sustainable Bharat*; a safety/infrastructure framing fits *Surakshit Bharat*).",
    "**Judging** (no weights published): problem clarity, originality, demonstrated feasibility, cost, beneficiary impact, scalability, quality of solution.",
    "**Entry route:** an institutional coordinator registers the institution and submits each team's concept; students cannot register themselves.",
    "**Dates conflict:** home page — submissions 25 Sep–**24 Oct 2026**, screening from 25 Oct, finale 30 Nov–15 Dec; timeline page ('indicative') — submissions to **6 Nov**.",
    "**Eligibility risk:** the portal found is the **South Zone** edition (AP, Karnataka, Keralam, Tamil Nadu, Telangana, A&N, Lakshadweep, Puducherry). Madhya Pradesh is not listed; "
    "the team must ask its coordinator whether another zone or a state route applies.",
    "**No hardware rules** (dimensions, mass, radio, launch) and **no video length or document list** are published.")
H3("Reference rules adopted in the absence of SEVA FIRST hardware rules")
P("The European Space Agency CanSat rules are the most widely used public baseline for can-sized payloads and are adopted here as **ASSUMED** "
  "constraints, to be replaced as soon as official rules are obtained [S3, S4, S5]:")
TCAP("ESA CanSat constraints adopted as assumptions")
TAB(["Constraint (ESA CanSat)", "Value", "STRATOS Rev A"], [
    ["Envelope", "Ø66 mm × 115 mm (parachute excluded; ≈45 mm extra for parachute, fittings, antennas)", f"Ø{G['cap_d']:.0f} × {BL.OVERALL_H:.0f} mm rigid; parachute and bridle outside"],
    ["Mass", "300–350 g; ballast if lighter", f"≈{mtot:.0f} g estimated → ≈{325 - mtot:.0f} g ballast for a 325 g target"],
    ["Descent rate", "8–11 m/s recommended; never < 5 or > 12 m/s", "≈9 m/s at 325 g (calculated)"],
    ["Survive acceleration", "20 g", "Retention by screws, zip ties, rods; verify by test (IMU range ±16 g saturates above 16 g)"],
    ["Operating time", "4 h continuous, battery and master switch easy to reach", f"≈{pw['runtime_h']:.0f} h estimated; switch reachable through cap; cell needs shell removal (≈2 min)"],
    ["Parachute connection", "50 N (ESA 2022–23 [S3]); 500 N (CanSat Belgium 2026–27 [S6])", f"Designed for a {BL.PROOF_LOAD_N} N proof load (§6.7)"],
    ["Primary mission", "Temperature and pressure to the ground at ≥ 1 Hz", "T and P in every 1 Hz packet; 10 Hz onboard"],
    ["Budget", "≤ €500 for the flight unit", "Payload production ≈" + fmt(payload_prod) + " (INR, see Chapter 7)"],
    ["Prohibited", "Explosives, pyrotechnics, flammable or dangerous materials", "None used; Li-ion cell handled per §9.3"],
], [24, 42, 34], size=15)
SM("CanSat India (IN-SPACe/ISRO/ASI) uses a different class of payload (≈1 kg, 7U, rocket to ≈1 km) and is not used as the baseline [S36].")
H3("Radio regulation in India [S7, S8]")
P("The 865–868 MHz band is licence-exempt for short-range devices under **GSR 853(E), 10 Dec 2021**. For tracking, tracing and data-acquisition "
  "devices (Table II, whose notes list meteorological and pollution sensors) the limits are **500 mW ERP, ≤ 200 kHz bandwidth, ≤ 2.5 % duty "
  "cycle for non-access-point devices, adaptive power control required**. (Other licence-exempt bands exist — 2.4 GHz [S9] and 433.05–434.79 MHz [S10] — but the selected Ra-01H covers 803–930 MHz only.) Table I (non-specific devices) allows 25 mW ERP with 1 % duty and "
  "frequency hopping. The rules state that equipment shall be type approved (ETA).")
P(f"Consequence for the design: LoRa SF7 at 1 packet/s would occupy the channel {lora['t_total_ms']/10:.1f} % of the time — above the limit. "
  f"The baseline therefore uses the same SX1276 in **GFSK** mode: {fsk['t_total_ms']:.2f} ms per packet ({fsk['t_total_ms']/10:.2f} % duty), "
  f"≈{carson_bandwidth_khz(R['fdev_khz'], R['bitrate_bps']):.0f} kHz occupied bandwidth and ≈{10 ** ((14 - 2 - 2.15) / 10):.0f} mW ERP (with the assumed −2 dBi payload antenna). "
  "Two compliance questions remain open and are logged as risk R14: (a) adaptive power control on a one-way link — STRATOS sets the lowest "
  "power that gives an adequate margin in the range test, but has no closed loop; (b) whether a one-off student prototype built from a module "
  "needs its own ETA. The team should confirm both with the institution before any outdoor transmission.")
H3("Testing, drops and flight [S11, S12, S13]")
P("Drone Rules 2021 do not expressly cover dropping payloads; the Aircraft Rules 1937 (Rule 26) prohibit dropping articles or parachute "
  "descents from aircraft — which include balloons and kites — without a written government order. Model-rocket propellant is treated as an "
  "explosive (PESO) [S37]. **Plan: ground and fixed-structure drop tests only until written permissions exist.**")

H2("1.4  Intended operating conditions (ASSUMED)")
TCAP("Assumed operating conditions")
TAB(["Parameter", "Assumed value", "Basis"], [
    ["Deployment", "Release at ≤1 km above ground (rocket, drone or balloon), then parachute descent", "ESA CanSat mission profile [S5]"],
    ["Ambient temperature", "0 to +45 °C at ground; ≈6.5 °C/km lapse", "Central India; BME280 full accuracy 0–65 °C [S20]"],
    ["Pressure", "≈850–1013 hPa", "Ground elevations up to ≈1.5 km"],
    ["Logging window", "4 h per session, several sessions per day", "ESA powered-time requirement"],
    ["Radio range", "≤ 1 km slant range (planning), 3 km stretch", "Link budget §6.6"],
    ["Shock", "Landing at ≤ 11 m/s; 20 g survival", "ESA requirement"],
], [24, 42, 34], size=16)

H2("1.5  Functional requirements")
TCAP("Requirements (each is verified in Table {T:tvm})")
TAB(["ID", "Requirement", "Rationale"], [[r[0], r[1], r[2]] for r in RG.REQUIREMENTS], [9, 63, 28], size=15)
H2("1.6  Constraints and success criteria")
BUL("**Constraints:** student build with ordinary tools (3D printer, soldering, hand tools); parts available in India; reference envelope Ø66 × 115 mm; "
    "licence-exempt radio limits; no flight without permission; budget within a student team's means.",
    "**Success (prototype stage):** a bench prototype that logs 4 h of real data, transmits it at 1 Hz, and whose reconciliation explains every gap with zero unexplained discrepancies.",
    "**Success (mission stage, if authorised):** a permitted drop or flight in which the descent rate is within 8–11 m/s, the payload is recovered intact, and the onboard and ground records reconcile.")

# =========================================================================== CH 2
H1("2  System architecture")
IMG(os.path.join(OUT, "STRATOS_System_Architecture.png"), "Figure 2-1  Functional block diagram. Line style distinguishes data, control, power and radio flows; E# marks where errors originate and D# where they are detected.")
H2("2.1  Subsystems")
TCAP("Subsystems and interfaces")
TAB(["Subsystem", "Function", "Key parts", "Interface to controller"], [
    ["Environmental sensing", "T, RH, P at 10 Hz", "BME280 breakout", "I2C0 (IO21/IO22), 400 kHz"],
    ["Motion sensing", "3-axis acceleration and rate", "LSM6DSOX (Adafruit 4438)", "I2C0 + INT1 → IO39"],
    ["Controller", "Scheduling, records, packets, error handling", "ESP32-DevKitC V4", "—"],
    ["Onboard storage", "Every record, CSV + line CRC", "microSD 3 V breakout + 16 GB card", "VSPI (IO18/19/23, CS IO5)"],
    ["Telemetry", "1 Hz packets, GFSK 866 MHz", "Ra-01H (SX1276) + helical antenna", "HSPI via GPIO matrix (IO14/27/13, NSS IO33), RST IO32, DIO0 IO26"],
    ["Power", "Protected, switched, regulated 3.3 V", "18650, DW01A module, PTC, DPDT, S7V8F3", "VSYS sense → IO34 (ADC1)"],
    ["Indicators", "Status and recovery beeper", "LED, buzzer via BC547", "IO25, IO4"],
    ["Structure and recovery", "Protect, carry loads, descend safely", "PETG caps/spine/sleeve, M3 rods, Al yoke, parachute", "—"],
    ["Ground station", "Receive, validate, log, display, reconcile", "Ra-01H + ESP32 receiver, laptop, stratos_gs", "USB serial 115 200 baud"],
], [18, 26, 26, 30], size=15)
H2("2.2  Data flow and the three data objects")
P("Every 100 ms the controller builds one **record** (session, rec_seq, elapsed time, 10 measurement fields, status flags). Every record goes to "
  "the onboard log; every tenth record (rec_seq mod 10 = 1) is also encoded as a 44-byte **telemetry packet** with its own pkt_seq and CRC. "
  "The ground station turns each valid packet into a **received record** with a UTC reception time, RSSI and sequence event. These three objects "
  "are deliberately different and are never confused in the software or the documents.")
IMG(os.path.join(OUT, "STRATOS_Telemetry_Architecture.png"), "Figure 2-2  Telemetry, onboard logging and reconciliation architecture. Example values are simulated.")
H2("2.3  Power flow")
P("Cell (BT1) → DW01A/FS8205A protection (U7) → PTC fuse F1 → master switch pole A → VSYS (3.0–4.2 V) → S7V8F3 buck-boost (U6) → master "
  "switch pole B → +3V3 rail → all modules. Pole B isolates the regulator when the switch is OFF so that the ESP32 board's USB port can power "
  "it for programming: Espressif warns that only one of the board's supply options may be used at a time [S16].")
H2("2.4  Key design decisions")
TCAP("Table 2-2  Decisions, alternatives and reasons")
TAB(["Decision", "Alternatives considered", "Reason"], [
    ["ESP32-DevKitC V4 controller", "Arduino Nano/Uno; RP2040 Pico; ESP32-S3 DevKit", "Enough GPIO for two SPI buses + I2C + ADC1; 520 kB SRAM; mature libraries; original board in stock (Mouser); fits on a 50 × 70 mm carrier"],
    ["GFSK instead of LoRa at 1 Hz", "LoRa SF7 at 1 Hz; LoRa at 0.25 Hz; 2.4 GHz", f"GSR 853(E) duty-cycle limit 2.5 %: LoRa SF7 needs {lora['t_total_ms']:.0f} ms per packet; GFSK needs {fsk['t_total_ms']:.1f} ms. LoRa kept as a slower, longer-range option"],
    ["Two separate SPI buses", "SD and radio sharing one bus", "Avoids SD cards that do not release MISO; keeps radio timing independent of SD writes"],
    ["CSV log with per-line CRC", "Binary log; plain CSV", "Human-readable, easy to reconcile, and truncated/corrupted lines are detectable"],
    ["Integers in packet units in the log", "Floating-point CSV", "Exact field-by-field comparison with packets, no rounding ambiguity"],
    ["Absent value = flag + sentinel/empty field", "Write 0", "A missing reading can never be mistaken for a valid zero"],
    ["Particulate sensor excluded", "PMS5003", "Needs 5 V and ≤100 mA for its fan, 50 × 38 × 21 mm, 30 s warm-up, airflow path [S31]; no mission objective requires it"],
    ["GNSS optional", "NEO-M8N fitted", "Not needed for the data-integrity mission; adds ≈30 mA [S32]; UART2 pins reserved for recovery aid if rules require it"],
    ["External cell charging", "On-board USB charging", "No charging inside a closed can; USB-C on U7 only for supervised bench use"],
    ["Rod-and-spine structure", "Stacked decks; tube with glued boards", "Clear load path for parachute loads; whole electronics slide out for service"],
], [24, 28, 48], size=15)

# =========================================================================== CH 3
H1("3  Mechanical design")
IMG(os.path.join(OUT, "STRATOS_Main_Assembly.png"), "Figure 3-1  Conceptual assembly rendered from the parametric CAD model (not a photograph). Numbered labels are listed on the figure.")
H2("3.1  Arrangement")
P(f"A 3 mm PETG **spine** with two 7 × 7 mm edge ribs runs between a bottom and a top cap. Two **M3 A2 stainless threaded rods** pass through "
  f"the ribs; nuts in hex pockets under the bottom cap and nyloc nuts above an **aluminium yoke** clamp the stack. Face A (+Y) carries the "
  f"controller on a 50 × 70 mm perfboard **carrier**; face B (−Y) carries the 18650 cell, IMU, radio and BME280. The **shell** "
  f"(Ø{G['shell_od']:.0f} × {G['shell_wall']} mm wall, {G['shell_len']} mm long) is a non-structural sleeve located by the cap spigots.")
TCAP("Table 3-1  Main dimensions (mm)")
TAB(["Feature", "Value", "Status"], [
    ["Cap and shell outer diameter", f"{G['cap_d']:.1f}", "PROPOSED (envelope ≤ 66, ASSUMED)"],
    ["Overall rigid height (bottom face to rod tops)", f"{BL.OVERALL_H:.1f}", "PROPOSED (envelope ≤ 115, ASSUMED)"],
    ["Cap flange / spigot", f"{G['cap_t']:.0f} / {G['spigot_h']:.0f} (spigot Ø{G['spigot_d']})", "PROPOSED"],
    ["Shell bore", f"Ø{G['shell_od'] - 2 * G['shell_wall']:.1f}", "PROPOSED"],
    ["Spine height × width", f"{G['spine_h']:.0f} × {2 * G['rod_x'] + G['rib_w']:.0f}", "PROPOSED"],
    ["Rod centres", f"{2 * G['rod_x']:.0f}", "PROPOSED"],
    ["Recovery yoke", f"{G['yoke_l']:.0f} × {G['yoke_w']:.0f} × {G['yoke_t']:.0f}, bridle holes at ±{G['bridle_x']:.0f}", "PROPOSED"],
    ["Worst internal radial clearance", f"{cad['worst_radial_clearance']['clearance_mm']:.2f} ({cad['worst_radial_clearance']['item']} to shell bore)", "CAD check"],
    ["Interferences between modelled parts", f"{len(cad['interference'])}", "CAD check (module outlines PRELIMINARY)"],
], [46, 30, 24], size=16)
H2("3.2  Mounting, access and cable routing")
BUL("Modules are screwed (M2.5 self-tapping) to printed bosses; the cell is held by its holder **and** a zip tie through the spine.",
    "The microSD breakout sits under the carrier, card edge at −X; the ESP32 micro-USB faces −Z. Both are reached by removing the shell.",
    "Service sequence: undo two nyloc nuts → lift yoke and top cap → slide the shell upwards. Estimated 2 minutes (to be timed).",
    "SW1 (DPDT) is operated with a pen tip through an 8 × 3 mm slot in the bottom cap, which prevents accidental switching.",
    "Harnesses (JST-XH) cross between faces through two spine slots (14 × 6 and 10 × 5 mm); vent slots in the shell sit beside the BME280.",
    "The antenna is a helix soldered to the radio adapter at the top of face B, ≥ 30 mm from the cell and on the opposite face from the ESP32.")
H2("3.3  Materials and fabrication")
TCAP("Materials and fabrication")
TAB(["Part", "Material", "Process", "Notes"], [
    ["Caps, spine, shell", "PETG", "FDM print, 0.4 mm nozzle", "Spine printed upright (rod bores vertical); caps flange-down; shell 3 perimeters"],
    ["Rods", "M3 A2 stainless threaded rod", "Cut to 112.5 mm, deburr", "Threadlocker or nyloc nuts"],
    ["Yoke", "6061-T6 flat bar 10 × 4 mm", "Saw, file R3 corners, drill", "Break edges so the bridle is not cut"],
    ["Carrier", "Double-sided perfboard 50 × 70 mm", "Hand wiring", "A custom PCB is a later option"],
    ["Parachute", "Ripstop nylon, paracord inner strands", "Cut and sew; spill hole optional", "High-visibility colour preferred"],
], [18, 26, 24, 32], size=15)
H2("3.4  Recovery concept")
P(f"A Ø0.33 m flat circular canopy hangs from a swivel and a two-leg (Y) bridle attached to holes at ±{G['bridle_x']:.0f} mm on the yoke, close to "
  "the rods so the yoke is not loaded in large bending. Deployment hardware (ejection from a rocket, release from a platform) is outside the "
  "Rev A scope and depends on the competition's launch provider.")
H2("3.5  Unresolved mechanical items")
TCAP("Unresolved mechanical items")
TAB(["#", "Item", "Status"], [
    ["A1", "Envelope and mass limits are ESA CanSat values, not SEVA FIRST rules", "ASSUMED"],
    ["A2", "Rigid height excludes the parachute, Y-bridle and swivel", "ASSUMED"],
    ["A3", "PETG printed with a 0.4 mm nozzle; spigot fit 0.1 mm radial", "PROPOSED"],
    ["A4", "Breakout outlines (BME280, adapter, holder, switch, connectors) from listings, not drawings", "PRELIMINARY"],
    ["A5", "JST-XH mated height at the carrier edge leaves ≈2.4 mm to the bore", "TO VERIFY with real parts"],
    ["A6", "Shell anti-rotation feature not yet designed", "UNRESOLVED"],
    ["A7", f"Ballast location for ≈{325 - mtot:.0f} g (if a 300 g minimum applies)", "UNRESOLVED"],
    ["—", "Holder and cell retention under 20 g; PETG cap strength under the rod nuts", "To be proven by test (FR-16)"],
], [8, 70, 22], size=16)
P("The four drawing sheets (general arrangement, internal arrangement with section, exploded view with parts list, part details) are in "
  "STRATOS_Mechanical_Drawings.pdf and reproduced in Appendix F.")

# =========================================================================== CH 4
H1("4  Electronics")
H2("4.1  Component selection")
TCAP("Table 4-1  Selected parts and verified key data")
TAB(["Ref", "Part", "Key data (source)", "Why chosen"], [
    ["U1", "ESP32-DevKitC V4 (WROOM-32E)", "3.0–3.6 V; modem-sleep 80 MHz 20–31 mA; board 54.4 × 27.9 mm; 38 pins [S14–S16]", "Two SPI hosts, ADC1, enough GPIO; original stocked"],
    ["U2", "BME280 breakout", "1.71–3.6 V; ±1 hPa, ±3 %RH, ±0.5 °C at 25 °C; 3.6 µA at 1 Hz; I2C 0x76/0x77 [S20]", "T, RH and P in one part; low power"],
    ["U3", "LSM6DSOX (Adafruit 4438)", "0.55 mA accel+gyro HP; ±2–16 g, ±125–2000 dps; 25.6 × 17.8 mm, 1.7 g; I2C 0x6A [S21, S22]", "Active part (MPU-6050 is EOL [S23]); level-shifted breakout"],
    ["U4", "Ra-01H (SX1276)", "803–930 MHz; 17 × 16 × 3.2 mm; stamp pads, soldered antenna; TX 87 mA at +17 dBm; standby 1.6 mA [S24, S25]", "868 MHz-band part in stock in India; FSK and LoRa in one chip"],
    ["U5", "microSD 3 V breakout (Adafruit 4682)", "No regulator or level shifter (3 V logic only); 25.4 × 22.8 × 3.5 mm [S27]; SD ≤100 mA in SPI [S26]", "Direct 3.3 V SPI, no 5 V-only translator"],
    ["U6", "Pololu S7V8F3", "VIN 2.7–11.8 V; 3.3 V out; up to 1 A (VIN > 3.3 V); Iq < 0.1 mA; 11 × 17 mm [S28]", "Keeps 3.3 V over the whole Li-ion range"],
    ["U7", "TP4056 module with DW01A/FS8205A", "TP4056: 4.2 V ±1.5 %, ≤1 A [S29]; DW01A thresholds NOT CONFIRMED", "Cheap, available cell protection"],
    ["BT1", "18650 Li-ion — BOM candidate Molicel INR18650-P28A", "2,800 mAh per supplier listing (datasheet to be checked). Envelope and mass upper bound from the Samsung 35E datasheet: ≥3,350 mAh, 8 A cont., ≤50 g, Ø18.55 × 65.25 mm [S30]", "Robust, swappable, counts toward minimum mass"],
], [6, 22, 44, 28], size=14)
P("**Excluded or deferred.** PMS5003 particulate sensor (5 V, ≤100 mA fan, 50 × 38 × 21 mm, 30 s warm-up) — excluded; NEO-M8N GNSS "
  "(23–32 mA tracking, 16 × 12.2 mm) — optional, UART2 pins reserved; ICM-42688-P — no breakout found in India; LSM6DS3TR-C — 0.90 mA, "
  "acceptable fallback.")
NOTE("Datasheet discrepancies to resolve before ordering: BME280 temperature accuracy over 0–65 °C (±0.5 °C in rev 1.24 vs ±1.0 °C in rev 1.6); "
     "Ra-01H maximum output (+19 vs +20 dBm in the same document). SX1276 GFSK sensitivity at 38.4 kb/s was **not confirmed** and is an assumption in the link budget.")
H2("4.2  Schematic")
P("The schematic is generated from a single netlist (design/netlist.py) that also produces the pin map, the component list and a KiCad-format "
  "netlist, so the four cannot disagree. Net labels of the same name are connected. Sheet 1 is reproduced below; all three sheets are in "
  "STRATOS_Electronics_Schematic.pdf and Appendix F.")
IMG(os.path.join(OUT, "STRATOS_Electronics_Schematic_Sheet1.png"), "Figure 4-1  Schematic sheet 1 of 3 — power, protection, master switch, regulator and battery sense.")
H2("4.3  Pin mapping")
TCAP("Table 4-2  ESP32 pin assignment (full table with far-end pins in STRATOS_Pin_Mapping.csv)")
TAB(["Signal", "GPIO", "Dir.", "Bus", "Connects to", "Note"],
    [[p[1], p[2], {"out": "Out", "in": "In", "bidir": "Bi"}[p[4]], p[5],
      p[0], p[6]] for p in BL.PINS if not p[1].startswith(("UART0", "GNSS"))], [16, 7, 6, 10, 10, 51], size=14)
P("Avoided pins: GPIO6–11 (module flash), GPIO0 and GPIO2 (boot), GPIO12 (must be low at power-on — it selects the flash voltage) and GPIO15 "
  "(boot log). GPIO5 is a strapping pin whose default is high; R4 (10 kΩ) keeps it high and the card deselected at boot [S14, S15, S17]. Routing the "
  "radio's SPI through the GPIO matrix limits the clock to ≈26 MHz full-duplex [S18], well above the SX1276's 10 MHz maximum.")
H2("4.4  Compatibility checks")
TCAP("Electrical compatibility checks")
TAB(["Check", "Result", "Basis"], [
    ["Supply voltages on +3V3 (3.3 V +5/−3 %)", "Within ESP32 3.0–3.6, BME280 1.71–3.6, LSM6DSOX 1.71–3.6 (board VIN 3–5), SX1276 1.8–3.7, Ra-01H 2.7–3.6, SD 2.7–3.6", "S14, S20, S22, S24–S26, S28"],
    ["Logic levels", "All 3.3 V CMOS; no 5 V device on the bus", "U5 is a 3 V-only breakout"],
    ["I2C addresses", "BME280 0x76/0x77 vs LSM6DSOX 0x6A — no conflict", "S20, S22"],
    ["I2C pull-ups", "Both breakouts include pull-ups (Adafruit: 10 kΩ); R8/R9 left unfitted unless measured too weak", "S22"],
    ["ADC range", "VBAT/2 = 1.5–2.1 V inside the 150–2450 mV range at 11 dB", "S19"],
    ["Regulator capacity", f"Worst coincident peak {pw['rail_peak']:.0f} mA vs up to 1 A (typ. 0.5–1 A)", "S28; §6.1"],
    ["Module supply requirement", "WROOM-32E asks for a supply able to deliver ≥ 0.5 A; Ra-01H asks for > 200 mA", "S14, S25"],
    ["Switch rating", "DPDT rating not stated by the supplier — must be ≥ 0.5 A DC", "OPEN"],
    ["Strapping pins", "IO5 held high (R4); IO12/IO15/IO0/IO2 unused", "S14"],
], [24, 52, 24], size=15)

# =========================================================================== CH 5
H1("5  Firmware and telemetry")
H2("5.1  Firmware architecture")
P("The firmware runs a fixed 100 ms cycle as an explicit state machine. Modules: acquisition and plausibility checks; record builder (session, "
  "rec_seq, millis); logger (50-record RAM ring buffer, CSV formatting with line CRC at flush time); packet encoder (shared C code, host-tested); "
  "radio driver (non-blocking transmit, completion interrupt on DIO0, 50 ms timeout); error handler (flags, retries, recovery states); power and "
  "landing monitor. The draft sketch is in firmware/payload/ and is **not yet compiled**.")
IMG(os.path.join(OUT, "STRATOS_Firmware_State_Diagram.png"), "Figure 5-1  Firmware state diagram with error handling (proposed).")
H2("5.2  Sampling and logging")
BUL("All sensors are read once per 100 ms cycle into one record (BME280 normal mode ≈13 Hz output; IMU 104 Hz output data rate sampled at 10 Hz).",
    "Records with rec_seq mod 10 = 1 are transmitted (1 Hz); the SD card is flushed at rec_seq mod 10 = 6, half a second away from the radio slot, to avoid coincident current peaks.",
    "Records are kept as binary structures until flush so that the radio outcome ('T' sent, 'F' failed) is written into the same CSV line.",
    "A buffer overflow or write failure is never silent: LOG_OVERFLOW / SD_WRITE_ERR flags travel in the next packet and the reconciliation reports the onboard gap.")
H2("5.3  Packet format")
TCAP("Table 5-1  44-byte telemetry packet (little-endian); full specification in STRATOS_Packet_Format.md")
TAB(["Offset", "Size", "Field", "Type", "Unit"], [[f[1], f[2], f[0], f[3], f[4]] for f in FIELDS], [10, 8, 20, 14, 48], size=14)
P("**Integrity field:** CRC-16/CCITT-FALSE (polynomial 0x1021, initial 0xFFFF, no reflection) over bytes 0–41; check value 0x29B1 for "
  "'123456789'. The receiver verifies it before reading any field. The radio's own packet CRC is also enabled. **Absent values** are flagged "
  "in the status word and written as sentinels (packet) or empty fields (log).")
TCAP("Table 5-2  Status flags")
TAB(["Bit", "Flag", "Meaning"], [[b, n, d] for b, (n, d) in STATUS_BITS.items() if not n.startswith("RESERVED")], [6, 20, 74], size=14)
H2("5.4  Ground-station processing")
NUM("Receiver firmware forwards every frame as `RX,<ms>,<rssi>,<snr|nan>,<len>,<hex>`; the laptop stamps UTC time and saves the raw capture.",
    "Validation: length = 44 → CRC-16 → magic/version/type. Failures go to ground_rejected.csv with the raw bytes and a reason.",
    "Sequence tracking per session: GAP (missing numbers logged to ground_gaps.csv), DUPLICATE, OUT_OF_ORDER, SESSION_CHANGE.",
    "Accepted packets go to ground_accepted.csv; the display reads the logged stream, so what is shown is what was recorded.", ref="num")
IMG(os.path.join(OUT, "STRATOS_Ground_Station_Mockup.png"), "Figure 5-2  Proposed ground-station interface drawn from the prototype software's state while replaying a SIMULATED capture — not connected to hardware.", scale=0.95)
H2("5.5  Post-mission reconciliation rules")
TCAP("Reconciliation rules")
TAB(["Rule", "Applies to", "Classification"], [
    ["R1", "Every onboard line", "Line CRC fails → ONBOARD_LINE_INVALID"],
    ["R2", "Onboard rec_seq jumps", "ONBOARD_LOGGING_GAP"],
    ["R3–R5", "Transmitted (tx = 'T') and received", "13 fields compared → MATCH or MISMATCH"],
    ["R6", "Transmitted, not received", "MISSING — corrupted frame observed / no frame observed"],
    ["R7", "tx = 'F' onboard", "NOT_TRANSMITTED (explained)"],
    ["R8", "Received, no valid onboard record", "GROUND_COPY_OF_INVALID_ONBOARD_LINE (explained) or GROUND_ONLY (unresolved)"],
], [10, 34, 56], size=15)
H2("5.6  Software demonstration (SIMULATED)")
P("stratos_gs.simulate generates a synthetic 171 s session (hold at 1 km, 9 m/s descent, landing), writes it in the onboard format, passes "
  "the packets through a simulated link with **deliberately injected faults**, runs the ground tracker and then the reconciliation:")
TCAP("Injected faults and results (simulated)")
TAB(["Injected fault (synthetic)", "Detected by", "Reconciliation result"], [
    ["Packet 6 dropped", "Ground gap log", "MISSING — no frame observed; recovered from onboard log"],
    ["One bit flipped in packet 9", "CRC-16 reject", "MISSING — corrupted frame observed; recovered from onboard log"],
    ["Packets 120–122 lost (burst)", "Ground gap log", "MISSING — no frame observed (3)"],
    ["Radio failure on packet 150", "Onboard tx = 'F', RADIO_ERR", "NOT_TRANSMITTED (explained)"],
    ["Packet 60 delivered twice", "DUPLICATE flag", "Counted once"],
    ["Humidity unavailable, records 800–804", "RH_INVALID flag, empty field", "Absent ≠ zero"],
    ["Final log line truncated", "Line CRC", "Ground packet preserves that record (explained)"],
], [34, 30, 36], size=15)
_miss = sorted(list(s7['missing']) + list(s7['missing_corrupt']))
P(f"Result (synthetic): {s7['records']:,} valid onboard lines plus {len(sim['onboard_invalid'])} truncated final line; {s7['scheduled']} packets "
  f"scheduled in the valid lines ({s7['tx_done']} sent, {s7['tx_fail']} radio failure) plus packet {sorted(s7['ground_recovers'])[0]} in the truncated line; "
  f"{s7['received']} unique packets accepted at the ground (the duplicate counted once) and {sim['ground_rejected']} corrupted frame rejected; "
  f"{len(_miss)} sequence numbers missing (6, 9, 120–122), all recovered from the onboard log (the ground gap log also lists 150, which the onboard log shows was never transmitted); {s7['match']} received packets match their onboard "
  f"records field for field, {s7['mismatch']} mismatch, and packet {sorted(s7['ground_recovers'])[0]} preserves the record whose onboard line was truncated. "
  f"**Unresolved discrepancies: {len(s7['anomalies']) + len(s7['ground_only'])}.**")
IMG(os.path.join(OUT, "STRATOS_Data_Integrity_Demonstration.png"), "Figure 5-3  Data-integrity demonstration, packets 001–010. Illustrative example using synthetic records; hardware validation pending.")
IMG(os.path.join(OUT, "STRATOS_Telemetry_Sequence.png"), "Figure 5-4  Data-flow sequence for one telemetry cycle (design targets, not measurements).", scale=0.9)

# =========================================================================== CH 6
H1("6  Engineering calculations")
P("All calculations are formula-driven in the workbooks; inputs are blue and labelled VERIFIED or ASSUMED. Each result below is preliminary "
  "until the ASSUMED inputs are replaced by measurements.")
H2("6.1  Power budget")
P("Average current per load: I_avg = I_active·D + I_idle·(1 − D). Battery current: I_batt = P_rail / (η·V_nom) + battery-side loads. "
  "Ideal operating time: t = C / I_avg.")
TCAP("Table 6-1  Power budget at the +3V3 rail")
TAB(["Load", "Active mA", "Idle mA", "Duty", "Avg mA", "Peak mA", "Source"],
    [[r["name"], f"{r['ia']:.2f}", f"{r['ii']:.2f}", f"{r['d'] * 100:.2f} %", f"{r['avg']:.2f}", f"{r['ip']:.0f}",
      r["sa"].split(":")[0]] for r in pw["rows"]] + [["**+3V3 total**", "", "", "", f"**{pw['rail_avg']:.1f}**", f"**{pw['rail_peak']:.0f}**", ""]],
    [34, 9, 9, 8, 9, 9, 22], size=14)
IMG(os.path.join(CH, "chart_power.png"), "Figure 6-1  Largest contributors to average and peak current.")
TCAP("Battery current and operating time (estimates)")
TAB(["Result", "Value"], [
    ["Rail power", f"{pw['rail_p']:.0f} mW"],
    ["Battery current (η = 0.85 ASSUMED, 3.6 V)", f"{pw['i_batt']:.1f} mA"],
    ["Ideal time, 2,800 mAh BOM cell (listing value)", f"{pw['ideal_h']:.0f} h"],
    ["Estimated time, 80 % usable (design basis)", f"{pw['runtime_h']:.0f} h → margin {pw['runtime_h'] / 4:.1f}× over 4 h"],
    ["Estimated time, genuine Samsung 35E (3,350 mAh minimum)", f"{pw['runtime_ref_h']:.0f} h"],
    ["Estimated time, conservative 2,000 mAh cell", f"{pw['runtime_cons_h']:.0f} h → margin {pw['runtime_cons_h'] / 4:.1f}× over 4 h"],
    ["Worst coincident peak at the cell (3.0 V)", f"{pw['peak_batt']:.0f} mA vs 8 A (35E rating; P28A rating to be read from its datasheet)"],
], [55, 45], size=16)
_i_wifi = (pw['rail_avg'] + 239) * 3.3 / PW.REG_EFF / PW.V_BATT_NOM + sum(b[2] for b in PW.BATT_SIDE)
P("The largest uncertainty is the DevKitC board overhead (no official figure) — the first bench measurement. Wi-Fi left on by mistake would "
  f"add ≈239 mA and cut the time to ≈{PW.CELL_CAP_MIN_MAH * PW.USABLE_FRACTION / _i_wifi:.0f} h (still above 4 h). FR-11 asks that the 4 h "
  "window uses at most 50 % of the usable capacity, i.e. a margin of at least 2×.")
H2("6.2  Storage and sampling")
TCAP("Storage and sampling figures")
TAB(["Quantity", "Value"], [
    ["Record rate × window", "10 records/s × 4 h = 144,000 records"],
    ["Worst-case line (122 characters + CR LF)", "124 bytes → 17.9 MB per session"],
    ["Typical line (simulated mean)", "≈70 bytes → 10.1 MB per session"],
    ["Usable card capacity (16 GB × 0.93 ASSUMED)", "≈14.9 GB → one session uses 0.12 %"],
    ["Average write rate", "≈1.2 kB/s worst case"],
    ["RAM ring buffer", "50 × 48 B = 2.4 kB (< 0.5 % of SRAM)"],
], [50, 50], size=16)
IMG(os.path.join(CH, "chart_storage.png"), "Figure 6-2  Storage requirement against card capacity.", scale=0.85)
H2("6.3  Mass budget")
IMG(os.path.join(CH, "chart_mass.png"), "Figure 6-3  Estimated mass by group (most items EST until weighed).", scale=0.85)
P(f"Estimated total before ballast: **{mtot:.0f} g**. If a 300–350 g rule applies, ≈{300 - mtot:.0f}–{350 - mtot:.0f} g of ballast is needed "
  f"(≈{325 - mtot:.0f} g for the 325 g design target). Printed parts are CAD volumes × assumed fill factors.")
H2("6.4  Dimensional checks (CAD)")
P(f"All modelled parts lie within Ø{cad['envelope']['max_diameter_used_mm']:.1f} mm and {cad['envelope']['height_mm']:.1f} mm height; "
  f"the smallest radial clearance is {cad['worst_radial_clearance']['clearance_mm']:.2f} mm ({cad['worst_radial_clearance']['item']}); "
  f"pairwise interference check: {len(cad['interference'])} intersections. Module outlines marked PRELIMINARY must be re-checked against the actual parts once obtained.")
H2("6.5  Telemetry timing and regulatory figures")
TCAP("Telemetry timing and regulatory figures")
TAB(["Quantity", "GFSK baseline", "LoRa option"], [
    ["Bytes / symbols on air", f"{fsk['bytes_on_air']} bytes", f"{lora['payload_symbols']} payload symbols + 12.25 preamble"],
    ["Time on air (44-byte payload)", f"{fsk['t_total_ms']:.2f} ms", f"{lora['t_total_ms']:.1f} ms (Semtech formula [S24])"],
    ["Duty cycle at 1 packet/s", f"{fsk['t_total_ms']/10:.2f} %", f"{lora['t_total_ms']/10:.1f} % (exceeds 2.5 %)"],
    ["Occupied bandwidth", f"≈{carson_bandwidth_khz(R['fdev_khz'], R['bitrate_bps']):.0f} kHz (Carson)", "125 kHz"],
    ["ERP (+14 dBm, −2 dBi antenna)", "≈10 mW", "≈10 mW"],
    ["Limits, GSR 853(E) Table II", "500 mW ERP, ≤200 kHz, ≤2.5 %", "same"],
], [34, 33, 33], size=15)
H2("6.6  Link budget")
P("Free-space path loss: FSPL = 20·log10(d) + 20·log10(f) − 147.55 dB. Assumptions: +14 dBm, −2 dBi payload antenna, +1 dBi ground antenna, 1 dB losses.")
IMG(os.path.join(CH, "chart_link.png"), "Figure 6-4  Free-space margin vs distance. GFSK sensitivity is ASSUMED (−105 dBm) pending a range test; LoRa sensitivity from the datasheet.", scale=0.9)
P(f"At 1 km the free-space received power is ≈{14 - 2 + 1 - 1 - fspl_db(1000, 866e6):.0f} dBm, giving ≈26 dB margin for GFSK (assumed sensitivity) "
  "and ≈44 dB for LoRa SF7. A 15 dB fade margin is met to ≈3 km for GFSK in free space; tumbling, polarisation and ground effects will reduce this.")
H2("6.7  Recovery calculations")
P("Steady descent: v = √(2mg / (ρ·C_D·A)). With m = 0.325 kg, v = 9 m/s, C_D = 0.75 (ASSUMED; flat circular canopies are commonly quoted at "
  "≈0.75–0.80, e.g. Knacke's *Parachute Recovery Systems Design Manual* — not re-verified here) and ρ = 1.225 kg/m³: A = 0.0857 m², **D = 0.33 m**.")
IMG(os.path.join(CH, "chart_descent.png"), "Figure 6-5  Descent speed vs mass for the chosen Ø0.33 m canopy across the assumed C_D range.", scale=0.9)
P(f"Attachment strength for a {BL.PROOF_LOAD_N} N proof pull: each rod carries 250 N (A2-70 M3 yield ≈2.26 kN, factor ≈9); the yoke sees "
  f"M = 250 N × {G['rod_x'] - G['bridle_x']:.0f} mm = 2,250 N·mm, Z = 10 × 4²/6 = 26.7 mm³, σ ≈ 84 MPa against ≈276 MPa yield for 6061-T6 "
  "(factor ≈3.3). A single central hole would raise the yoke stress about 2.8×, hence the two-leg bridle. Estimated opening load at an assumed "
  "25 m/s deployment: ≈49 N. The PETG cap under the rod nuts must be proven by a pull test.")

# =========================================================================== CH 7
H1("7  Bill of materials and cost")
P("Prices were read from supplier pages on 24 Oct 2026 [S33] and are converted to INR including GST (18 % ASSUMED where pages show prices "
  "excluding GST). **Nothing has been ordered.** Full details, URLs, stock notes and alternatives are in STRATOS_BOM.xlsx.")
TCAP("Table 7-1  Compact BOM (key parts)")
key = ["P01", "P02", "P03", "P04", "P07", "P08", "P09", "P10", "P11", "P12", "P06", "S01"]
rows = []
for row in B.BOM:
    if row[0] in key:
        u = unit(row)
        rows.append([row[0], row[3], row[4], row[9], fmt(u * row[5]) if u is not None else "—", row[11]])
TAB(["Item", "Component", "Model", "Supplier", "Cost incl. GST", "Availability"], rows, [6, 18, 30, 14, 11, 21], size=14)
TCAP("Table 7-2  Cost summary")
TAB(["Category", "INR incl. GST"], [[k, fmt(v)] for k, v in cat.items()] +
    [["Allowances (fasteners, Al bar, shipping, Pololu import)", fmt(allow)], ["**Subtotal**", f"**{fmt(subtotal)}**"],
     ["Contingency 15 %", fmt(subtotal * 0.15)], ["**Total estimated procurement**", f"**{fmt(total)}**"],
     ["Per-payload production estimate (flight unit, incl. import allowance)", fmt(payload_prod)],
     ["Ground station (separate; laptop assumed owned)", fmt(cat["Ground station"])]], [70, 30], size=15)
IMG(os.path.join(CH, "chart_cost.png"), "Figure 7-1  Procurement cost by category.", scale=0.85)
H3("Procurement notes")
BUL("**Pololu S7V8F3** is not stocked by the Indian retailers checked; it is priced at USD 9.95 with an assumed ₹88/USD and a ₹2,500 shipping/duty allowance. A domestic LDO alternative is listed but not priced.",
    "**18650 cell:** the Robu 'Samsung 35E' listing states its cells are copies — do not use. A Molicel P28A is priced as a candidate; authenticity and capacity must be verified on receipt.",
    "**microSD:** the 16 GB card was out of stock on 24 Oct; industrial cards were unavailable or expensive. Test every card before use (risk R04).",
    "**Ra-01H** has stamp pads and no IPEX connector: the payload helix is soldered to the adapter; the ground pigtail's coax must be soldered to the ANT pad.",
    "Robu 'mirror' pages showed lower prices than live robu.in pages; Mouser prices exclude GST and possibly duties. Re-check on the purchase day.",
    "Items already owned (laptop, multimeter, 3D printer, soldering station) are ASSUMED and listed as 'Owned (to confirm)'.")

# =========================================================================== CH 8
H1("8  Development and verification")
H2("8.1  Development roadmap")
IMG(os.path.join(CH, "chart_roadmap.png"), "Figure 8-1  Proposed roadmap from 24 Oct 2026. Only M01 (this dossier, a draft pending team review) and M02 (software prototype, simulation only) exist; everything else is planned.")
P("**Schedule conflict and recovery plan.** If the submission window closes on 24 October, the concept must be submitted now with this dossier as "
  "evidence of design maturity. If shortlisted, the realistic target before the finale (30 Nov–15 Dec) is a **working bench prototype** that "
  "logs, transmits and reconciles real sensor data; no flight is planned before the finale. If the team is not eligible this cycle, the roadmap "
  "continues unchanged toward the next edition or a CanSat competition with published rules.")
H2("8.2  Test and verification matrix")
TCAP("Verification of every requirement (acceptance criteria fixed before testing)", key="tvm")
TAB(["ID", "Method", "Acceptance criterion", "Status"], [[r[0], r[3], r[5], r[7]] for r in RG.REQUIREMENTS], [8, 14, 48, 30], size=14)
H2("8.3  Planned test procedures (summary)")
TCAP("Planned test stages")
TAB(["Stage", "Test", "Evidence"], [
    ["1 Design review", "Rules, envelope, interfaces, BOM", "Signed checklist"],
    ["2 Component/interface", "Chip IDs (BME280 0x60), cell capacity, regulator output, switch rating", "Incoming-inspection sheet"],
    ["3 Sensors", "30 min logging next to reference instruments; six-orientation IMU test", "Serial logs, comparison sheet"],
    ["4 Local logging", "4 h run; 10 random power cuts", "Log files; reconciliation of onboard lines"],
    ["5 Telemetry", "Bench link then range test at 100 m–1 km; channel survey first", "Transmitter + receiver logs; packet-error rate vs distance"],
    ["6 Data integrity", "Deliberately skipped sequence numbers and corrupted frames from a test transmitter", "Reject/gap logs; unit tests"],
    ["7 Integrated ground test", "4 h run with induced faults, measured current", "Reconciliation report; INA219 log"],
    ["8 Mechanical/recovery", "Shake, drop from a fixed structure (3 drops timed), 500 N pull", "Inspection record, video, timing"],
    ["9 Mission validation", "Only with written permissions and a safety review", "Authorised plan, post-test report"],
], [18, 50, 32], size=15)
H2("8.4  Software evidence available now")
BUL("`python -m unittest discover -s tests` — 8 tests pass: CRC check value; packet round-trip; **every single-bit error in a frame detected**; wrong length rejected; absent ≠ zero; log-line round-trip and truncation; gap/corruption/duplicate/session tracking; simulated reconciliation classifies all injected faults.",
    "The C packet/log-line code compiles with `-Wall -Wextra -Werror` and its output is byte-identical to the Python reference for four test records, including sentinels and extreme values.",
    "These are software results on synthetic data; they do not verify any hardware requirement.")
H2("8.5  Known limitations")
BUL("No sensor accuracy, timing jitter, power, radio range, SD reliability or structural result is measured yet.",
    "IMU accelerometer range (±16 g) saturates above 16 g; launch shocks above that will clip (survival is a separate matter).",
    "No real-time clock: absolute time exists only at the ground; onboard time restarts after a reset (made visible by the session ID).",
    "Payload antenna performance inside the can is unknown; the link budget uses assumed gains and an assumed GFSK sensitivity.",
    "Adaptive power control (GSR 853(E) Table II) is not implemented on the one-way link.")

# =========================================================================== CH 9
H1("9  Risk and safety")
IMG(os.path.join(CH, "chart_risk.png"), "Figure 9-1  Risk matrix before any test. No mitigation has yet been verified by a hardware test.", scale=0.8)
TCAP("Table 9-1  Risk register (condensed; full register with causes and owners in STRATOS_Risk_Register.xlsx)")
TAB(["ID", "Risk", "L", "C", "Score", "Mitigation (proposed)", "Verification", "Status"],
    [[r[0], r[1], r[4], r[5], r[4] * r[5], r[6], r[7], "Proposed" if r[9].startswith("Proposed") else "Partly shown in simulation"] for r in RG.RISKS],
    [5, 13, 4, 4, 6, 36, 22, 10], size=13)
P("Scales: likelihood 1 Rare (< 5 %) … 5 Almost certain (> 80 %); consequence 1 Negligible … 5 Severe (injury, payload loss or project failure). "
  "Bands: Low 1–4, Medium 5–9, High 10–16, Critical 17–25.")
H2("9.1  Recovery and deployment considerations")
BUL("No deployment from aircraft (drones, balloons, kites) without written permission; Rule 26 of the Aircraft Rules prohibits dropping articles and parachute descents.",
    "Drop tests from a fixed structure over a cordoned area, with a spotter, low wind and no people below.",
    "Inspect bridle, swivel, yoke and nuts before every test; replace any line showing abrasion.",
    "High-visibility canopy, contact label and the landing beeper aid recovery.")
H2("9.2  Radio permissions")
BUL("Operate only in 865–867 MHz within GSR 853(E) limits; channel survey before every test; lowest adequate power.",
    "Confirm with the institution whether the prototype needs ETA or falls under an R&D/prototype exemption before outdoor use (risk R14).")
H2("9.3  Battery safety")
BUL("Genuine cell, DW01A protection, PTC fuse, insulated holder, firmware cut-off at 3.30 V.",
    "Charge outside the can in a charger on a non-flammable surface, never unattended; supervised USB-C bench charging only with the shell removed.",
    "Store at partial charge; discard any swollen, dented or hot cell.")

# =========================================================================== CH 10
H1("10  Team and implementation plan")
P("The team has not supplied member names, enrolment or skills, so responsibilities are defined as **roles**. One person may hold several roles.")
TCAP("Roles and responsibilities")
TAB(["Role", "Responsibilities", "Named member"], [
    ["Project manager", "Entry route and deadlines (M03), procurement, schedule, risk reviews", "TO BE ASSIGNED"],
    ["Systems lead", "Requirements, design reviews, rules compliance, integration", "TO BE ASSIGNED"],
    ["Electronics lead", "Carrier wiring, power path, incoming inspection, current measurements", "TO BE ASSIGNED"],
    ["Firmware lead", "Payload and receiver firmware, compiling, module tests", "TO BE ASSIGNED"],
    ["Ground-station / software lead", "stratos_gs, range tests, reconciliation reports", "TO BE ASSIGNED"],
    ["Mechanical lead", "Printing, rods/yoke, parachute, drop and pull tests", "TO BE ASSIGNED"],
], [20, 58, 22], size=16, highlight=list(range(6)))
H2("10.1  Next steps (first two weeks)")
NUM("Today: confirm the entry route, level, theme and deadline with the institution coordinator; submit the concept if the window is open.",
    "Review this dossier; resolve the open items (switch rating, DW01A thresholds, adapter pitch, shell anti-rotation).",
    "Order long-lead and critical parts (Pololu or LDO alternative, Mouser items, Ra-01H × 2, cell) from two sources where possible.",
    "Start printing caps, spine and shell; check fits against the drawings.",
    "Compile the payload firmware; bring up sensors and SD logging on the bench; measure board current with the INA219.",
    "Build the receiver and run the ground software on real frames; replace simulated evidence with real test records in Rev B.", ref="num2")
H2("10.2  Dependencies and procurement risks")
P("Integration depends on procurement (M05) and firmware (M07); recovery tests depend on fabrication (M06). Procurement risks: imported "
  "regulator lead time, counterfeit cells and BME280/BMP280 substitution, out-of-stock SD cards and antenna listings with a single unit in stock.")

# =========================================================================== APPENDICES
H1("Appendix A  Source references")
refs = [
    ("S1", "SEVA FIRST Innovation Challenge portal (home, participate, tracks, timeline, themes, register), Ministry of Education", "https://sevafirst.mic.gov.in"),
    ("S2", "News on AIR — Education Minister to inaugurate SEVA FIRST Innovation Challenge", "https://newsonair.gov.in/education-minister-pralhad-joshi-to-inaugurate-seva-first-innovation-challenge-in-bengaluru-tomorrow/"),
    ("S3", "ESA CanSat 2022–2023 Guidelines", "https://www.planete-sciences.org/espace/IMG/pdf/cansat_guidelines_2022-23_final-1.pdf"),
    ("S4", "ESA CanSat — technical information", "https://cansat.esa.int/about-cansat/technical-info/"),
    ("S5", "ESA CanSat — the mission", "https://cansat.esa.int/about-cansat/cansat-mission/"),
    ("S6", "CanSat Belgium Directives 2026–27", "https://www.innoviris.brussels/sites/default/files/2026-08/Directives%2026-27_0.pdf"),
    ("S7", "GSR 853(E) 2021 — Low power equipment 865–868 MHz for Short Range Devices (Exemption from Licence) Rules", "https://www.thc.nic.in/Central%20Governmental%20Rules/use%20of%20low%20power%20Equipment%20in%20the%20frequency%20band%20865%20to%20868%20MHz%20for%20Short%20Range%20Devices%20Exemption%20from%20Licence%20Rules,2021.pdf"),
    ("S8", "DoT clarification on ETA for 865–867 MHz equipment", "https://dot.gov.in/sites/default/files/Clarification%20ETA%20865-867%20MHz.pdf?download=1"),
    ("S9", "GSR 45(E) 2005 — 2.4 GHz licence exemption (legal database copy)", "https://www.legitquest.com/act/use-of-low-power-equipment-in-the-frequency-band-24-ghz-to-24835-ghz-exemption-from-licensing-requirement-rules-2005/9f50"),
    ("S10", "GSR 347(E) 2022 — 433.05–434.79 MHz (legal database copy)", "https://www.legitquest.com/act/use-of-low-power-radio-frequency-devices-in-the-frequency-band-43305-to-43479-mhz-exemption-from-license-rules-2022/BB37"),
    ("S11", "Drone (Amendment) Rules 2023, Ministry of Civil Aviation", "https://www.civilaviation.gov.in/sites/default/files/2024-04/Drone%20%28Amendment%29%20Rules%2C%202023.pdf"),
    ("S12", "Aircraft Rules 1937 (unofficial copy)", "https://bnblegal.com/bareact/the-aircraft-rules-1937/"),
    ("S13", "Digital Sky airspace map, DGCA", "https://digitalsky.dgca.gov.in/home"),
    ("S14", "Espressif ESP32-WROOM-32E/32UE datasheet v2.1", "https://documentation.espressif.com/esp32-wroom-32e_esp32-wroom-32ue_datasheet_en.pdf"),
    ("S15", "Espressif ESP32 Series datasheet v5.3", "https://documentation.espressif.com/esp32_datasheet_en.pdf"),
    ("S16", "Espressif ESP32-DevKitC V4 user guide", "https://docs.espressif.com/projects/esp-dev-kits/en/latest/esp32/esp32-devkitc/user_guide.html"),
    ("S17", "ESP-IDF GPIO reference (ESP32)", "https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-reference/peripherals/gpio.html"),
    ("S18", "ESP-IDF SPI master reference (ESP32)", "https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-reference/peripherals/spi_master.html"),
    ("S19", "ESP-IDF v4.4.4 ADC reference", "https://docs.espressif.com/projects/esp-idf/en/v4.4.4/esp32/api-reference/peripherals/adc.html"),
    ("S20", "Bosch Sensortec BME280 datasheet", "https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bme280-ds002.pdf"),
    ("S21", "ST LSM6DSOX datasheet DS12814 Rev 4", "https://www.st.com/resource/en/datasheet/lsm6dsox.pdf"),
    ("S22", "Adafruit LSM6DSOX 6-DoF breakout (4438)", "https://www.adafruit.com/product/4438"),
    ("S23", "TDK PCN 000614 — MPU-6050 end of life", "https://www.mouser.com/PCN/TDK_PCN_000614.pdf"),
    ("S24", "Semtech SX1276 datasheet Rev 7 (mirror) and product page", "https://cdn.sparkfun.com/assets/7/7/3/2/2/SX1276_Datasheet.pdf"),
    ("S25", "Ai-Thinker Ra-01H specification V1.0", "https://aithinker-static.oss-cn-shenzhen.aliyuncs.com/docs/Public%20Document%20Center/LoRa/lora/Specification/Ra-01H_V1.0%20Specification-20191029.pdf"),
    ("S26", "SD Physical Layer Simplified Specification v3.01 (mirror)", "https://www.cs.utexas.edu/~simon/378/resources/Part_1_Physical_Layer_Simplified_Specification_Ver_3.01_Final_100518.pdf"),
    ("S27", "Adafruit Micro SD SPI/SDIO breakout — 3 V only (4682)", "https://www.adafruit.com/product/4682"),
    ("S28", "Pololu S7V8F3 3.3 V step-up/step-down regulator (#2122)", "https://www.pololu.com/product/2122"),
    ("S29", "TP4056 datasheet (mirror)", "https://dlnmh9ip6v2uc.cloudfront.net/datasheets/Prototyping/TP4056.pdf"),
    ("S30", "Samsung SDI INR18650-35E specification (mirror)", "https://www.orbtronic.com/content/samsung-35e-datasheet-inr18650-35e.pdf"),
    ("S31", "Plantower PMS5003 manual V2.3 (Adafruit copy)", "https://cdn-shop.adafruit.com/product-files/3686/plantower-pms5003-manual_v2-3.pdf"),
    ("S32", "u-blox NEO-M8 data sheet UBX-15031086", "https://content.u-blox.com/sites/default/files/NEO-M8-FW3_DataSheet_UBX-15031086.pdf"),
    ("S33", "Supplier pages for every BOM line (accessed 24 Oct 2026)", "see STRATOS_BOM.xlsx, column 'Source URL'"),
    ("S34", "Reference footage sources", "see STRATOS_Reference_Footage_Register.xlsx"),
    ("S35", "Drishti IAS — SEVA FIRST at IISc", "https://www.drishtiias.com/state-pcs-current-affairs/seva-first-innovation-challenge-at-iisc-bengaluru"),
    ("S36", "IN-SPACe Model Rocketry/CanSat India Student Competition 2026 (news)", "https://www.passionateinmarketing.com/in-space-invites-applications-for-model-rocketry-and-cansat-india-student-competition-2026/"),
    ("S37", "PESO notification S.O. 5282(E), 11 Nov 2022", "https://peso.gov.in/web/sites/default/files/2024-01/Notification_ISRO_11-11-22.pdf"),
]
SM("Mirrors are third-party copies of manufacturer documents used where the manufacturer's host blocked automated access; check critical values against the manufacturer's current revision. All pages were accessed on 24 Oct 2026.")
TCAP("Source references")
TAB(["Ref", "Document", "URL"], [[a, b, c] for a, b, c in refs], [6, 44, 50], size=13)

H1("Appendix B  Simulation methodology")
P("The simulation exists to exercise the data pipeline, not to predict flight behaviour. It is deterministic (seed 2026) and uses the obviously "
  "synthetic base date 2000-01-01 so its outputs cannot be mistaken for test records.")
BUL("Profile: 30 s hold at 1,000 m above a 500 m site, 9 m/s descent, 30 s on the ground; ISA pressure; 6.5 K/km lapse with a 3 s first-order sensor lag; synthetic noise, pendulum motion and a landing spike.",
    "Records: 10 Hz, written by the same formatting code as the firmware specification (integer units, line CRC).",
    "Link: 1 packet/s at the GFSK time on air; faults injected exactly as listed in §5.6; RSSI synthetic; SNR 'nan' (GFSK).",
    "Processing: the same tracker and reconciliation modules that the ground station uses on real captures.",
    "Re-run: `python -m stratos_gs.simulate --out sim_output` (from the software folder).")

H1("Appendix C  Reference-footage attribution")
P("The team's montage contains footage from other creators' projects [S34]. It is **reference footage, not evidence of STRATOS hardware**, and must "
  "be captioned as such with attribution.")
TCAP("Reference-footage register (summary)")
TAB(["#", "Title / creator", "URL", "Recommendation"], [
    ["1", "Remote Serial Monitor for ESP8266 using WebSerial — IoT Projects Ideas (28 Apr 2025)", "https://www.youtube.com/watch?v=AboNyz5pGwo",
     "Short, captioned clip at most; better replaced by the STRATOS ground-station replay"],
    ["2", "How To Build Air Quality Monitor – Measure PM2.5, PM10, CO2, And Temperature — Electronics Innovation (4 Dec 2023)",
     "https://www.youtube.com/watch?v=phvoMO1-OTQ", "Caption as reference; its BME680/SDS011 sensors are not STRATOS parts"],
    ["3", "ESP32 Bitcoin Miner Controller — KiCad PCB Design — source NOT FOUND", "Team to supply",
     "Remove: its relay/control schematic must not be presented as STRATOS electronics; use the STRATOS schematic instead"],
], [5, 40, 27, 28], size=14)
SM("No Creative Commons licence was visible on either identified video; treat them as all rights reserved. This is not legal advice.")

H1("Appendix D  Software and firmware files")
TCAP("Software and firmware files")
TAB(["Path (in STRATOS_Source_Files.zip)", "Purpose", "Status"], [
    ["software/stratos_gs/packet.py", "Packet definition, CRC, encode/decode", "Tested (synthetic)"],
    ["software/stratos_gs/onboard_log.py", "Onboard CSV format with line CRC", "Tested (synthetic)"],
    ["software/stratos_gs/tracker.py", "Ground validation and sequence tracking", "Tested (synthetic)"],
    ["software/stratos_gs/ground_station.py", "Host application (live serial or replay)", "Replay tested; live mode not connected"],
    ["software/stratos_gs/reconcile.py", "Post-mission reconciliation", "Tested (synthetic)"],
    ["software/stratos_gs/simulate.py", "Synthetic mission and fault injection", "Runs"],
    ["software/tests/", "8 unit tests", "Pass (24 Oct 2026)"],
    ["firmware/common/stratos_packet.{h,c}", "Portable C packet and log-line code", "Host-compiled, matches Python"],
    ["firmware/payload/stratos_payload.ino", "Payload firmware draft (state machine)", "NOT compiled"],
    ["firmware/ground_rx/stratos_ground_rx.ino", "Receiver firmware draft", "NOT compiled"],
    ["design/*.py", "Baseline, layout, netlist, BOM, power, mass, registers (single source of truth)", "—"],
    ["cad/, schematic/, diagrams/, sheets/", "Generators for every drawing, diagram and workbook; build_all.sh rebuilds everything", "—"],
], [38, 40, 22], size=14)

H1("Appendix E  Actual test logs")
P("**None.** No STRATOS hardware test has been performed as of 24 Oct 2026. This appendix will hold the real logs, photographs and reports "
  "named in the evidence column of STRATOS_Test_Verification_Matrix.xlsx when the tests are run.")

# landscape appendix with drawing and schematic sheets
new_section("landscape")
H1("Appendix F  Drawing and schematic sheets", pb=False)
SM("Reduced copies; the full-resolution sheets are in STRATOS_Mechanical_Drawings.pdf and STRATOS_Electronics_Schematic.pdf.")
for i, t in enumerate(["General arrangement", "Internal arrangement and section", "Exploded view and parts list", "Part details"], start=1):
    IMG(os.path.join(SRC, f"STRATOS_Mechanical_Sheet{i}.png"), f"Figure F-{i}  Mechanical drawing sheet {i}: {t}.", scale=0.97,
        maxh=5.0 if i == 1 else 5.85, maxw=3000)
for i, t in enumerate(["Power and regulation", "Controller, storage, indicators", "Sensors and radio"], start=1):
    IMG(os.path.join(OUT, f"STRATOS_Electronics_Schematic_Sheet{i}.png"), f"Figure F-{4 + i}  Schematic sheet {i}: {t}.", scale=0.97,
        maxh=5.85, maxw=3000)

_js = json.dumps(sections)
for k, v in LABELS.items():
    _js = _js.replace("{T:" + k + "}", v)
assert "{T:" not in _js, "unresolved table label"
sections = json.loads(_js)
json.dump({"title": "STRATOS Engineering Dossier", "description": "SEVA FIRST Innovation Challenge 2026 — Team Nothingburger — Rev A",
           "header": "STRATOS Engineering Dossier · Team Nothingburger · Rev A · 24 Oct 2026", "sections": sections},
          open(os.path.join(HERE, "content.json"), "w"), indent=1)
print("ok", sum(len(s["blocks"]) for s in sections), "blocks", fmt(total), fmt(payload_prod))
