// Render the STRATOS dossier from content.json (built by content.py) with docx-js.
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, ImageRun, PageBreak, Header, Footer, PageNumber,
  TableOfContents, LevelFormat, PageOrientation, ExternalHyperlink, TabStopType,
  Bookmark, InternalHyperlink, Tab, LeaderType,
} = require("docx");

const C = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const OUT = process.argv[3];
const FONT = "Arial";
const INK = "1B2733", ACCENT = "1F3A5F", MUTED = "5B6875", WARN = "7A4A00";
const A4 = { width: 11906, height: 16838 };
const MARGIN = 1134;
const PORTRAIT_W = A4.width - 2 * MARGIN;        // 9638 DXA
const LANDSCAPE_W = A4.height - 2 * MARGIN;      // 14570 DXA

// inline markup: **bold**, *italic*, `code`
function runs(text, base = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, font: FONT, ...base }));
    else if (t.startsWith("`")) out.push(new TextRun({ text: t.slice(1, -1), font: "Consolas", ...base, size: (base.size || 20) - 2 }));
    else out.push(new TextRun({ text: t.slice(1, -1), italics: true, font: FONT, ...base }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, ...base }));
  return out;
}

const border = { style: BorderStyle.SINGLE, size: 4, color: "B8C2CC" };
const borders = { top: border, bottom: border, left: border, right: border };

function table(b, width) {
  const total = b.widths.reduce((a, x) => a + x, 0);
  const cols = b.widths.map((w) => Math.round((w / total) * width));
  const diff = width - cols.reduce((a, x) => a + x, 0);
  cols[cols.length - 1] += diff;
  const fs_ = b.size || 16;
  const rows = [];
  const mkCell = (txt, j, head, fill) => new TableCell({
    borders, width: { size: cols[j], type: WidthType.DXA },
    shading: head ? { fill: "1F3A5F", type: ShadingType.CLEAR, color: "auto" } : (fill ? { fill, type: ShadingType.CLEAR, color: "auto" } : undefined),
    margins: { top: 50, bottom: 50, left: 80, right: 80 },
    children: String(txt).split("\n").map((line) => new Paragraph({
      spacing: { before: 0, after: 0 },
      children: runs(line, { size: fs_, color: head ? "FFFFFF" : INK, bold: head ? true : undefined }),
    })),
  });
  rows.push(new TableRow({ tableHeader: true, children: b.header.map((h, j) => mkCell(h, j, true)) }));
  b.rows.forEach((r, i) => {
    const fill = (b.highlight && b.highlight.includes(i)) ? "FFF4D6" : (i % 2 === 1 ? "F5F7FA" : undefined);
    rows.push(new TableRow({ children: r.map((c, j) => mkCell(c, j, false, fill)) }));
  });
  return new Table({ width: { size: width, type: WidthType.DXA }, columnWidths: cols, rows });
}

function image(b, width) {
  const maxPx = Math.floor((width / 1440) * 96 * (b.scale || 1));
  let w = Math.min(maxPx, b.px[0]);
  let h = Math.round((w * b.px[1]) / b.px[0]);
  if (b.maxh && h > b.maxh * 96) { h = Math.round(b.maxh * 96); w = Math.round((h * b.px[0]) / b.px[1]); }
  return new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { before: 120, after: 60 },
    children: [new ImageRun({ type: "png", data: fs.readFileSync(b.path), transformation: { width: w, height: h },
      altText: { title: b.alt || "figure", description: b.alt || "figure", name: path.basename(b.path) } })],
  });
}

function block(b, width) {
  switch (b.t) {
    case "h1": return [new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: b.pb !== false, children: anchored(b) })];
    case "h2": return [new Paragraph({ heading: HeadingLevel.HEADING_2, children: anchored(b) })];
    case "h3": return [new Paragraph({ heading: HeadingLevel.HEADING_3, children: runs(b.x) })];
    case "p": return [new Paragraph({ spacing: { after: 120 }, children: runs(b.x) })];
    case "small": return [new Paragraph({ spacing: { after: 80 }, children: runs(b.x, { size: 16, color: MUTED }) })];
    case "note": return [new Paragraph({
      spacing: { before: 80, after: 140 }, shading: { fill: "FFF4D6", type: ShadingType.CLEAR, color: "auto" },
      border: { left: { style: BorderStyle.SINGLE, size: 18, color: "B26A00", space: 6 } },
      children: runs(b.x, { color: WARN, size: 19 }) })];
    case "bullets": return b.items.map((it) => new Paragraph({ numbering: { reference: "bul", level: 0 }, spacing: { after: 60 }, children: runs(it) }));
    case "numbers": return b.items.map((it) => new Paragraph({ numbering: { reference: b.ref || "num", level: 0 }, spacing: { after: 60 }, children: runs(it) }));
    case "table": return [table(b, width), new Paragraph({ spacing: { after: 60 }, children: [] })];
    case "img": return [image(b, width)];
    case "cap": return [new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: runs(b.x, { size: 17, italics: true, color: MUTED }) })];
    case "tcap": return [new Paragraph({ spacing: { before: 160, after: 60 }, keepNext: true, children: runs(b.x, { size: 18, bold: true, color: ACCENT }) })];
    case "pb": return [new Paragraph({ children: [new PageBreak()] })];
    case "toc": return toc(b, width);
    case "code": return b.x.split("\n").map((line) => new Paragraph({ spacing: { before: 0, after: 0 },
      shading: { fill: "F5F7FA", type: ShadingType.CLEAR, color: "auto" },
      children: [new TextRun({ text: line || " ", font: "Consolas", size: 16, color: INK })] }));
    case "link": return [new Paragraph({ spacing: { after: 60 }, children: [
      ...runs(b.pre || ""), new ExternalHyperlink({ link: b.url, children: [new TextRun({ text: b.x, style: "Hyperlink", font: FONT, size: 18 })] }) ] })];
    case "cover": return cover(b, width);
    default: throw new Error("unknown block " + b.t);
  }
}

function anchored(b) {
  return b.anchor ? [new Bookmark({ id: b.anchor, children: runs(b.x) })] : runs(b.x);
}

// Contents list with cached page numbers; toc_field.py wraps these paragraphs in a Word TOC field
function toc(b, width) {
  const out = [new Paragraph({ pageBreakBefore: true, spacing: { before: 200, after: 120 },
    children: [new TextRun({ text: "Contents", font: FONT, size: 32, bold: true, color: ACCENT })] })];
  out.push(new Paragraph({ spacing: { after: 160 }, children: runs(b.note || "", { size: 16, color: MUTED }) }));
  b.entries.forEach((e) => out.push(new Paragraph({
    style: e.level === 1 ? "TOC1" : "TOC2",
    tabStops: [{ type: TabStopType.RIGHT, position: width, leader: LeaderType.DOT }],
    children: [new InternalHyperlink({ anchor: e.anchor, children: [
      new TextRun({ text: e.text, font: FONT, size: e.level === 1 ? 20 : 19, bold: e.level === 1 ? true : undefined, color: INK }),
      new TextRun({ children: [new Tab(), String(e.page)], font: FONT, size: e.level === 1 ? 20 : 19, color: INK })] })],
  })));
  return out;
}

function cover(b, width) {
  const out = [];
  out.push(new Paragraph({ spacing: { before: 600, after: 120 }, children: [new TextRun({ text: "STRATOS", font: FONT, size: 72, bold: true, color: ACCENT })] }));
  out.push(new Paragraph({ spacing: { after: 80 }, children: [new TextRun({ text: b.subtitle, font: FONT, size: 32, color: INK })] }));
  out.push(new Paragraph({ spacing: { after: 300 }, border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: ACCENT, space: 4 } },
    children: [new TextRun({ text: b.tagline, font: FONT, size: 22, color: MUTED })] }));
  out.push(image({ path: b.image, px: b.px }, width));
  b.lines.forEach((l) => out.push(new Paragraph({ spacing: { after: 60 }, children: runs(l, { size: 21 }) })));
  out.push(new Paragraph({ spacing: { before: 200, after: 0 }, shading: { fill: "FFF4D6", type: ShadingType.CLEAR, color: "auto" },
    border: { left: { style: BorderStyle.SINGLE, size: 18, color: "B26A00", space: 6 } },
    children: runs(b.status, { size: 20, bold: true, color: WARN }) }));
  return out;
}

function header(text) {
  return new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "B8C2CC", space: 2 } },
    children: [new TextRun({ text, font: FONT, size: 15, color: MUTED })] })] });
}
function footer() {
  return new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "Proposed design — no STRATOS hardware has been built or tested · Page ", font: FONT, size: 15, color: MUTED }),
    new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 15, color: MUTED }),
    new TextRun({ text: " of ", font: FONT, size: 15, color: MUTED }),
    new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 15, color: MUTED })] })] });
}

const sections = C.sections.map((s) => {
  const land = s.orientation === "landscape";
  const width = land ? LANDSCAPE_W : PORTRAIT_W;
  const children = [];
  s.blocks.forEach((b) => block(b, width).forEach((x) => children.push(x)));
  return {
    properties: { page: { size: { width: A4.width, height: A4.height, orientation: land ? PageOrientation.LANDSCAPE : PageOrientation.PORTRAIT },
      margin: { top: MARGIN, bottom: MARGIN, left: MARGIN, right: MARGIN, header: 560, footer: 560 } }, titlePage: !!s.titlePage },
    headers: { default: header(C.header) }, footers: { default: footer() }, children,
  };
});

const doc = new Document({
  creator: "Team Nothingburger", title: C.title, description: C.description,
  styles: {
    default: { document: { run: { font: FONT, size: 20, color: INK } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: FONT, color: ACCENT }, paragraph: { spacing: { before: 200, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 25, bold: true, font: FONT, color: ACCENT }, paragraph: { spacing: { before: 260, after: 120 }, outlineLevel: 1, keepNext: true } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 21, bold: true, font: FONT, color: INK }, paragraph: { spacing: { before: 180, after: 80 }, outlineLevel: 2, keepNext: true } },
      { id: "TOC1", name: "toc 1", basedOn: "Normal", next: "Normal", run: { size: 20, bold: true, font: FONT, color: INK },
        paragraph: { spacing: { before: 100, after: 30 }, tabStops: [{ type: TabStopType.RIGHT, position: PORTRAIT_W, leader: LeaderType.DOT }] } },
      { id: "TOC2", name: "toc 2", basedOn: "Normal", next: "Normal", run: { size: 19, font: FONT, color: INK },
        paragraph: { spacing: { before: 0, after: 20 }, indent: { left: 360 }, tabStops: [{ type: TabStopType.RIGHT, position: PORTRAIT_W, leader: LeaderType.DOT }] } },
    ],
  },
  numbering: { config: [
    { reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] },
    { reference: "num", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
    { reference: "num2", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
  ] },
  sections,
});
Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(OUT, buf); console.log("wrote", OUT); });
