"""Wrap the pre-rendered Contents paragraphs (styles TOC1/TOC2) in a Word TOC field so Word can refresh them.
Usage: python3 toc_field.py file.docx   (edits in place)"""
import re, shutil, sys, zipfile, os, tempfile
src = sys.argv[1]
with zipfile.ZipFile(src) as z:
    names = z.namelist()
    data = {n: z.read(n) for n in names}
xml = data["word/document.xml"].decode("utf8")
paras = [m for m in re.finditer(r"<w:p>(?:(?!</w:p>).)*?<w:pStyle w:val=\"TOC[12]\"/>.*?</w:p>", xml, re.S)]
assert paras, "no TOC paragraphs found"
first, last = paras[0], paras[-1]
begin = ('<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> TOC \\o "1-2" \\h \\z \\u </w:instrText></w:r>'
         '<w:r><w:fldChar w:fldCharType="separate"/></w:r>')
end = '<w:r><w:fldChar w:fldCharType="end"/></w:r>'
lp = last.group(0)
new_last = lp[:-len("</w:p>")] + end + "</w:p>"
fp = first.group(0) if first is not last else new_last
i = fp.index("</w:pPr>") + len("</w:pPr>")
new_first = fp[:i] + begin + fp[i:]
if first is last:
    xml = xml[:first.start()] + new_first + xml[first.end():]
else:
    xml = xml[:last.start()] + new_last + xml[last.end():]
    xml = xml[:first.start()] + new_first + xml[first.end():]
data["word/document.xml"] = xml.encode("utf8")
fd, tmp = tempfile.mkstemp(suffix=".docx"); os.close(fd)
with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        z.writestr(n, data[n])
shutil.move(tmp, src)
print("TOC field wrapped around", len(paras), "entries")
