"""Find the page of every TOC entry in a PDF rendering of the dossier. Usage: python3 toc_pages.py dossier.pdf content.json out.json"""
import json, re, subprocess, sys
pdf, content, out = sys.argv[1:4]
txt = subprocess.run(["pdftotext", "-layout", pdf, "-"], capture_output=True, text=True).stdout
pages = txt.split("\f")
norm = lambda s: re.sub(r"\s+", " ", s).strip()
is_toc = [sum(1 for l in p.splitlines() if re.search(r"\.{4,}\s*\d+\s*$", l)) >= 5 for p in pages]
C = json.load(open(content))
entries = [e for s in C["sections"] for b in s["blocks"] if b["t"] == "toc" for e in b["entries"]]
res, start, missing = {}, 0, []
for e in entries:
    target = norm(e["text"].replace("**", "").replace("*", ""))
    found = None
    for k in range(start, len(pages)):
        if is_toc[k]:
            continue
        if any(norm(l) == target for l in pages[k].splitlines()):
            found = k
            break
    if found is None:
        missing.append(e["text"])
        continue
    res[e["anchor"]] = found + 1
    start = found
json.dump(res, open(out, "w"), indent=1)
print("pages found", len(res), "of", len(entries), "toc pages", [i + 1 for i, t in enumerate(is_toc) if t], "missing", missing)
