#!/usr/bin/env bash
# Build STRATOS_Engineering_Dossier.docx: content -> docx-js -> TOC field; two passes so the Contents page numbers are filled in.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; OUTDOC="${1:-$HERE/../out/STRATOS_Engineering_Dossier.docx}"
SCR="${2:-$HERE/../work/docx_check}"; mkdir -p "$SCR"
SOFFICE="${SOFFICE:-soffice}"
export NODE_PATH="${NODE_PATH:-/home/claude/.npm-global/lib/node_modules}"
one_pass() { python3 "$HERE/content.py"; node "$HERE/render.js" "$HERE/content.json" "$OUTDOC"; python3 "$HERE/toc_field.py" "$OUTDOC"; }
rm -f "$HERE/toc_pages.json"; one_pass
cp "$OUTDOC" "$SCR/pass1.docx"; (cd "$SCR" && $SOFFICE --headless --convert-to pdf pass1.docx >/dev/null 2>&1)
python3 "$HERE/toc_pages.py" "$SCR/pass1.pdf" "$HERE/content.json" "$HERE/toc_pages.json"
one_pass
echo "built $OUTDOC"
