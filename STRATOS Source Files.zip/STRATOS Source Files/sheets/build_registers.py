"""Build risk register, roadmap, test/verification matrix, reference-footage register and storage budget."""
import os, sys, datetime as dt
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "design"))
from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.styles import PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from xlsx_common import *
from registers import RISKS, LIKELIHOOD, CONSEQUENCE, BANDS, REQUIREMENTS
from baseline import RECORD_PERIOD_MS, TX_EVERY_N, MISSION_LOG_H, RING_BUFFER_RECORDS, RADIO

OUT = sys.argv[1]
TODAY = "2026-10-24"

# =============================================================== risk register
wb = Workbook()
ws = wb.active; ws.title = "Risk register"
title(ws, "STRATOS — Technical and operational risk register (Rev A, 24 Oct 2026)",
      "Score = Likelihood × Consequence. No mitigation has yet been verified by a hardware test. Owners are roles: assign a named team member to each.")
cols = ["ID", "Risk", "Cause", "Effect", "Likelihood (1–5)", "Consequence (1–5)", "Score (L×C)", "Rating",
        "Proposed mitigation", "Verification method", "Owner (role)", "Mitigation status", "Named owner (team to fill)"]
header(ws, 4, cols, [6, 22, 32, 30, 11, 12, 9, 10, 52, 40, 16, 30, 16])
for i, (rid, t, cause, eff, L, C, mit, ver, owner, st) in enumerate(RISKS, start=5):
    vals = [rid, t, cause, eff, L, C, f"=E{i}*F{i}",
            f'=IF(G{i}>=17,"Critical",IF(G{i}>=10,"High",IF(G{i}>=5,"Medium","Low")))', mit, ver, owner, st, ""]
    for j, v in enumerate(vals, start=1):
        c = put(ws, i, j, v, color=(BLUE if j in (5, 6) else "000000"),
                fill=(INPUT_FILL if j == 13 else (WARN_FILL if "not yet verified" in str(v) else None)))
    ws.row_dimensions[i].height = 75
last = 4 + len(RISKS)
red = PatternFill("solid", fgColor="F4C7C3"); amber = PatternFill("solid", fgColor="FCE8B2"); green = PatternFill("solid", fgColor="D9EAD3")
ws.conditional_formatting.add(f"H5:H{last}", CellIsRule(operator="equal", formula=['"Critical"'], fill=red))
ws.conditional_formatting.add(f"H5:H{last}", CellIsRule(operator="equal", formula=['"High"'], fill=red))
ws.conditional_formatting.add(f"H5:H{last}", CellIsRule(operator="equal", formula=['"Medium"'], fill=amber))
ws.conditional_formatting.add(f"H5:H{last}", CellIsRule(operator="equal", formula=['"Low"'], fill=green))
dv = DataValidation(type="whole", operator="between", formula1="1", formula2="5", allow_blank=False)
ws.add_data_validation(dv); dv.add(f"E5:F{last}")
ws.freeze_panes = "C5"
notes(ws, last + 2, ["Legend: blue numbers are judgement inputs (edit them); Score and Rating are formulas; yellow cells are for the team to fill.",
                     "Mitigation status vocabulary: 'Proposed — not yet verified' | 'Partly demonstrated in software simulation (synthetic data); hardware test pending' | 'Verified by test (cite evidence)'.",
                     "No risk is marked 'Verified by test' because no STRATOS hardware has been built or tested (24 Oct 2026)."])

ws2 = wb.create_sheet("Rating scales")
title(ws2, "Rating scales used in the register")
header(ws2, 4, ["Value", "Likelihood", "Meaning"], [8, 18, 60])
for i, (v, n, d) in enumerate(LIKELIHOOD, start=5):
    put(ws2, i, 1, v); put(ws2, i, 2, n); put(ws2, i, 3, d)
header(ws2, 11, ["Value", "Consequence", "Meaning"])
for i, (v, n, d) in enumerate(CONSEQUENCE, start=12):
    put(ws2, i, 1, v); put(ws2, i, 2, n); put(ws2, i, 3, d)
header(ws2, 18, ["Score from", "Score to", "Rating"])
for i, (lo, hi, n) in enumerate(BANDS, start=19):
    put(ws2, i, 1, lo); put(ws2, i, 2, hi); put(ws2, i, 3, n)

ws3 = wb.create_sheet("Heat map")
title(ws3, "Risk heat map — number of risks in each Likelihood × Consequence cell (formulas)")
put(ws3, 4, 1, "Likelihood ↓ / Consequence →", bold=True, fill=SUB_FILL)
for c in range(1, 6):
    put(ws3, 4, c + 1, c, bold=True, fill=SUB_FILL)
for r in range(5, 0, -1):
    row = 5 + (5 - r)
    put(ws3, row, 1, r, bold=True, fill=SUB_FILL)
    for c in range(1, 6):
        cell = put(ws3, row, c + 1, f"=COUNTIFS('Risk register'!$E$5:$E${last},{r},'Risk register'!$F$5:$F${last},{c})")
        sc = r * c
        cell.fill = red if sc >= 10 else (amber if sc >= 5 else green)
        cell.alignment = Alignment(horizontal="center", vertical="center")
ws3.column_dimensions["A"].width = 28
wb.save(os.path.join(OUT, "STRATOS_Risk_Register.xlsx"))

# =============================================================== roadmap
wb = Workbook(); ws = wb.active; ws.title = "Roadmap"
title(ws, "STRATOS — Development roadmap (Rev A, 24 Oct 2026)",
      "Planned dates are a proposal from 24 Oct 2026. Depends on: FS = finish-to-start; SS + n d = may start n days after the predecessor starts, because only part of it is needed "
      "(e.g. one firmware module or one delivery). Competition dates are from the SEVA FIRST portal, whose own pages conflict (see 'Schedule conflict').")
cols = ["ID", "Milestone", "Planned start", "Planned finish", "Duration (days)", "Actual start", "Actual finish", "Status",
        "Depends on", "Responsible (role)", "Evidence required for completion", "Named owner (team to fill)"]
header(ws, 4, cols, [6, 36, 12, 12, 10, 12, 12, 30, 14, 18, 52, 16])
D = dt.date
M = [
    ("M01", "Design dossier Rev A (this package) — draft", D(2026, 10, 24), D(2026, 10, 24), None, None,
     "Draft prepared with AI assistance (24 Oct) — team review pending", "—", "Systems lead (review)", "Dossier, drawings, schematic, budgets; team review sign-off"),
    ("M02", "Ground-station + reconciliation software prototype (simulation)", D(2026, 10, 24), D(2026, 10, 24), None, None,
     "Prototype drafted with AI assistance; runs on simulated data only — not hardware-validated", "—", "Ground-station lead (review)", "8 unit tests passing; simulated reconciliation report"),
    ("M03", "Confirm entry route, level, theme and deadline with institution coordinator", D(2026, 10, 24), D(2026, 10, 27), None, None,
     "Not started — URGENT (deadline may be 24 Oct)", "—", "Project manager", "Written confirmation from coordinator / portal"),
    ("M04", "Design review and component-selection freeze", D(2026, 10, 26), D(2026, 10, 28), None, None, "Not started", "M01", "Systems lead",
     "Review checklist signed; BOM status → selected"),
    ("M05", "Procurement (domestic parts; Pololu import or LDO fallback)", D(2026, 10, 28), D(2026, 11, 7), None, None, "Not started", "M04",
     "Project manager", "Order confirmations; parts received and inspected (chip IDs, cell capacity)"),
    ("M06", "Mechanical fabrication (print caps, spine, shell; cut yoke and rods)", D(2026, 10, 29), D(2026, 11, 8), None, None, "Not started", "M04 (FS); M05 structural materials, ordered first (SS + 1 d)",
     "Mechanical lead", "Printed parts measured against drawing; fit check photos of the actual parts"),
    ("M07", "Firmware development (incremental, on host then ESP32)", D(2026, 10, 28), D(2026, 11, 20), None, None, "Not started (draft sketch exists, uncompiled)",
     "M04", "Firmware lead", "Compiled firmware under version control; module tests"),
    ("M08", "Sensor testing (BME280, IMU) on the bench", D(2026, 11, 3), D(2026, 11, 8), None, None, "Not started", "M05 sensors received (SS + 6 d); M07 sensor module (SS + 6 d)", "Electronics lead",
     "Serial logs; comparison with reference instruments"),
    ("M09", "Storage verification (microSD logging, power-cut test)", D(2026, 11, 5), D(2026, 11, 11), None, None, "Not started", "M05 storage parts received (SS + 8 d); M07 logger module (SS + 8 d)",
     "Firmware lead", "Log files; reconciliation of onboard lines; power-cut results"),
    ("M10", "Telemetry verification (radio pair, bench then range test)", D(2026, 11, 8), D(2026, 11, 16), None, None, "Not started", "M05 radios received (SS + 11 d); M07 radio module (SS + 11 d)",
     "Ground-station lead", "Transmitter and receiver logs; packet-error rate vs distance"),
    ("M11", "System integration on the bench", D(2026, 11, 17), D(2026, 11, 22), None, None, "Not started", "M06, M08, M09, M10 (FS)",
     "Systems lead", "Integrated bench run ≥ 30 min; photos of the actual assembly"),
    ("M12", "Integrated ground testing (4 h run, induced faults, reconciliation)", D(2026, 11, 23), D(2026, 11, 26), None, None, "Not started", "M11 (FS)",
     "Ground-station lead", "4 h logs; reconciliation reports; measured current"),
    ("M13", "Recovery testing (parachute drop tests from a fixed structure)", D(2026, 11, 18), D(2026, 11, 26), None, None, "Not started", "M06 (FS)",
     "Mechanical lead", "Drop-test videos and timing; descent-rate calculation; pull test"),
    ("M14", "Final validation and documentation (dossier Rev B with real evidence)", D(2026, 11, 27), D(2026, 11, 30), None, None, "Not started",
     "M12, M13 (FS)", "Project manager", "Updated dossier; test matrix statuses backed by evidence"),
]
for i, (mid, name, ps, pf, as_, af, st, dep, owner, ev) in enumerate(M, start=5):
    vals = [mid, name, ps, pf, f"=D{i}-C{i}+1", as_ or "", af or "", st, dep, owner, ev, ""]
    for j, v in enumerate(vals, start=1):
        c = put(ws, i, j, v, fmt=("yyyy-mm-dd" if j in (3, 4, 6, 7) else None), color=(BLUE if j in (3, 4) else "000000"),
                fill=(INPUT_FILL if j == 12 else None))
    ws.row_dimensions[i].height = 42
last = 4 + len(M)
ws.conditional_formatting.add(f"H5:H{last}", FormulaRule(formula=[f'ISNUMBER(SEARCH("URGENT",H5))'], fill=red))
ws.conditional_formatting.add(f"H5:H{last}", FormulaRule(formula=[f'ISNUMBER(SEARCH("Complete",H5))'], fill=green))
ws.freeze_panes = "C5"
# Gantt (weeks)
g0 = 14
weeks = [D(2026, 10, 19) + dt.timedelta(days=7 * k) for k in range(9)]
for k, wk in enumerate(weeks):
    c = put(ws, 4, g0 + k, wk, bold=True, fill=SUB_FILL, fmt="dd mmm")
    ws.column_dimensions[chr(ord("A") + g0 + k - 1)].width = 7
for i in range(5, last + 1):
    for k in range(len(weeks)):
        col = chr(ord("A") + g0 + k - 1)
        put(ws, i, g0 + k, f'=IF(AND({col}$4<=$D{i},{col}$4+6>=$C{i}),"■","")')
notes(ws, last + 2, ["Status vocabulary: Not started | In progress | Complete (cite evidence) | Complete in simulation only. No future task is marked complete.",
                     "Blue dates are planning inputs; edit them and Duration and the week bars update. Week columns show the Monday of each week.",
                     "Dates assume parts arrive within 10 days of ordering; the Pololu import is the long-lead item (LDO fallback listed in the BOM)."])
ws2 = wb.create_sheet("Schedule conflict")
title(ws2, "Competition dates and the schedule conflict")
header(ws2, 4, ["Source", "Submission window", "Screening", "Finale", "URL"], [36, 26, 18, 24, 60])
rows = [("SEVA FIRST portal — home page", "25 Sep – 24 Oct 2026", "from 25 Oct", "30 Nov – 15 Dec 2026", "https://sevafirst.mic.gov.in"),
        ("SEVA FIRST portal — timeline page ('indicative')", "25 Sep – 6 Nov 2026", "from 7 Nov", "30 Nov – 15 Dec 2026", "https://sevafirst.mic.gov.in/timeline"),
        ("News reports (Careers360, Drishti)", "—", "—", "National finale 10–17 Dec 2026", "https://news.careers360.com/sfic-2026-education-minister-joshi-launches-seva-first-innovation-challenge-school-college-itis-polytechnics-students-apply-oct-24")]
for i, r in enumerate(rows, start=5):
    for j, v in enumerate(r, start=1):
        put(ws2, i, j, v)
notes(ws2, 9, ["Conflict: on 24 Oct 2026 the concept-submission window may already be closing. The portal is the South Zone edition and does not list Madhya Pradesh.",
               "Recovery plan: (1) confirm route and deadline with the institution coordinator today; (2) submit the concept with this dossier as evidence of design maturity;",
               "(3) if shortlisted, aim for a working BENCH prototype (sensing + logging + radio + reconciliation on real data) before the finale; no flight is planned before the finale;",
               "(4) if not eligible this cycle, continue the roadmap unchanged and target the next edition or a CanSat competition with published rules."])
wb.save(os.path.join(OUT, "STRATOS_Development_Roadmap.xlsx"))

# =============================================================== verification matrix
wb = Workbook(); ws = wb.active; ws.title = "Verification matrix"
title(ws, "STRATOS — Test and verification matrix (Rev A, 24 Oct 2026)",
      "Acceptance criteria are defined before testing. 'Demonstrated in software simulation' means synthetic data only; no hardware requirement has been verified.")
cols = ["ID", "Requirement", "Source / rationale", "Verification method", "Procedure (summary)", "Acceptance criterion",
        "Evidence required", "Status", "Evidence reference", "Test date", "Result"]
header(ws, 4, cols, [7, 36, 20, 14, 40, 44, 26, 34, 40, 11, 12])
EVREF = {"FR-05": "software/tests: test_line_roundtrip_and_truncation; simulation F7 (synthetic)",
         "FR-07": "software/tests: test_gap_corruption_duplicate; simulated capture replay (synthetic)",
         "FR-08": "software/tests: test_gap_corruption_duplicate (synthetic)",
         "FR-09": "software/tests: test_reconciliation_classifies_injected_faults; reconciliation_report.md (synthetic)",
         "FR-10": "software/tests: test_absent_value_is_not_zero (synthetic)",
         "FR-11": "STRATOS_Power_Budget.xlsx (calculation)", "FR-12": "cad_report.json envelope check (CAD)",
         "FR-13": "Dossier §6.7 parachute sizing (calculation)", "FR-15": "Dossier §1.3 and §6.5 radio configuration vs GSR 853(E)"}
for i, (rid, req, src, meth, proc, acc, ev, st) in enumerate(REQUIREMENTS, start=5):
    vals = [rid, req, src, meth, proc, acc, ev, st, EVREF.get(rid, ""), "", ""]
    for j, v in enumerate(vals, start=1):
        put(ws, i, j, v, fill=(OK_FILL if "simulation" in str(v) and j == 8 else (INPUT_FILL if j in (10, 11) else None)))
    ws.row_dimensions[i].height = 62
ws.freeze_panes = "C5"
notes(ws, 5 + len(REQUIREMENTS) + 1, ["Status vocabulary: Not started | Analysis complete | Demonstrated in software simulation (synthetic data) | Passed (hardware, cite evidence) | Failed.",
                                       "Yellow cells (Test date, Result) are filled only when a real test has been run. Software unit tests: python -m unittest discover -s tests (8 pass, 24 Oct 2026)."])
wb.save(os.path.join(OUT, "STRATOS_Test_Verification_Matrix.xlsx"))

# =============================================================== reference footage register
wb = Workbook(); ws = wb.active; ws.title = "Reference footage"
title(ws, "STRATOS — Reference-footage register (external material, NOT STRATOS hardware)",
      "Every clip in the team's montage comes from another creator's project and must be labelled 'Reference footage' with attribution.")
cols = ["#", "Original title", "Creator / channel", "Source URL", "Published", "Licence seen", "Segment used in montage",
        "Technical subject shown", "Relationship to STRATOS", "Reuse / attribution requirement", "Recommendation"]
header(ws, 4, cols, [4, 34, 24, 40, 12, 22, 20, 34, 40, 40, 40])
rows = [
    (1, "Remote Serial Monitor for ESP8266 using WebSerial", "IoT Projects Ideas (@iotprojectsideas); article by Alsan Parajuli",
     "https://www.youtube.com/watch?v=AboNyz5pGwo", "2025-04-28",
     "Not visible on page (no Creative Commons marker); companion article marked 'All Rights Reserved'",
     "TEAM TO FILL (mm:ss–mm:ss)",
     "ESP8266 serial output viewed in a web browser over Wi-Fi (WebSerial library)",
     "General example of viewing live embedded data. STRATOS uses a radio link + USB serial + Python instead; WebSerial is not part of the design.",
     "Treat as all rights reserved: obtain permission or limit to a short, attributed reference clip.",
     "Use only a few seconds, captioned 'Reference footage: IoT Projects Ideas'. Better: replace with the STRATOS ground-station replay."),
    (2, "How To Build Air Quality Monitor – Measure PM2.5, PM10, CO2, And Temperature", "Electronics Innovation (@electronicsinnovation)",
     "https://www.youtube.com/watch?v=phvoMO1-OTQ", "2023-12-04", "Not visible on page (no Creative Commons marker)",
     "TEAM TO FILL (mm:ss–mm:ss)",
     "ESP8266 with BME680 and SDS011 sensors; environmental measurement display",
     "General example of sensor integration. STRATOS uses BME280 + LSM6DSOX and deliberately excludes a particulate sensor (power, airflow, volume).",
     "Treat as all rights reserved: obtain permission or limit to a short, attributed reference clip.",
     "Caption 'Reference footage: Electronics Innovation'; do not imply its sensors are STRATOS hardware."),
    (3, "ESP32 Bitcoin Miner Controller — KiCad PCB Design (title as supplied by the team)", "NOT FOUND",
     "NOT FOUND — team must supply the original URL", "—", "Unknown", "TEAM TO FILL",
     "Relay/control schematic and PCB design in KiCad",
     "Unrelated to STRATOS. Its schematic must NOT be presented as the STRATOS electronics design.",
     "Source unidentified, so attribution and licence cannot be checked.",
     "Remove from the montage. Replace with the STRATOS schematic sheets or the CAD exploded view from this dossier."),
]
for i, r in enumerate(rows, start=5):
    for j, v in enumerate(r, start=1):
        put(ws, i, j, v, fill=(INPUT_FILL if "TEAM TO FILL" in str(v) else (WARN_FILL if "NOT FOUND" in str(v) else None)))
    ws.row_dimensions[i].height = 95
notes(ws, 10, ["Searched 24 Oct 2026. Candidates considered but not matching item 3: MAKER-VINOD 'The ESP32 Miner Board – Mining Duino Coin' (https://www.youtube.com/watch?v=B-pOQ3jTFe0);",
               "iNimbleSloth 'My Homemade USB Duino-Coin Miner in KiCAD' (https://www.youtube.com/watch?v=QOA7npsJhVo). Do not assume either is the source.",
               "This register is not legal advice. Copyright exceptions vary; when in doubt, ask the creator or replace the clip with STRATOS-specific material."])
wb.save(os.path.join(OUT, "STRATOS_Reference_Footage_Register.xlsx"))

# =============================================================== storage budget
wb = Workbook(); ws = wb.active; ws.title = "Storage budget"
title(ws, "STRATOS — Storage and sampling budget (Rev A, 24 Oct 2026)",
      "Yellow cells with blue text are inputs; everything else is calculated. Record sizes come from the format specification (STRATOS_Packet_Format.md).")
header(ws, 4, ["Parameter", "Value", "Unit", "Basis / source"], [52, 14, 12, 70])
inputs = [
    ("Record period (all sensors in one record)", RECORD_PERIOD_MS, "ms", "PROPOSED: 10 Hz; BME280 output ≈13 Hz in normal mode, IMU ODR 104 Hz sampled at 10 Hz"),
    ("Design logging window per session", MISSION_LOG_H, "h", "ASSUMED: ESA CanSat asks for 4 h of continuous operation"),
    ("Worst-case CSV line incl. CR LF", 124, "bytes", "Format spec: 122 characters max + CR LF"),
    ("Typical CSV line incl. CR LF", 70, "bytes", "Mean of 1,710 simulated lines = 69.9 bytes (synthetic)"),
    ("File header (2 comment lines + column names)", 200, "bytes", "Format spec (rounded up)"),
    ("Sessions (files) per mission day", 10, "files", "ASSUMED: each power-up creates a new file"),
    ("FAT32 cluster size", 32768, "bytes", "Typical default for 16–32 GB cards (verify after formatting)"),
    ("Card capacity (nominal)", 16, "GB", "BOM P08: 16 GB card"),
    ("Usable fraction after formatting", 0.93, "—", "ASSUMED: decimal GB vs GiB + file-system overhead"),
    ("Telemetry interval", RECORD_PERIOD_MS * TX_EVERY_N, "ms", "PROPOSED: 1 record in 10 transmitted"),
    ("Telemetry frame payload", RADIO["payload_bytes"], "bytes", "Packet spec"),
    ("Ground CSV row (accepted packet)", 130, "bytes", "ASSUMED: estimate of one ground_accepted.csv row"),
    ("RAM ring buffer depth", RING_BUFFER_RECORDS, "records", "PROPOSED: 5 s of records"),
    ("Buffered record size in RAM", 48, "bytes", "stratos_record_t (40 B) + pkt_seq + tx flag, aligned"),
    ("ESP32-WROOM-32E internal SRAM", 520, "kB", "Espressif datasheet (total SRAM; usable heap is smaller)"),
]
for i, (p, v, u, src) in enumerate(inputs, start=5):
    put(ws, i, 1, p); put(ws, i, 2, v, color=BLUE, fill=INPUT_FILL); put(ws, i, 3, u); put(ws, i, 4, src)
r = 5 + len(inputs) + 1
put(ws, r, 1, "Calculated", bold=True, fill=SUB_FILL); put(ws, r, 2, "", fill=SUB_FILL); put(ws, r, 3, "", fill=SUB_FILL); put(ws, r, 4, "", fill=SUB_FILL)
calc = [
    ("Records per second", "=1000/B5", "rec/s", "1000 / record period"),
    ("Records per session (N_records)", "=B6*3600*1000/B5", "records", "window × 3600 × rate"),
    ("Storage per session, worst case (S = N × B_record + header)", "=B{n}*B7+B9", "bytes", "N × worst-case line + header"),
    ("Storage per session, typical", "=B{n}*B8+B9", "bytes", "N × typical line + header"),
    ("Storage per session incl. cluster slack (worst case)", "=CEILING(B{w}/B11,1)*B11", "bytes", "rounded up to whole clusters"),
    ("Storage per mission day (worst case)", "=B{c}*B10", "bytes", "sessions × per-session"),
    ("Usable card capacity", "=B12*1E9*B13", "bytes", "nominal × usable fraction"),
    ("Card used per mission day (worst case)", "=B{d}/B{u}", "%", ""),
    ("Margin factor (usable / day requirement)", "=B{u}/B{d}", "×", ""),
    ("Average write rate (worst case)", "=B{rr}*B7", "B/s", "far below microSD SPI throughput"),
    ("Telemetry downlink, application bytes per hour", "=3600*1000/B14*B15", "bytes/h", ""),
    ("Ground log per session (CSV rows)", "=B6*3600*1000/B14*B16", "bytes", ""),
    ("RAM used by ring buffer", "=B17*B18", "bytes", ""),
    ("RAM buffer as share of SRAM", "=B{ram}/(B19*1024)", "%", ""),
]
rows_idx = {}
for k, (p, fml, u, src) in enumerate(calc):
    i = r + 1 + k
    rows_idx[k] = i
for k, (p, fml, u, src) in enumerate(calc):
    i = rows_idx[k]
    fml = fml.format(n=rows_idx[1], w=rows_idx[2], c=rows_idx[4], d=rows_idx[5], u=rows_idx[6], rr=rows_idx[0], ram=rows_idx[12])
    fmt = "0.00%" if u == "%" else ("#,##0" if u in ("bytes", "records", "bytes/h") else "#,##0.0")
    put(ws, i, 1, p); put(ws, i, 2, fml, fmt=fmt); put(ws, i, 3, u); put(ws, i, 4, src)
sc_r = rows_idx[13] + 3
put(ws, sc_r, 1, "Scenarios (worst-case line length)", bold=True, fill=SUB_FILL)
header(ws, sc_r + 1, ["Logging duration", "Hours", "Records", "Storage (MB)", "% of usable card"])
for k, h in enumerate([1, 4, 24, 72]):
    i = sc_r + 2 + k
    put(ws, i, 1, f"{h} h continuous"); put(ws, i, 2, h, color=BLUE, fill=INPUT_FILL)
    put(ws, i, 3, f"=B{i}*3600*1000/$B$5", fmt="#,##0")
    put(ws, i, 4, f"=(C{i}*$B$7+$B$9)/1E6", fmt="0.00")
    put(ws, i, 5, f"=D{i}*1E6/$B${rows_idx[6]}", fmt="0.000%")
ch = BarChart(); ch.type = "bar"; ch.title = "Share of usable card per scenario (worst case)"
ch.y_axis.title = "% of card"; ch.y_axis.numFmt = "0.0%"
data = Reference(ws, min_col=5, min_row=sc_r + 1, max_row=sc_r + 5)
cats = Reference(ws, min_col=1, min_row=sc_r + 2, max_row=sc_r + 5)
ch.add_data(data, titles_from_data=True); ch.set_categories(cats); ch.height = 7; ch.width = 16; ch.legend = None
ws.add_chart(ch, f"F{sc_r}")
notes(ws, sc_r + 8, ["Conclusion: one 4 h session uses about 0.12 % of the usable card (≈830× margin) and even ten 4 h sessions use about 1.2 %; capacity is not a sizing constraint.",
                     "The binding storage risks are corruption on power loss and card retention under shock (risk register R04), not capacity."])
ws.freeze_panes = "A5"
wb.save(os.path.join(OUT, "STRATOS_Storage_Budget.xlsx"))
print("ok")
