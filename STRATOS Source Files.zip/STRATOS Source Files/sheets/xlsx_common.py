"""Shared openpyxl styling helpers for the STRATOS workbooks."""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.comments import Comment

FONT = "Arial"
HEAD_FILL = PatternFill("solid", fgColor="1F3A5F")
SUB_FILL = PatternFill("solid", fgColor="E8EEF5")
INPUT_FILL = PatternFill("solid", fgColor="FFF4D6")
WARN_FILL = PatternFill("solid", fgColor="FDECEA")
OK_FILL = PatternFill("solid", fgColor="E8F5E9")
THIN = Side(style="thin", color="B8C2CC")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
BLUE = "0000FF"


def f(bold=False, color="000000", size=10, italic=False):
    return Font(name=FONT, bold=bold, color=color, size=size, italic=italic)


def title(ws, text, sub=None, row=1):
    ws.cell(row=row, column=1, value=text).font = f(True, "1F3A5F", 14)
    if sub:
        ws.cell(row=row + 1, column=1, value=sub).font = f(False, "52514E", 9, italic=True)


def header(ws, row, cols, widths=None):
    for j, c in enumerate(cols, start=1):
        cell = ws.cell(row=row, column=j, value=c)
        cell.font = f(True, "FFFFFF")
        cell.fill = HEAD_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        cell.border = BORDER
    if widths:
        for j, w in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[row].height = 32


def put(ws, row, col, value, bold=False, color="000000", fill=None, fmt=None, wrap=True, comment=None):
    cell = ws.cell(row=row, column=col, value=value)
    cell.font = f(bold, color)
    cell.alignment = Alignment(wrap_text=wrap, vertical="top")
    cell.border = BORDER
    if fill:
        cell.fill = fill
    if fmt:
        cell.number_format = fmt
    if comment:
        cell.comment = Comment(comment, "STRATOS dossier")
    return cell


def notes(ws, start_row, lines, col=1):
    for i, t in enumerate(lines):
        c = ws.cell(row=start_row + i, column=col, value=t)
        c.font = f(False, "52514E", 9, italic=(i > 0))
        c.alignment = Alignment(wrap_text=False)
