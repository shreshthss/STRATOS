"""Build STRATOS_Power_Budget.xlsx, STRATOS_BOM.xlsx and STRATOS_Calculations.xlsx (formula-driven)."""
import os, sys, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "design"))
from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment
from xlsx_common import *
import power as PW
import bom as B
import mass as MS
from baseline import RADIO, GEOM as G, PROOF_LOAD_N

OUT, SRC = sys.argv[1], sys.argv[2]

# =================================================================== POWER
wb = Workbook(); ws = wb.active; ws.title = "Power budget"
title(ws, "STRATOS — Preliminary power budget (Rev A, 24 Oct 2026)",
      "Average current per load: I_avg = I_active·D + I_idle·(1 − D). Blue cells are inputs (with sources); black cells are formulas. Measure every ASSUMED value with the INA219.")
cols = ["Load", "Ref", "Rail (V)", "Active current (mA)", "Idle current (mA)", "Duty cycle D", "Average current (mA)",
        "Peak current (mA)", "Average power (mW)", "Source — active", "Source — idle / peak", "Note"]
header(ws, 4, cols, [44, 9, 8, 11, 11, 10, 12, 11, 11, 52, 46, 44])
r0 = 5
for i, (n, ref, v, ia, ii, d, ip, sa, si, note) in enumerate(PW.LOADS):
    r = r0 + i
    put(ws, r, 1, n); put(ws, r, 2, ref)
    put(ws, r, 3, v, color=BLUE, fill=INPUT_FILL)
    put(ws, r, 4, ia, color=BLUE, fill=INPUT_FILL, fmt="0.00")
    put(ws, r, 5, ii, color=BLUE, fill=INPUT_FILL, fmt="0.00")
    if ref == "U4":
        put(ws, r, 6, "=Inputs!B8/Inputs!B9", fmt="0.00%")
    else:
        put(ws, r, 6, d, color=BLUE, fill=INPUT_FILL, fmt="0.00%")
    put(ws, r, 7, f"=D{r}*F{r}+E{r}*(1-F{r})", fmt="0.000")
    put(ws, r, 8, ip, color=BLUE, fill=INPUT_FILL, fmt="0.0")
    put(ws, r, 9, f"=G{r}*C{r}", fmt="0.0")
    put(ws, r, 10, sa); put(ws, r, 11, si); put(ws, r, 12, note)
    ws.row_dimensions[r].height = 48
rl = r0 + len(PW.LOADS) - 1
rt = rl + 1
put(ws, rt, 1, "+3V3 rail total", bold=True, fill=SUB_FILL)
for c in range(2, 13):
    put(ws, rt, c, "", fill=SUB_FILL)
put(ws, rt, 7, f"=SUM(G{r0}:G{rl})", bold=True, fill=SUB_FILL, fmt="0.00")
put(ws, rt, 8, f"=SUM(H{r0}:H{rl})", bold=True, fill=SUB_FILL, fmt="0.0")
put(ws, rt, 9, f"=SUM(I{r0}:I{rl})", bold=True, fill=SUB_FILL, fmt="0.0")
put(ws, rt, 10, "Peak column = all loads at their peak simultaneously (worst case, not expected: firmware separates the SD flush from the radio slot).", fill=SUB_FILL)
rb = rt + 2
put(ws, rb, 1, "Battery-side loads (not on the 3.3 V rail)", bold=True, fill=SUB_FILL)
for c in range(2, 13):
    put(ws, rb, c, "", fill=SUB_FILL)
for k, (n, ref, ma, src) in enumerate(PW.BATT_SIDE):
    r = rb + 1 + k
    put(ws, r, 1, n); put(ws, r, 2, ref); put(ws, r, 7, ma, color=BLUE, fill=INPUT_FILL, fmt="0.000"); put(ws, r, 10, src)
rbl = rb + len(PW.BATT_SIDE)
ws.freeze_panes = "B5"
# chart of average contributors
ch = BarChart(); ch.type = "bar"; ch.title = "Average current by load (mA)"; ch.legend = None
ch.add_data(Reference(ws, min_col=7, min_row=4, max_row=rl), titles_from_data=True)
ch.set_categories(Reference(ws, min_col=2, min_row=r0, max_row=rl)); ch.height = 7.5; ch.width = 15
ws.add_chart(ch, f"A{rbl + 3}")
ch2 = BarChart(); ch2.type = "bar"; ch2.title = "Peak current by load (mA)"; ch2.legend = None
ch2.add_data(Reference(ws, min_col=8, min_row=4, max_row=rl), titles_from_data=True)
ch2.set_categories(Reference(ws, min_col=2, min_row=r0, max_row=rl)); ch2.height = 7.5; ch2.width = 15
ws.add_chart(ch2, f"F{rbl + 3}")

wi = wb.create_sheet("Inputs")
title(wi, "Inputs and assumptions")
header(wi, 4, ["Parameter", "Value", "Unit", "Source / status"], [46, 12, 10, 70])
fsk = PW.FSK_AIRTIME_MS
ins = [("Regulator efficiency η", PW.REG_EFF, "—", "ASSUMED within Pololu's typical 80–95 %"),
       ("Battery nominal voltage", PW.V_BATT_NOM, "V", "VERIFIED for INR18650-35E (3.60 V); typical of the BOM cell — confirm from its datasheet"),
       ("Battery voltage at safe shutdown", PW.V_BATT_MIN, "V", "PROPOSED firmware threshold"),
       ("Radio time on air per packet", round(fsk, 3), "ms", f"COMPUTED: {RADIO['preamble_bytes'] + RADIO['sync_bytes'] + RADIO['payload_bytes'] + 2} bytes at {RADIO['bitrate_bps']} b/s"),
       ("Packet interval", 1000, "ms", "PROPOSED: 1 Hz"),
       ("Cell capacity, design basis (BOM cell P10)", PW.CELL_CAP_MIN_MAH, "mAh", "SUPPLIER: Molicel INR18650-P28A listing (2,800 mAh); datasheet minimum NOT CONFIRMED — measure on receipt"),
       ("Usable fraction", PW.USABLE_FRACTION, "—", "ASSUMED: above 3.30 V cut-off, temperature, ageing"),
       ("Conservative cell capacity (if authenticity unverified)", PW.CONSERVATIVE_CAP_MAH, "mAh", "ASSUMED fallback for an unverified cell"),
       ("Required operating time", PW.MISSION_H, "h", "ASSUMED: ESA CanSat asks for 4 h powered"),
       ("Lowest cell voltage for peak calculation", 3.0, "V", "ASSUMED (below the 3.30 V shutdown, for margin)"),
       ("Reference cell capacity (genuine Samsung INR18650-35E)", PW.CELL_CAP_REF_MAH, "mAh", "VERIFIED: 35E minimum capacity (0.2C to 2.65 V); Robu 35E listing rejected as a copy")]
for k, (p, v, u, s) in enumerate(ins, start=5):
    put(wi, k, 1, p); put(wi, k, 2, v, color=BLUE, fill=INPUT_FILL); put(wi, k, 3, u); put(wi, k, 4, s)
# rows: 5 eff, 6 Vnom, 7 Vmin, 8 airtime, 9 interval, 10 cap, 11 usable, 12 cons cap, 13 req h, 14 Vlow, 15 ref cap

wr = wb.create_sheet("Battery and runtime")
title(wr, "Battery current and operating-time estimate")
header(wr, 4, ["Quantity", "Value", "Unit", "Formula / note"], [52, 14, 10, 70])
rr = [("+3V3 rail average current", f"='Power budget'!G{rt}", "mA", "sum of loads"),
      ("+3V3 rail average power", f"='Power budget'!I{rt}", "mW", "Σ I·V"),
      ("Battery-side average current", f"='Power budget'!I{rt}/Inputs!B5/Inputs!B6+SUM('Power budget'!G{rb + 1}:G{rbl})", "mA",
       "P_rail / (η · V_nom) + battery-side loads"),
      ("Ideal operating time t = C / I_avg", "=Inputs!B10/B7", "h", "minimum rated capacity, no derating"),
      ("Usable capacity", "=Inputs!B10*Inputs!B11", "mAh", "C × usable fraction"),
      ("Estimated operating time (design basis)", "=B9/B7", "h", "usable capacity / battery current"),
      ("Estimated operating time (conservative cell)", "=Inputs!B12*Inputs!B11/B7", "h", "unverified 2,000 mAh cell"),
      ("Margin over required time (design basis)", "=B10/Inputs!B13", "×", "≥ 2 required by FR-11 (the 4 h window may use at most 50 % of usable capacity)"),
      ("Margin over required time (conservative cell)", "=B11/Inputs!B13", "×", ""),
      ("Energy used in the 4 h window", "=B7*Inputs!B13", "mAh", ""),
      ("Share of usable capacity used in 4 h", "=B14/B9", "%", ""),
      ("Worst-case simultaneous peak at +3V3", f"='Power budget'!H{rt}", "mA", "all peaks coincident"),
      ("Worst-case peak at the cell (lowest voltage)", "=B16*3.3/Inputs!B5/Inputs!B14", "mA", "check against cell, protection and switch ratings"),
      ("Cell maximum continuous discharge (35E reference)", 8000, "mA", "VERIFIED: Samsung INR18650-35E 8 A; P28A rating to be read from its datasheet"),
      ("Regulator output capability (input > 3.3 V)", 1000, "mA", "VERIFIED: Pololu 'up to 1 A continuous' (typ. 500 mA–1 A)"),
      ("Estimated operating time (reference genuine 35E)", "=Inputs!B15*Inputs!B11/B7", "h", "if a genuine Samsung 35E is sourced instead")]
for k, (q, fml, u, n) in enumerate(rr, start=5):
    put(wr, k, 1, q); put(wr, k, 2, fml, fmt=("0.0%" if u == "%" else "#,##0.0")); put(wr, k, 3, u); put(wr, k, 4, n)
wr.cell(row=18, column=2).font = f(color=BLUE); wr.cell(row=19, column=2).font = f(color=BLUE)
notes(wr, 22, ["Result: the design-basis estimate is about 43 h against a 4 h requirement, so the 18650 is far larger than the energy need.",
               "It is kept because it is robust, available, easy to swap, and its 50 g counts toward the 300 g minimum mass if ESA-style rules apply.",
               "Every ASSUMED current must be replaced by a measured value before the runtime is claimed (TVM FR-11)."])

wsc = wb.create_sheet("Scenarios")
title(wsc, "Operating scenarios (average +3V3 rail current)")
header(wsc, 4, ["Scenario", "Change from baseline", "Rail average (mA)", "Battery current (mA)", "Operating time, design basis (h)"], [40, 60, 16, 16, 20])
scen = [("Baseline flight / logging", "as Power budget sheet", f"='Power budget'!G{rt}"),
        ("Landed, recovery beeper on", "buzzer 30 mA × 5 % duty added", f"='Power budget'!G{rt}+30*0.05"),
        ("Optional GNSS fitted (NEO-M8N)", "+30 mA continuous tracking (VERIFIED, NEO-M8 Table 11)", f"='Power budget'!G{rt}+30"),
        ("CPU left at 240 MHz (firmware fault)", "ESP32 68 mA instead of 31 mA", f"='Power budget'!G{rt}+(68-31)"),
        ("Wi-Fi accidentally left transmitting", "+239 mA average Wi-Fi TX (VERIFIED, WROOM-32E Table 16)", f"='Power budget'!G{rt}+239")]
for k, (s, ch_, fml) in enumerate(scen, start=5):
    put(wsc, k, 1, s); put(wsc, k, 2, ch_); put(wsc, k, 3, fml, fmt="0.0")
    put(wsc, k, 4, f"=C{k}*3.3/Inputs!$B$5/Inputs!$B$6+SUM('Power budget'!$G${rb + 1}:$G${rbl})", fmt="0.0")
    put(wsc, k, 5, f"=Inputs!$B$10*Inputs!$B$11/D{k}", fmt="0.0")
wb.save(os.path.join(OUT, "STRATOS_Power_Budget.xlsx"))

# =================================================================== BOM
wb = Workbook(); ws = wb.active; ws.title = "BOM"
title(ws, "STRATOS — Bill of materials (Rev A, prices read 24 Oct 2026)",
      "Nothing has been ordered: every status is 'Proposed'. Unit cost (INR incl. GST) is a formula of the listed price, the GST basis and the inputs on the 'Inputs' sheet.")
cols = ["Item", "Category", "Ref", "Component", "Manufacturer / model", "Qty", "Price as listed", "Currency", "GST basis",
        "Unit cost INR incl. GST", "Subtotal INR", "Supplier", "Source URL", "Accessed", "Availability (as shown)",
        "Alternative source", "Mass each (g)", "Mass source", "Supply voltage", "Typical current", "Peak current",
        "Role in system", "Status", "Owned / new purchase"]
header(ws, 4, cols, [6, 18, 10, 30, 36, 5, 10, 8, 8, 12, 12, 18, 40, 11, 18, 36, 9, 18, 14, 14, 14, 34, 10, 14])
mass_lookup = {}
for name, q, m, src in MS.items():
    mass_lookup[name] = (m, src)
MASS_MAP = {"P01": ("ESP32-DevKitC V4 board",), "P02": ("BME280 breakout",), "P03": ("LSM6DSOX breakout (Adafruit 4438)",),
            "P04": ("Ra-01H radio module",), "P05": ("Radio adapter (perfboard 22 × 25 mm + header)",), "P06": ("868 MHz helical antenna",),
            "P07": ("microSD breakout (Adafruit 4682)",), "P08": ("microSD card",), "P09": ("Pololu S7V8F3 regulator",),
            "P10": ("18650 cell (upper bound: 35E max)",), "P11": ("Single-cell holder (Keystone 1043)",), "P12": ("TP4056 + DW01A module",),
            "P21": ("Buzzer",), "P14": ("DPDT switch",)}
r0 = 5
for k, row in enumerate(B.BOM):
    (iid, cat, ref, name, model, qty, price, cur, gst, sup, url, stock, alt, mass_g, msrc, supply, ityp, ipk, role) = row
    r = r0 + k
    mm = MASS_MAP.get(iid)
    mval, msrc2 = (mass_lookup[mm[0]] if mm else ("", ""))
    owned = "Owned (to confirm)" if "Owned" in sup or "owned" in model.lower() else ("Made from other items" if price == 0 else "New purchase")
    vals = [iid, cat, ref, name, model, qty, price if price is not None else "", cur, gst,
            (f'=IF(G{r}="","",IF(H{r}="USD",G{r}*Inputs!$B$6,IF(I{r}="excl",G{r}*(1+Inputs!$B$5),G{r})))'),
            f'=IF(J{r}="","",J{r}*F{r})', sup, url, B.ACCESSED, stock, alt, mval, msrc2, supply, ityp, ipk, role, "Proposed", owned]
    for j, v in enumerate(vals, start=1):
        put(ws, r, j, v, color=(BLUE if j in (6, 7) else "000000"),
            fill=(WARN_FILL if (j == 7 and price is None) or (j == 15 and "OUT OF STOCK" in str(v)) else None),
            fmt=("#,##0.00" if j in (7, 10, 11) else None))
    ws.row_dimensions[r].height = 40
rl = r0 + len(B.BOM) - 1
ws.freeze_panes = "E5"
ws.auto_filter.ref = f"A4:X{rl}"

wi = wb.create_sheet("Inputs")
title(wi, "Cost inputs (edit these)")
header(wi, 4, ["Parameter", "Value", "Source / status"], [40, 12, 80])
put(wi, 5, 1, "GST rate applied to prices listed excl. GST"); put(wi, 5, 2, B.GST_RATE, color=BLUE, fill=INPUT_FILL, fmt="0%")
put(wi, 5, 3, "ASSUMED 18 % for electronic components — verify per HSN code on each invoice")
put(wi, 6, 1, "USD → INR conversion"); put(wi, 6, 2, B.FX_USD_INR, color=BLUE, fill=INPUT_FILL, fmt="0.00")
put(wi, 6, 3, "ASSUMPTION — not researched; set to the rate on the purchase day")
put(wi, 7, 1, "Contingency"); put(wi, 7, 2, B.CONTINGENCY_PCT, color=BLUE, fill=INPUT_FILL, fmt="0%")
put(wi, 7, 3, "PROPOSED: covers price changes, breakage and missing small parts")
put(wi, 8, 1, "PETG used per payload incl. waste (g)"); put(wi, 8, 2, 130, color=BLUE, fill=INPUT_FILL)
put(wi, 8, 3, "ESTIMATE: ≈100 g printed (CAD × fill factors) + 30 % failed prints / supports")

wa = wb.create_sheet("Allowances")
title(wa, "Allowances (explicit assumptions, not quotations)")
header(wa, 4, ["ID", "Allowance", "INR"], [6, 90, 12])
for k, (aid, t, v) in enumerate(B.ALLOWANCES, start=5):
    put(wa, k, 1, aid); put(wa, k, 2, t); put(wa, k, 3, v, color=BLUE, fill=INPUT_FILL, fmt="#,##0")
al = 4 + len(B.ALLOWANCES)

wsu = wb.create_sheet("Summary")
title(wsu, "Cost summary by category (formulas)")
header(wsu, 4, ["Category", "Purchase cost INR (incl. GST)", "Note"], [34, 22, 80])
cats = ["Payload – electronics", "Payload – power", "Payload – passives", "Payload – interconnect", "Structure", "Recovery",
        "Ground station", "Development equipment", "Spares"]
for k, c in enumerate(cats, start=5):
    put(wsu, k, 1, c); put(wsu, k, 2, f'=SUMIF(BOM!$B$5:$B${rl},A{k},BOM!$K$5:$K${rl})', fmt="#,##0")
cl = 4 + len(cats)
put(wsu, cl + 1, 1, "Allowances (fasteners, Al bar, shipping, import)"); put(wsu, cl + 1, 2, f"=SUM(Allowances!C5:C{al})", fmt="#,##0")
put(wsu, cl + 2, 1, "Subtotal before contingency", bold=True); put(wsu, cl + 2, 2, f"=SUM(B5:B{cl + 1})", bold=True, fmt="#,##0")
put(wsu, cl + 3, 1, "Contingency"); put(wsu, cl + 3, 2, f"=B{cl + 2}*Inputs!B7", fmt="#,##0")
put(wsu, cl + 4, 1, "TOTAL ESTIMATED PROCUREMENT COST", bold=True, fill=SUB_FILL); put(wsu, cl + 4, 2, f"=B{cl + 2}+B{cl + 3}", bold=True, fill=SUB_FILL, fmt="#,##0")
put(wsu, cl + 6, 1, "Per-payload production cost (flight unit)", bold=True, fill=SUB_FILL); put(wsu, cl + 6, 2, "", fill=SUB_FILL)
put(wsu, cl + 7, 1, "Payload electronics + power + passives + interconnect")
put(wsu, cl + 7, 2, f"=SUM(B5:B8)", fmt="#,##0"); put(wsu, cl + 7, 3, "Packs/kits are counted whole (most parts come in packs)")
put(wsu, cl + 8, 1, "PETG used per payload (estimate)")
petg_row = [k for k, row in enumerate(B.BOM) if row[0] == "S01"][0] + r0
put(wsu, cl + 8, 2, f"=BOM!J{petg_row}/1000*Inputs!B8", fmt="#,##0"); put(wsu, cl + 8, 3, "spool price × grams used / 1000")
put(wsu, cl + 9, 1, "Recovery materials"); put(wsu, cl + 9, 2, "=B10", fmt="#,##0")
put(wsu, cl + 10, 1, "Fasteners and Al bar allowances"); put(wsu, cl + 10, 2, "=Allowances!C5+Allowances!C6", fmt="#,##0")
put(wsu, cl + 11, 1, "Pololu import allowance"); put(wsu, cl + 11, 2, "=Allowances!C8", fmt="#,##0")
put(wsu, cl + 12, 1, "Estimated payload production cost", bold=True, fill=SUB_FILL)
put(wsu, cl + 12, 2, f"=SUM(B{cl + 7}:B{cl + 11})", bold=True, fill=SUB_FILL, fmt="#,##0")
put(wsu, cl + 13, 1, "Ground station (separate)"); put(wsu, cl + 13, 2, "=B11", fmt="#,##0"); put(wsu, cl + 13, 3, "laptop and USB cable assumed team-owned")
put(wsu, cl + 14, 1, "Reusable development equipment (separate)"); put(wsu, cl + 14, 2, "=B12", fmt="#,##0")
notes(wsu, cl + 16, ["Items not priced: S02 fasteners and S03 aluminium bar (allowances used); PETG counted as a full spool in procurement.",
                     "Price caveats: Robu 'mirror' pages showed lower prices than the live robu.in pages; Mouser prices exclude GST and possible duties;",
                     "several items were out of stock on 24 Oct 2026 (marked red on the BOM sheet). Re-check prices on the purchase day."])

wp = wb.create_sheet("Pitch table")
title(wp, "Compact BOM for the pitch (top items by cost, incl. GST)")
header(wp, 4, ["Subsystem", "Key part", "Qty", "Cost INR"], [22, 50, 6, 12])
pitch = [("Controller", "P01"), ("Environmental sensor", "P02"), ("Motion sensor", "P03"), ("Radio", "P04"), ("Storage", "P07"),
         ("Storage medium", "P08"), ("Power regulation", "P09"), ("Battery", "P10"), ("Battery holder", "P11")]
for k, (s, iid) in enumerate(pitch, start=5):
    idx = [j for j, row in enumerate(B.BOM) if row[0] == iid][0] + r0
    put(wp, k, 1, s); put(wp, k, 2, f"=BOM!E{idx}"); put(wp, k, 3, f"=BOM!F{idx}"); put(wp, k, 4, f"=BOM!K{idx}", fmt="#,##0")
pl = 4 + len(pitch)
put(wp, pl + 1, 1, "Payload production estimate", bold=True); put(wp, pl + 1, 4, f"=Summary!B{cl + 12}", bold=True, fmt="#,##0")
put(wp, pl + 2, 1, "Ground station", bold=True); put(wp, pl + 2, 4, f"=Summary!B{cl + 13}", bold=True, fmt="#,##0")
put(wp, pl + 3, 1, "Total procurement incl. contingency", bold=True); put(wp, pl + 3, 4, f"=Summary!B{cl + 4}", bold=True, fmt="#,##0")
wb.move_sheet("Summary", offset=-3)
wb.save(os.path.join(OUT, "STRATOS_BOM.xlsx"))

# =================================================================== CALCULATIONS (source file)
wb = Workbook(); ws = wb.active; ws.title = "Mass budget"
title(ws, "STRATOS — Mass budget (preliminary)", "Weigh every EST item on receipt and replace it.")
header(ws, 4, ["Item", "Qty", "Mass each (g)", "Subtotal (g)", "Source"], [60, 6, 14, 14, 50])
rows = MS.items()
for k, (n, q, m, src) in enumerate(rows, start=5):
    put(ws, k, 1, n); put(ws, k, 2, q); put(ws, k, 3, m, color=BLUE, fill=INPUT_FILL, fmt="0.0"); put(ws, k, 4, f"=B{k}*C{k}", fmt="0.0"); put(ws, k, 5, src)
ml = 4 + len(rows)
put(ws, ml + 1, 1, "Estimated total without ballast", bold=True); put(ws, ml + 1, 4, f"=SUM(D5:D{ml})", bold=True, fmt="0.0")
put(ws, ml + 2, 1, "Reference minimum mass (ESA CanSat, assumed)"); put(ws, ml + 2, 4, 300, color=BLUE, fill=INPUT_FILL)
put(ws, ml + 3, 1, "Reference maximum mass (ESA CanSat, assumed)"); put(ws, ml + 3, 4, 350, color=BLUE, fill=INPUT_FILL)
put(ws, ml + 4, 1, "Design target mass (mid-band)"); put(ws, ml + 4, 4, f"=(D{ml + 2}+D{ml + 3})/2", fmt="0.0")
put(ws, ml + 5, 1, "Ballast needed to reach the target", bold=True); put(ws, ml + 5, 4, f"=MAX(0,D{ml + 4}-D{ml + 1})", bold=True, fmt="0.0")
put(ws, ml + 6, 1, "Margin to maximum without ballast"); put(ws, ml + 6, 4, f"=D{ml + 3}-D{ml + 1}", fmt="0.0")
mass_rows = dict(total=ml + 1, target=ml + 4)

wsp = wb.create_sheet("Parachute sizing")
title(wsp, "Parachute sizing: v = √(2 m g / (ρ C_D A))", "Flat circular canopy; C_D range from the literature for flat circular canopies (to be confirmed by drop test).")
header(wsp, 4, ["Parameter", "Value", "Unit", "Source"], [44, 12, 10, 70])
pin = [("Payload mass for sizing", f"='Mass budget'!D{mass_rows['target']}/1000", "kg", "design target mass (with ballast)"),
       ("Target steady descent speed", 9.0, "m/s", "ESA CanSat recommends 8–11 m/s (limits 5–12 m/s)"),
       ("Drag coefficient C_D (nominal area)", 0.75, "—", "ASSUMED: flat circular canopies ≈0.75–0.80 (Knacke, Parachute Recovery Systems Design Manual)"),
       ("Air density ρ", 1.225, "kg/m³", "ISA sea level; ≈1.112 kg/m³ at 1 km"),
       ("g", 9.81, "m/s²", "")]
for k, (p, v, u, s) in enumerate(pin, start=5):
    put(wsp, k, 1, p); put(wsp, k, 2, v, color=(BLUE if not str(v).startswith("=") else "000000"), fill=(INPUT_FILL if not str(v).startswith("=") else None), fmt="0.000")
    put(wsp, k, 3, u); put(wsp, k, 4, s)
put(wsp, 11, 1, "Required canopy area A", bold=True); put(wsp, 11, 2, "=2*B5*B9/(B8*B7*B6^2)", bold=True, fmt="0.0000"); put(wsp, 11, 3, "m²")
put(wsp, 12, 1, "Nominal canopy diameter D", bold=True); put(wsp, 12, 2, "=SQRT(4*B11/PI())", bold=True, fmt="0.000"); put(wsp, 12, 3, "m")
put(wsp, 13, 1, "Chosen diameter (rounded)"); put(wsp, 13, 2, 0.33, color=BLUE, fill=INPUT_FILL, fmt="0.00"); put(wsp, 13, 3, "m")
header(wsp, 15, ["Sensitivity: descent speed (m/s) with the chosen diameter", "C_D = 0.60", "C_D = 0.75", "C_D = 0.90"])
for k, (lab, m) in enumerate([("Unballasted estimate", f"='Mass budget'!D{mass_rows['total']}/1000"), ("300 g", 0.300), ("Design target", "=B5"), ("350 g", 0.350)], start=16):
    put(wsp, k, 1, lab)
    for j, cd in enumerate((0.60, 0.75, 0.90), start=2):
        mref = m if isinstance(m, float) else m[1:]
        put(wsp, k, j, f"=SQRT(2*({mref})*$B$9/($B$8*{cd}*PI()*$B$13^2/4))", fmt="0.00")
put(wsp, 21, 1, "At 1 km altitude (ρ = 1.112) the speeds rise by √(1.225/1.112) ≈ 5 %.")
put(wsp, 22, 1, "Opening-load estimate (ASSUMED deployment at 25 m/s, opening factor 2)")
put(wsp, 22, 2, "=0.5*B8*25^2*B7*PI()*B13^2/4*2", fmt="0.0"); put(wsp, 22, 3, "N")

wsy = wb.create_sheet("Recovery attachment")
title(wsy, "Recovery attachment strength (hand calculation, preliminary)")
header(wsy, 4, ["Parameter", "Value", "Unit", "Source"], [52, 12, 10, 70])
yin = [("Proof load applied at the bridle", PROOF_LOAD_N, "N", "Belgium 2026–27 / Malta 2025–26 rules (500 N); ESA 2022–23 asks 50 N; ESA 2018 1000 N"),
       ("Yoke width b", G["yoke_w"], "mm", "drawing"), ("Yoke thickness t", G["yoke_t"], "mm", "drawing"),
       ("Lever arm from bridle hole to rod", G["rod_x"] - G["bridle_x"], "mm", "rod at ±25, bridle hole at ±16"),
       ("6061-T6 yield strength", 276, "MPa", "ASSUMED typical handbook value"),
       ("M3 A2-70 rod tensile stress area", 5.03, "mm²", "ISO 898 / ISO 3506 value for M3"),
       ("A2-70 proof/yield strength", 450, "MPa", "ISO 3506-1 property class 70 (0.2 % proof stress)")]
for k, (p, v, u, s) in enumerate(yin, start=5):
    put(wsy, k, 1, p); put(wsy, k, 2, v, color=BLUE, fill=INPUT_FILL); put(wsy, k, 3, u); put(wsy, k, 4, s)
put(wsy, 13, 1, "Bending moment per side M = (F/2)·a"); put(wsy, 13, 2, "=B5/2*B8", fmt="0"); put(wsy, 13, 3, "N·mm")
put(wsy, 14, 1, "Section modulus Z = b·t²/6"); put(wsy, 14, 2, "=B6*B7^2/6", fmt="0.0"); put(wsy, 14, 3, "mm³")
put(wsy, 15, 1, "Bending stress σ = M/Z"); put(wsy, 15, 2, "=B13/B14", fmt="0"); put(wsy, 15, 3, "MPa")
put(wsy, 16, 1, "Safety factor on yield (yoke)", bold=True); put(wsy, 16, 2, "=B9/B15", bold=True, fmt="0.00")
put(wsy, 17, 1, "Rod tension per rod F/2"); put(wsy, 17, 2, "=B5/2", fmt="0"); put(wsy, 17, 3, "N")
put(wsy, 18, 1, "Rod yield load"); put(wsy, 18, 2, "=B10*B11", fmt="0"); put(wsy, 18, 3, "N")
put(wsy, 19, 1, "Safety factor on yield (rods)", bold=True); put(wsy, 19, 2, "=B18/B17", bold=True, fmt="0.0")
notes(wsy, 21, ["The PETG bottom cap carries the rod nuts; its strength depends on print orientation and must be proven by a pull test (TVM FR-16).",
                "With a single central bridle hole the yoke stress would be about 2.8× higher, which is why a two-leg (Y) bridle is specified."])

wl = wb.create_sheet("Link budget")
title(wl, "Radio link budget (free space, preliminary)", "FSPL = 20·log10(d) + 20·log10(f) − 147.55 dB. Real links need extra fade margin for tumbling, polarisation and body shadowing.")
header(wl, 4, ["Parameter", "Value", "Unit", "Source"], [50, 12, 10, 70])
lin = [("Frequency", 866e6, "Hz", "PROPOSED"), ("Transmit power (conducted)", RADIO["tx_power_dbm"], "dBm", "PROPOSED"),
       ("Payload antenna gain", -2.0, "dBi", "ASSUMED (small helix inside the can; listing claims ≈1.5 dBi in free space)"),
       ("Ground antenna gain", 1.0, "dBi", "SUPPLIER listing (1 dBi rubber duck)"), ("Cable / connector / mismatch losses", 1.0, "dB", "ASSUMED"),
       ("Receiver sensitivity, GFSK 38.4 kb/s (baseline)", -105, "dBm", "ASSUMED — NOT CONFIRMED from the SX1276 datasheet; measure in the range test"),
       ("Receiver sensitivity, LoRa SF7/125 kHz (option)", -123, "dBm", "VERIFIED: SX1276 datasheet Table 10"),
       ("Required fade margin", 15, "dB", "ASSUMED planning value")]
for k, (p, v, u, s) in enumerate(lin, start=5):
    put(wl, k, 1, p); put(wl, k, 2, v, color=BLUE, fill=INPUT_FILL, fmt=("0" if abs(v) > 1000 else "0.0")); put(wl, k, 3, u); put(wl, k, 4, s)
header(wl, 14, ["Distance (m)", "FSPL (dB)", "Received power (dBm)", "Margin GFSK (dB)", "Margin LoRa SF7 (dB)", "GFSK ≥ fade margin?"])
for k, d in enumerate([300, 1000, 2000, 3000, 5000], start=15):
    put(wl, k, 1, d, color=BLUE, fill=INPUT_FILL)
    put(wl, k, 2, f"=20*LOG10(A{k})+20*LOG10($B$5)-147.55", fmt="0.0")
    put(wl, k, 3, f"=$B$6+$B$7+$B$8-$B$9-B{k}", fmt="0.0")
    put(wl, k, 4, f"=C{k}-$B$10", fmt="0.0"); put(wl, k, 5, f"=C{k}-$B$11", fmt="0.0")
    put(wl, k, 6, f'=IF(D{k}>=$B$12,"yes","NO")')
put(wl, 21, 1, "Effective radiated power (ERP)"); put(wl, 21, 2, "=B6+B7-2.15", fmt="0.0"); put(wl, 21, 3, "dBm")
put(wl, 22, 1, "ERP in mW"); put(wl, 22, 2, "=10^(B21/10)", fmt="0.0"); put(wl, 22, 3, "mW")
put(wl, 23, 1, "Limit, GSR 853(E) Table II"); put(wl, 23, 2, 500, color=BLUE, fill=INPUT_FILL); put(wl, 23, 3, "mW")
put(wl, 24, 1, "Duty cycle at 1 packet/s"); put(wl, 24, 2, f"={PW.FSK_AIRTIME_MS:.4f}/1000", fmt="0.00%"); put(wl, 24, 3, "—")
put(wl, 25, 1, "Duty-cycle limit (non-access-point, Table II)"); put(wl, 25, 2, 0.025, color=BLUE, fill=INPUT_FILL, fmt="0.0%")
wb.save(os.path.join(SRC, "STRATOS_Calculations.xlsx"))
print("ok")
