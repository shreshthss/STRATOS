"""Unit tests for the STRATOS software prototype (synthetic inputs only).

Run:  python -m unittest discover -s tests -v     (from the software/ folder)
"""
import os
import struct
import tempfile
import unittest

from stratos_gs.packet import (Packet, Record, decode, DecodeError, crc16_ccitt_false,
                               PACKET_LEN, FLAG, SENT_U16, to_engineering)
from stratos_gs.onboard_log import format_line, parse_lines, TX_DONE
from stratos_gs.tracker import GroundTracker
from stratos_gs import simulate


def make_packet(seq, session=1, rh=4512):
    rec = Record(session, 10 * (seq - 1) + 1, 1000 * seq, 2534, rh, 1003250,
                 12, -5, 1001, 3, -1, 0, 3987,
                 FLAG["BME_PRESENT"] | FLAG["IMU_PRESENT"] | FLAG["SD_OK"])
    return rec, Packet.from_record(rec, seq)


class TestCRC(unittest.TestCase):
    def test_check_value(self):
        # Standard check value for CRC-16/CCITT-FALSE
        self.assertEqual(crc16_ccitt_false(b"123456789"), 0x29B1)


class TestPacket(unittest.TestCase):
    def test_length_and_roundtrip(self):
        _, p = make_packet(5)
        frame = p.encode()
        self.assertEqual(len(frame), PACKET_LEN)
        q = decode(frame)
        self.assertEqual((q.pkt_seq, q.rec_seq, q.press_dPa, q.crc16), (5, 41, 1003250, p.crc16))

    def test_every_single_bit_error_is_detected(self):
        _, p = make_packet(7)
        frame = p.encode()
        for i in range(PACKET_LEN * 8):
            bad = bytearray(frame)
            bad[i // 8] ^= 1 << (i % 8)
            with self.assertRaises(DecodeError):
                decode(bytes(bad))

    def test_wrong_length_rejected(self):
        _, p = make_packet(1)
        with self.assertRaises(DecodeError) as cm:
            decode(p.encode()[:-1])
        self.assertEqual(cm.exception.kind, "LENGTH")

    def test_absent_value_is_not_zero(self):
        rec, p = make_packet(2, rh=SENT_U16)
        p.status |= FLAG["RH_INVALID"]
        e = to_engineering(decode(p.encode()))
        self.assertIsNone(e["rh_pct"])
        rec0, p0 = make_packet(3, rh=0)
        self.assertEqual(to_engineering(decode(p0.encode()))["rh_pct"], 0.0)


class TestOnboardLog(unittest.TestCase):
    def test_line_roundtrip_and_truncation(self):
        rec, _ = make_packet(4, rh=SENT_U16)
        line = format_line(rec, 4, TX_DONE)
        self.assertIn(",,", line)                      # absent RH written as empty field
        ok = parse_lines([line])[0]
        self.assertTrue(ok.valid)
        self.assertEqual(ok.record.rh_cpct, SENT_U16)
        bad = parse_lines([line[:30]])[0]
        self.assertFalse(bad.valid)


class TestTracker(unittest.TestCase):
    def _line(self, frame, ms=0):
        return f"RX,{ms},-70,8.0,{len(frame)},{frame.hex()}"

    def test_gap_corruption_duplicate(self):
        tr = GroundTracker()
        for s in (100, 102):                           # 101 never arrives
            tr.feed_line(self._line(make_packet(s)[1].encode()), "t")
        self.assertEqual(tr.gap_rows[-1]["first_missing"], 101)
        bad = bytearray(make_packet(103)[1].encode()); bad[20] ^= 0xFF
        ev = tr.feed_line(self._line(bytes(bad)), "t")
        self.assertFalse(ev.accepted)
        self.assertEqual(ev.reason, "CRC")
        ev = tr.feed_line(self._line(make_packet(102)[1].encode()), "t")
        self.assertIn("DUPLICATE", ev.seq_event)
        ev = tr.feed_line(self._line(make_packet(1, session=2)[1].encode()), "t")
        self.assertIn("SESSION_CHANGE", ev.seq_event)


class TestSimulatedPipeline(unittest.TestCase):
    def test_reconciliation_classifies_injected_faults(self):
        with tempfile.TemporaryDirectory() as d:
            out = simulate.run(d)
            s = out["result"]["sessions"][simulate.SESSION]
            self.assertEqual(s["missing"], [6, 120, 121, 122])
            self.assertEqual(s["missing_corrupt"], [9])
            self.assertEqual(s["not_transmitted"], [150])
            self.assertEqual(s["mismatch"], 0)
            self.assertEqual(s["ground_only"], [])
            self.assertEqual(len(s["ground_recovers"]), 1)
            self.assertEqual(out["result"]["ground_duplicates"], 1)
            self.assertEqual(len(out["result"]["onboard_invalid"]), 1)


if __name__ == "__main__":
    unittest.main()
