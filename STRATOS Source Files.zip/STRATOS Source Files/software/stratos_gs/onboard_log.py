"""
STRATOS onboard log format (CSV, format version 1).

The payload firmware writes one CSV line per 10 Hz record to LOG_<session>.CSV
on the microSD card. Each line ends with a CRC-16/CCITT-FALSE of the line text
so that truncated or corrupted lines (for example after a power loss during a
write) can be detected after recovery.

Values are written in the same integer units as the telemetry packet, so a
received packet can be compared with its onboard record exactly, without
floating-point rounding. Unavailable measurements are written as an empty
field (never as 0) and are also flagged in the status word.

STATUS: software prototype; the firmware writer that mirrors this format is a
draft and has not been run on hardware.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional

from .packet import (Record, SENT_I16, SENT_U16, SENT_U32, crc16_ccitt_false)

LOG_FORMAT_VERSION = 1
COLUMNS = ["session", "rec_seq", "t_ms", "temp_cC", "rh_cpct", "press_dPa",
           "ax_mg", "ay_mg", "az_mg", "gx_ddps", "gy_ddps", "gz_ddps",
           "vbat_mV", "status", "pkt_seq", "tx", "lcrc"]
_SENTINELS = {"temp_cC": SENT_I16, "rh_cpct": SENT_U16, "press_dPa": SENT_U32,
              "ax_mg": SENT_I16, "ay_mg": SENT_I16, "az_mg": SENT_I16,
              "gx_ddps": SENT_I16, "gy_ddps": SENT_I16, "gz_ddps": SENT_I16,
              "vbat_mV": SENT_U16}

TX_NONE, TX_DONE, TX_FAIL = "", "T", "F"


def header_lines(session: int, fw: str, period_ms: int, tx_every: int) -> list[str]:
    return [f"# STRATOS onboard log v{LOG_FORMAT_VERSION}",
            f"# session={session} fw={fw} record_period_ms={period_ms} tx_every_n={tx_every}",
            ",".join(COLUMNS)]


def format_line(rec: Record, pkt_seq: Optional[int], tx: str) -> str:
    vals = [str(rec.session), str(rec.rec_seq), str(rec.t_ms)]
    for name in COLUMNS[3:13]:
        v = getattr(rec, name)
        vals.append("" if v == _SENTINELS[name] else str(v))
    vals.append(f"{rec.status:04X}")
    vals.append("" if pkt_seq is None else str(pkt_seq))
    vals.append(tx)
    body = ",".join(vals)
    return f"{body},{crc16_ccitt_false(body.encode('ascii')):04X}"


@dataclass
class LogLine:
    lineno: int
    valid: bool
    reason: str
    record: Optional[Record] = None
    pkt_seq: Optional[int] = None
    tx: str = ""
    raw: str = ""


def parse_lines(lines: Iterable[str]) -> list[LogLine]:
    out: list[LogLine] = []
    for n, raw in enumerate(lines, start=1):
        raw = raw.rstrip("\r\n")
        if not raw or raw.startswith("#") or raw.startswith("session,"):
            continue
        parts = raw.split(",")
        if len(parts) != len(COLUMNS):
            out.append(LogLine(n, False, f"FIELD_COUNT({len(parts)})", raw=raw))
            continue
        body = raw.rsplit(",", 1)[0]
        try:
            stored = int(parts[-1], 16)
        except ValueError:
            out.append(LogLine(n, False, "LCRC_FORMAT", raw=raw))
            continue
        if crc16_ccitt_false(body.encode("ascii", "replace")) != stored:
            out.append(LogLine(n, False, "LCRC_MISMATCH", raw=raw))
            continue
        d = dict(zip(COLUMNS, parts))
        kw = {"session": int(d["session"]), "rec_seq": int(d["rec_seq"]), "t_ms": int(d["t_ms"])}
        for name, sent in _SENTINELS.items():
            kw[name] = sent if d[name] == "" else int(d[name])
        kw["status"] = int(d["status"], 16)
        out.append(LogLine(n, True, "OK", Record(**kw),
                           int(d["pkt_seq"]) if d["pkt_seq"] else None, d["tx"], raw))
    return out
