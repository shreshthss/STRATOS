"""LoRa time-on-air and link-budget helpers (Semtech SX1276 datasheet formula)."""
from __future__ import annotations

import math


def lora_time_on_air_ms(payload_len: int, sf: int = 7, bw_hz: float = 125e3, cr: int = 1,
                        preamble: int = 8, explicit_header: bool = True, crc_on: bool = True,
                        low_dr_opt: bool | None = None) -> dict:
    """Return symbol time, preamble time, payload symbols and total airtime.

    cr: 1..4 for coding rate 4/5..4/8. Low-data-rate optimisation is mandated
    by Semtech when the symbol duration exceeds 16 ms.
    """
    t_sym = (2 ** sf) / bw_hz * 1000.0
    if low_dr_opt is None:
        low_dr_opt = t_sym > 16.0
    de = 1 if low_dr_opt else 0
    ih = 0 if explicit_header else 1
    t_pre = (preamble + 4.25) * t_sym
    num = 8 * payload_len - 4 * sf + 28 + 16 * (1 if crc_on else 0) - 20 * ih
    n_payload = 8 + max(math.ceil(num / (4 * (sf - 2 * de))) * (cr + 4), 0)
    t_pay = n_payload * t_sym
    return {"t_sym_ms": t_sym, "t_preamble_ms": t_pre, "payload_symbols": n_payload,
            "t_payload_ms": t_pay, "t_total_ms": t_pre + t_pay}


def fspl_db(distance_m: float, freq_hz: float) -> float:
    """Free-space path loss (dB)."""
    return 20 * math.log10(distance_m) + 20 * math.log10(freq_hz) - 147.55


def link_margin_db(pt_dbm, gt_dbi, gr_dbi, losses_db, distance_m, freq_hz, sensitivity_dbm):
    pr = pt_dbm + gt_dbi + gr_dbi - losses_db - fspl_db(distance_m, freq_hz)
    return pr, pr - sensitivity_dbm


def fsk_time_on_air_ms(payload_len: int, bitrate_bps: float = 38400, preamble_bytes: int = 5,
                       sync_bytes: int = 4, length_byte: bool = False, crc_bytes: int = 2) -> dict:
    """Time on air of an SX127x FSK packet (packet engine, fixed or variable length)."""
    nbytes = preamble_bytes + sync_bytes + (1 if length_byte else 0) + payload_len + crc_bytes
    return {"bytes_on_air": nbytes, "t_total_ms": nbytes * 8 / bitrate_bps * 1000.0}


def carson_bandwidth_khz(fdev_khz: float, bitrate_bps: float) -> float:
    """Carson's-rule occupied bandwidth estimate for 2-FSK: 2 (fdev + bitrate/2)."""
    return 2 * (fdev_khz + bitrate_bps / 2000.0)
