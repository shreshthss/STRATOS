"""
STRATOS telemetry packet definition (format version 1).

This module is the single authoritative definition of the 44-byte STRATOS
telemetry packet. The C implementation in firmware/stratos_packet.c mirrors it
and is checked against the golden vectors produced here (see tests/).

STATUS: software prototype. Exercised with synthetic data only; not yet
validated on STRATOS radio hardware.

Byte order: little-endian for all multi-byte fields.
Integrity:  CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF, no reflection,
            xorout 0x0000) computed over bytes 0..41, stored little-endian in
            bytes 42..43. Check value for ASCII "123456789" is 0x29B1.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field, asdict
from typing import Optional

MAGIC = b"ST"            # bytes 0..1
FORMAT_VERSION = 1        # byte 2
PKT_TYPE_TELEMETRY = 0x01  # byte 3
PACKET_LEN = 44
CRC_COVERED_LEN = 42

# struct layout, little-endian, no padding
#  2s magic | B ver | B type | H session | I pkt_seq | I rec_seq | I t_ms |
#  h temp_cC | H rh_cpct | I press_dPa | 3h acc_mg | 3h gyr_ddps |
#  H vbat_mV | H status | H crc
_FMT = "<2sBBHIIIhHIhhhhhhHHH"
assert struct.calcsize(_FMT) == PACKET_LEN

# Sentinel values written when a measurement is unavailable. The status flag
# is authoritative; the sentinel is a second, independent marker so that an
# absent value can never be mistaken for a valid zero.
SENT_I16 = -32768
SENT_U16 = 0xFFFF
SENT_U32 = 0xFFFFFFFF

# ---- status bit field (uint16) ------------------------------------------
STATUS_BITS = {
    0: ("BME_PRESENT", "BME280 initialised and responding"),
    1: ("IMU_PRESENT", "IMU initialised and responding"),
    2: ("SD_OK", "Onboard log file open and last flush succeeded"),
    3: ("T_INVALID", "Temperature unavailable or out of plausibility range"),
    4: ("RH_INVALID", "Humidity unavailable or out of plausibility range"),
    5: ("P_INVALID", "Pressure unavailable or out of plausibility range"),
    6: ("ACC_INVALID", "Acceleration unavailable"),
    7: ("GYR_INVALID", "Angular rate unavailable"),
    8: ("SD_WRITE_ERR", "At least one SD write/flush failed since last packet"),
    9: ("LOG_OVERFLOW", "RAM log buffer overflowed; records were dropped"),
    10: ("VBAT_LOW", "Battery voltage below 3.40 V"),
    11: ("RADIO_ERR", "Previous transmission failed or timed out"),
    12: ("CYCLE_OVERRUN", "Acquisition cycle exceeded its 100 ms period"),
    13: ("RESERVED13", "Reserved, transmitted as 0"),
    14: ("RESERVED14", "Reserved, transmitted as 0"),
    15: ("RESERVED15", "Reserved, transmitted as 0"),
}
FLAG = {name: 1 << bit for bit, (name, _) in STATUS_BITS.items()}

# ---- field table (used for documentation generation) ---------------------
# name, offset, size, type, unit/scale, description
FIELDS = [
    ("magic", 0, 2, "char[2]", "-", 'Frame marker, ASCII "ST" (0x53 0x54)'),
    ("version", 2, 1, "uint8", "-", "Packet format version, = 1"),
    ("type", 3, 1, "uint8", "-", "Packet type, 0x01 = telemetry"),
    ("session", 4, 2, "uint16", "-", "Session ID: boot counter held in ESP32 NVS, +1 per power-up"),
    ("pkt_seq", 6, 4, "uint32", "-", "Packet sequence number, +1 per packet handed to the radio in this session (starts at 1)"),
    ("rec_seq", 10, 4, "uint32", "-", "Sequence number of the onboard record this packet summarises (starts at 1)"),
    ("t_ms", 14, 4, "uint32", "ms", "Elapsed time since boot at acquisition (millis())"),
    ("temp_cC", 18, 2, "int16", "0.01 degC", "BME280 temperature; sentinel -32768"),
    ("rh_cpct", 20, 2, "uint16", "0.01 %RH", "BME280 relative humidity; sentinel 0xFFFF"),
    ("press_dPa", 22, 4, "uint32", "0.1 Pa", "BME280 pressure; sentinel 0xFFFFFFFF"),
    ("ax_mg", 26, 2, "int16", "mg", "Acceleration X (IMU frame); sentinel -32768"),
    ("ay_mg", 28, 2, "int16", "mg", "Acceleration Y; sentinel -32768"),
    ("az_mg", 30, 2, "int16", "mg", "Acceleration Z; sentinel -32768"),
    ("gx_ddps", 32, 2, "int16", "0.1 deg/s", "Angular rate X; sentinel -32768"),
    ("gy_ddps", 34, 2, "int16", "0.1 deg/s", "Angular rate Y; sentinel -32768"),
    ("gz_ddps", 36, 2, "int16", "0.1 deg/s", "Angular rate Z; sentinel -32768"),
    ("vbat_mV", 38, 2, "uint16", "mV", "Battery voltage after divider correction; sentinel 0xFFFF"),
    ("status", 40, 2, "uint16", "bitfield", "Status flags (see status table)"),
    ("crc16", 42, 2, "uint16", "-", "CRC-16/CCITT-FALSE over bytes 0..41"),
]
assert sum(f[2] for f in FIELDS) == PACKET_LEN

MEASUREMENT_FIELDS = ["temp_cC", "rh_cpct", "press_dPa", "ax_mg", "ay_mg", "az_mg",
                      "gx_ddps", "gy_ddps", "gz_ddps", "vbat_mV"]


def crc16_ccitt_false(data: bytes, crc: int = 0xFFFF) -> int:
    """CRC-16/CCITT-FALSE, bitwise (identical algorithm to the C version)."""
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return crc


@dataclass
class Record:
    """One onboard record (10 Hz). Values are in packet integer units."""
    session: int
    rec_seq: int
    t_ms: int
    temp_cC: int = SENT_I16
    rh_cpct: int = SENT_U16
    press_dPa: int = SENT_U32
    ax_mg: int = SENT_I16
    ay_mg: int = SENT_I16
    az_mg: int = SENT_I16
    gx_ddps: int = SENT_I16
    gy_ddps: int = SENT_I16
    gz_ddps: int = SENT_I16
    vbat_mV: int = SENT_U16
    status: int = 0


@dataclass
class Packet:
    session: int
    pkt_seq: int
    rec_seq: int
    t_ms: int
    temp_cC: int
    rh_cpct: int
    press_dPa: int
    ax_mg: int
    ay_mg: int
    az_mg: int
    gx_ddps: int
    gy_ddps: int
    gz_ddps: int
    vbat_mV: int
    status: int
    crc16: Optional[int] = None

    @classmethod
    def from_record(cls, rec: Record, pkt_seq: int) -> "Packet":
        d = asdict(rec)
        return cls(pkt_seq=pkt_seq, **d)

    def encode(self) -> bytes:
        body = struct.pack(_FMT[:-1], MAGIC, FORMAT_VERSION, PKT_TYPE_TELEMETRY,
                           self.session, self.pkt_seq, self.rec_seq, self.t_ms,
                           self.temp_cC, self.rh_cpct, self.press_dPa,
                           self.ax_mg, self.ay_mg, self.az_mg,
                           self.gx_ddps, self.gy_ddps, self.gz_ddps,
                           self.vbat_mV, self.status)
        crc = crc16_ccitt_false(body)
        self.crc16 = crc
        return body + struct.pack("<H", crc)


class DecodeError(Exception):
    def __init__(self, kind: str, detail: str = ""):
        super().__init__(f"{kind}: {detail}")
        self.kind = kind          # LENGTH | MAGIC | VERSION | TYPE | CRC
        self.detail = detail


def decode(frame: bytes) -> Packet:
    """Validate structure and integrity, then decode. Raises DecodeError."""
    if len(frame) != PACKET_LEN:
        raise DecodeError("LENGTH", f"expected {PACKET_LEN} bytes, got {len(frame)}")
    calc = crc16_ccitt_false(frame[:CRC_COVERED_LEN])
    stored = struct.unpack_from("<H", frame, CRC_COVERED_LEN)[0]
    # CRC is checked before any field is trusted, including the header.
    if calc != stored:
        raise DecodeError("CRC", f"stored 0x{stored:04X}, computed 0x{calc:04X}")
    v = struct.unpack(_FMT, frame)
    if v[0] != MAGIC:
        raise DecodeError("MAGIC", repr(v[0]))
    if v[1] != FORMAT_VERSION:
        raise DecodeError("VERSION", str(v[1]))
    if v[2] != PKT_TYPE_TELEMETRY:
        raise DecodeError("TYPE", str(v[2]))
    return Packet(*v[3:])


def flags_to_names(status: int) -> list[str]:
    return [STATUS_BITS[b][0] for b in range(16) if status & (1 << b)]


def to_engineering(p) -> dict:
    """Convert integer units to engineering units; None where unavailable."""
    def ok(val, sent, flag):
        return not (val == sent or (p.status & FLAG[flag]))
    out = {
        "temp_C": p.temp_cC / 100 if ok(p.temp_cC, SENT_I16, "T_INVALID") else None,
        "rh_pct": p.rh_cpct / 100 if ok(p.rh_cpct, SENT_U16, "RH_INVALID") else None,
        "press_hPa": p.press_dPa / 1000 if ok(p.press_dPa, SENT_U32, "P_INVALID") else None,
        "vbat_V": p.vbat_mV / 1000 if p.vbat_mV != SENT_U16 else None,
    }
    for ax in "xyz":
        a = getattr(p, f"a{ax}_mg")
        g = getattr(p, f"g{ax}_ddps")
        out[f"a{ax}_g"] = a / 1000 if ok(a, SENT_I16, "ACC_INVALID") else None
        out[f"g{ax}_dps"] = g / 10 if ok(g, SENT_I16, "GYR_INVALID") else None
    return out
