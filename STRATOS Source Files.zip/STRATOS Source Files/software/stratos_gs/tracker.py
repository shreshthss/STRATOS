"""
Ground-station packet validation and sequence tracking.

Separates the events the dossier requires to be kept distinct:
  * a frame that arrived but failed validation (LENGTH / MAGIC / VERSION /
    TYPE / CRC)  -> rejected, logged with its raw bytes, counted as invalid;
  * a packet sequence number that never arrived  -> logged as a gap;
  * a duplicate or out-of-order sequence number   -> accepted but flagged;
  * a new session ID (payload rebooted)           -> new sequence tracker.

The receiver firmware forwards every radio frame to the host as one text line:
    RX,<receiver_ms>,<rssi_dBm>,<snr_dB or nan>,<len>,<hex bytes>   (SNR exists only in LoRa mode)
The host adds its own UTC reception timestamp.

STATUS: software prototype exercised with synthetic, simulated frames only.
"""
from __future__ import annotations

import csv
import datetime as dt
from dataclasses import dataclass, field
from typing import Optional

from .packet import (Packet, DecodeError, decode, FIELDS, MEASUREMENT_FIELDS)

ACCEPT_COLUMNS = (["rx_utc", "rx_ms", "rssi_dBm", "snr_dB", "session", "pkt_seq",
                   "rec_seq", "t_ms"] + MEASUREMENT_FIELDS + ["status", "crc16", "seq_event"])
REJECT_COLUMNS = ["rx_utc", "rx_ms", "rssi_dBm", "snr_dB", "length", "reason",
                  "last_accepted_session", "last_accepted_pkt_seq", "hex"]
GAP_COLUMNS = ["session", "first_missing", "last_missing", "count",
               "detected_before_pkt_seq", "detected_utc"]


@dataclass
class RxEvent:
    rx_utc: str
    rx_ms: int
    rssi: float
    snr: float
    raw: bytes
    accepted: bool
    reason: str = "OK"
    packet: Optional[Packet] = None
    seq_event: str = ""


@dataclass
class SessionState:
    session: int
    last_seq: Optional[int] = None
    received: set = field(default_factory=set)
    gaps: list = field(default_factory=list)   # (first, last)
    duplicates: int = 0
    out_of_order: int = 0


class GroundTracker:
    def __init__(self):
        self.sessions: dict[int, SessionState] = {}
        self.current: Optional[SessionState] = None
        self.frames_total = 0
        self.accepted = 0
        self.rejected = 0
        self.reject_reasons: dict[str, int] = {}
        self.events: list[RxEvent] = []
        self.gap_rows: list[dict] = []

    # -- line parsing ------------------------------------------------------
    @staticmethod
    def parse_line(line: str):
        parts = line.strip().split(",")
        if len(parts) != 6 or parts[0] != "RX":
            return None
        _, rx_ms, rssi, snr, length, hexs = parts
        try:
            raw = bytes.fromhex(hexs)
        except ValueError:
            raw = b""
        return int(rx_ms), float(rssi), float(snr), int(length), raw

    def feed_line(self, line: str, rx_utc: Optional[str] = None) -> Optional[RxEvent]:
        parsed = self.parse_line(line)
        if parsed is None:
            return None
        rx_ms, rssi, snr, _length, raw = parsed
        if rx_utc is None:
            rx_utc = dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds")
        return self.feed_frame(raw, rx_utc, rx_ms, rssi, snr)

    # -- validation and sequence tracking ------------------------------------
    def feed_frame(self, raw: bytes, rx_utc: str, rx_ms: int, rssi: float, snr: float) -> RxEvent:
        self.frames_total += 1
        try:
            pkt = decode(raw)
        except DecodeError as e:
            self.rejected += 1
            self.reject_reasons[e.kind] = self.reject_reasons.get(e.kind, 0) + 1
            ev = RxEvent(rx_utc, rx_ms, rssi, snr, raw, False, e.kind)
            self.events.append(ev)
            return ev

        self.accepted += 1
        ev = RxEvent(rx_utc, rx_ms, rssi, snr, raw, True, "OK", pkt)
        st = self.sessions.get(pkt.session)
        if st is None:
            st = SessionState(pkt.session)
            self.sessions[pkt.session] = st
            if self.current is not None:
                ev.seq_event = "SESSION_CHANGE"
            self.current = st
        elif st is not self.current:
            ev.seq_event = "SESSION_RESUMED"
            self.current = st

        seq = pkt.pkt_seq
        if st.last_seq is None:
            if seq > 1:   # packets 1..seq-1 of this session never arrived
                self._gap(st, 1, seq - 1, seq, rx_utc)
                ev.seq_event = (ev.seq_event + " GAP").strip()
            st.last_seq = seq
        elif seq == st.last_seq + 1:
            st.last_seq = seq
        elif seq > st.last_seq + 1:
            self._gap(st, st.last_seq + 1, seq - 1, seq, rx_utc)
            ev.seq_event = (ev.seq_event + f" GAP({seq - st.last_seq - 1})").strip()
            st.last_seq = seq
        elif seq in st.received:
            st.duplicates += 1
            ev.seq_event = (ev.seq_event + " DUPLICATE").strip()
        else:
            st.out_of_order += 1
            ev.seq_event = (ev.seq_event + " OUT_OF_ORDER").strip()
        st.received.add(seq)
        self.events.append(ev)
        return ev

    def _gap(self, st: SessionState, first: int, last: int, before: int, utc: str):
        st.gaps.append((first, last))
        self.gap_rows.append({"session": st.session, "first_missing": first,
                              "last_missing": last, "count": last - first + 1,
                              "detected_before_pkt_seq": before, "detected_utc": utc})

    # -- summaries ---------------------------------------------------------
    def missing_count(self, session: Optional[int] = None) -> int:
        sts = [self.sessions[session]] if session is not None else self.sessions.values()
        total = 0
        for st in sts:
            missing = set()
            for a, b in st.gaps:
                missing.update(range(a, b + 1))
            total += len(missing - st.received)   # late arrivals fill gaps
        return total

    def summary(self) -> dict:
        cur = self.current
        return {
            "frames_total": self.frames_total,
            "accepted": self.accepted,
            "rejected": self.rejected,
            "reject_reasons": dict(self.reject_reasons),
            "missing": self.missing_count(),
            "duplicates": sum(s.duplicates for s in self.sessions.values()),
            "out_of_order": sum(s.out_of_order for s in self.sessions.values()),
            "sessions": sorted(self.sessions),
            "last_pkt_seq": cur.last_seq if cur else None,
        }

    # -- logging -----------------------------------------------------------
    def write_logs(self, accepted_csv: str, rejected_csv: str, gaps_csv: str):
        with open(accepted_csv, "w", newline="") as fa, \
             open(rejected_csv, "w", newline="") as fr, \
             open(gaps_csv, "w", newline="") as fg:
            wa, wr, wg = csv.writer(fa), csv.writer(fr), csv.DictWriter(fg, GAP_COLUMNS)
            wa.writerow(ACCEPT_COLUMNS)
            wr.writerow(REJECT_COLUMNS)
            wg.writeheader()
            last_sess, last_seq = "", ""
            for ev in self.events:
                if ev.accepted:
                    p = ev.packet
                    wa.writerow([ev.rx_utc, ev.rx_ms, ev.rssi, ev.snr, p.session, p.pkt_seq,
                                 p.rec_seq, p.t_ms] + [getattr(p, m) for m in MEASUREMENT_FIELDS]
                                + [f"{p.status:04X}", f"{p.crc16:04X}", ev.seq_event])
                    last_sess, last_seq = p.session, p.pkt_seq
                else:
                    wr.writerow([ev.rx_utc, ev.rx_ms, ev.rssi, ev.snr, len(ev.raw), ev.reason,
                                 last_sess, last_seq, ev.raw.hex().upper()])
            for row in self.gap_rows:
                wg.writerow(row)
