"""STRATOS ground-station, packet and reconciliation software (prototype).

Status: software prototype exercised with synthetic data only. Not yet
connected to, or validated with, STRATOS radio hardware.
"""
__version__ = "0.1.0"
