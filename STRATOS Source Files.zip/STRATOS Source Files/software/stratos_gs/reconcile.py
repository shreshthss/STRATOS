"""
Post-mission reconciliation of the recovered onboard log with the ground logs.

Reconciliation rules (format v1), applied per session ID:
  R1  Every onboard CSV line is checked with its line CRC. Lines that fail
      (truncated, corrupted) are counted and excluded from comparison.
  R2  Onboard rec_seq must increase by exactly 1. A jump is an onboard logging
      gap (e.g. RAM buffer overflow or SD write failure), reported separately
      from radio losses.
  R3  The expected-at-ground set is every valid onboard record whose pkt_seq
      column is filled and whose tx column is "T" (radio transmit-complete interrupt seen).
      Records with tx = "F" (radio failure) are not expected at the ground.
  R4  The ground set is every accepted (CRC-valid) packet, de-duplicated by
      (session, pkt_seq).
  R5  Expected and received  -> compare rec_seq, t_ms, all measurement fields
      and the status word. Equal -> MATCH, otherwise MISMATCH (fields listed).
  R6  Expected, not received -> MISSING. Sub-classified as
      "corrupted frame observed" if the ground reject log holds a rejected
      frame received between the neighbouring accepted packets, otherwise
      "no frame observed".
  R7  tx = "F" and not received -> NOT_TRANSMITTED (explained by the onboard
      log). tx = "F" but received -> anomaly RECEIVED_DESPITE_TX_FAIL.
  R8  Received but no valid onboard record with that pkt_seq -> GROUND_ONLY.

A CRC check only detects corruption; it says nothing about whether the sensor
reading itself is physically accurate. Measurement validity is assessed
separately (calibration and plausibility checks).

STATUS: software prototype; exercised with synthetic data only.
"""
from __future__ import annotations

import argparse
import csv
from collections import defaultdict

from .onboard_log import parse_lines, TX_DONE, TX_FAIL
from .packet import MEASUREMENT_FIELDS

COMPARE_FIELDS = ["rec_seq", "t_ms"] + MEASUREMENT_FIELDS + ["status"]


def _load_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def reconcile(onboard_path: str, accepted_path: str, rejected_path: str) -> dict:
    with open(onboard_path, encoding="ascii", errors="replace") as f:
        lines = parse_lines(f)
    accepted = _load_csv(accepted_path)
    rejected = _load_csv(rejected_path)

    res = {"onboard_lines": len(lines), "onboard_valid": 0, "onboard_invalid": [],
           "onboard_gaps": [], "sessions": {}, "discrepancies": []}

    # R1, R2 ---------------------------------------------------------------
    by_session = defaultdict(list)
    for ln in lines:
        if not ln.valid:
            res["onboard_invalid"].append((ln.lineno, ln.reason))
            continue
        res["onboard_valid"] += 1
        by_session[ln.record.session].append(ln)
    for sess, lst in by_session.items():
        lst.sort(key=lambda l: l.record.rec_seq)
        for a, b in zip(lst, lst[1:]):
            if b.record.rec_seq != a.record.rec_seq + 1:
                res["onboard_gaps"].append((sess, a.record.rec_seq + 1, b.record.rec_seq - 1))
    for lineno, reason in res["onboard_invalid"]:
        res["discrepancies"].append({"session": "", "pkt_seq": "", "rec_seq": "",
                                     "class": "ONBOARD_LINE_INVALID",
                                     "detail": f"line {lineno}: {reason}"})
    for sess, a, b in res["onboard_gaps"]:
        res["discrepancies"].append({"session": sess, "pkt_seq": "", "rec_seq": f"{a}-{b}",
                                     "class": "ONBOARD_LOGGING_GAP",
                                     "detail": f"{b - a + 1} record(s) absent from onboard log"})

    # R4: ground set ---------------------------------------------------------
    ground = {}
    dup = 0
    for row in accepted:
        key = (int(row["session"]), int(row["pkt_seq"]))
        if key in ground:
            dup += 1
            continue
        ground[key] = row
    res["ground_accepted_rows"] = len(accepted)
    res["ground_unique"] = len(ground)
    res["ground_duplicates"] = dup
    res["ground_rejected"] = len(rejected)
    reasons = defaultdict(int)
    for r in rejected:
        reasons[r["reason"]] += 1
    res["ground_reject_reasons"] = dict(reasons)

    # Rejected frames indexed by (session, last accepted pkt_seq) so they can be
    # located between neighbouring accepted packets (R6).
    rejects_after = defaultdict(int)
    for r in rejected:
        if r["last_accepted_pkt_seq"]:
            rejects_after[(int(r["last_accepted_session"]), int(r["last_accepted_pkt_seq"]))] += 1

    # R3, R5-R8 per session ---------------------------------------------------
    all_sessions = sorted(set(by_session) | {k[0] for k in ground})
    for sess in all_sessions:
        s = {"records": len(by_session.get(sess, [])), "scheduled": 0, "tx_done": 0,
             "tx_fail": 0, "received": 0, "match": 0, "mismatch": 0, "missing": [],
             "missing_corrupt": [], "not_transmitted": [], "ground_only": [], "ground_recovers": [],
             "anomalies": []}
        expected = {}
        for ln in by_session.get(sess, []):
            if ln.pkt_seq is not None:
                s["scheduled"] += 1
                expected[ln.pkt_seq] = ln
                if ln.tx == TX_DONE:
                    s["tx_done"] += 1
                elif ln.tx == TX_FAIL:
                    s["tx_fail"] += 1
        g_seqs = sorted(k[1] for k in ground if k[0] == sess)
        s["received"] = len(g_seqs)

        for pseq, ln in sorted(expected.items()):
            row = ground.get((sess, pseq))
            if ln.tx == TX_FAIL:
                if row is None:
                    s["not_transmitted"].append(pseq)
                    res["discrepancies"].append({"session": sess, "pkt_seq": pseq,
                        "rec_seq": ln.record.rec_seq, "class": "NOT_TRANSMITTED",
                        "detail": "onboard log records radio TX failure (explained)"})
                else:
                    s["anomalies"].append(pseq)
                    res["discrepancies"].append({"session": sess, "pkt_seq": pseq,
                        "rec_seq": ln.record.rec_seq, "class": "RECEIVED_DESPITE_TX_FAIL",
                        "detail": "investigate TX-done detection"})
                continue
            if row is None:
                prev = max([q for q in g_seqs if q < pseq], default=None)
                corrupt = prev is not None and rejects_after.get((sess, prev), 0) > 0
                if corrupt:
                    s["missing_corrupt"].append(pseq)
                    cls, det = "MISSING_CORRUPTED_FRAME_OBSERVED", \
                        f"rejected frame(s) logged after pkt {prev}; content recovered from onboard log"
                else:
                    s["missing"].append(pseq)
                    cls, det = "MISSING_NO_FRAME_OBSERVED", "no frame received; content recovered from onboard log"
                res["discrepancies"].append({"session": sess, "pkt_seq": pseq,
                                             "rec_seq": ln.record.rec_seq, "class": cls, "detail": det})
                continue
            diffs = []
            for f_ in COMPARE_FIELDS:
                ob = getattr(ln.record, f_)
                gv = int(row[f_], 16) if f_ == "status" else int(row[f_])
                if ob != gv:
                    diffs.append(f"{f_}: onboard={ob} ground={gv}")
            if diffs:
                s["mismatch"] += 1
                res["discrepancies"].append({"session": sess, "pkt_seq": pseq,
                    "rec_seq": ln.record.rec_seq, "class": "MISMATCH", "detail": "; ".join(diffs)})
            else:
                s["match"] += 1
        # (session, rec_seq) prefixes of invalid onboard lines, where readable
        damaged = set()
        for ln in lines:
            if not ln.valid:
                p = ln.raw.split(",")
                if len(p) >= 2 and p[0].isdigit() and p[1].isdigit():
                    damaged.add((int(p[0]), int(p[1])))
        for q in g_seqs:
            if q not in expected:
                rseq = int(ground[(sess, q)]["rec_seq"])
                if (sess, rseq) in damaged:
                    s["ground_recovers"].append(q)
                    res["discrepancies"].append({"session": sess, "pkt_seq": q, "rec_seq": rseq,
                        "class": "GROUND_COPY_OF_INVALID_ONBOARD_LINE",
                        "detail": "onboard line failed its CRC; the CRC-valid ground packet preserves this record (explained)"})
                else:
                    s["ground_only"].append(q)
                    res["discrepancies"].append({"session": sess, "pkt_seq": q, "rec_seq": rseq,
                        "class": "GROUND_ONLY",
                        "detail": "no valid or damaged onboard record carries this pkt_seq"})
        res["sessions"][sess] = s
    return res


def _ranges(nums):
    nums = sorted(nums)
    out, start, prev = [], None, None
    for n in nums:
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            out.append((start, prev)); start = prev = n
    if start is not None:
        out.append((start, prev))
    return ", ".join(f"{a}" if a == b else f"{a}-{b}" for a, b in out) or "none"


def format_report(res: dict, title_note: str = "") -> str:
    L = ["# STRATOS reconciliation report", ""]
    if title_note:
        L += [f"> {title_note}", ""]
    L += ["## Onboard log",
          f"- Data lines read: {res['onboard_lines']}",
          f"- Valid lines (line CRC OK): {res['onboard_valid']}",
          f"- Invalid lines: {len(res['onboard_invalid'])}"
          + (f" ({'; '.join(f'line {a}: {b}' for a, b in res['onboard_invalid'])})" if res['onboard_invalid'] else ""),
          f"- Onboard logging gaps: {len(res['onboard_gaps'])}", "",
          "## Ground logs",
          f"- Accepted rows: {res['ground_accepted_rows']} (unique packets {res['ground_unique']}, duplicates {res['ground_duplicates']})",
          f"- Rejected frames: {res['ground_rejected']} {res['ground_reject_reasons'] or ''}", ""]
    for sess, s in res["sessions"].items():
        missing_all = s["missing"] + s["missing_corrupt"]
        L += [f"## Session {sess}",
              "| Quantity | Count |", "|---|---|",
              f"| Onboard records (valid) | {s['records']} |",
              f"| Packets scheduled onboard | {s['scheduled']} |",
              f"| Radio transmit-complete confirmed onboard | {s['tx_done']} |",
              f"| Radio TX failures logged onboard | {s['tx_fail']} |",
              f"| Unique packets accepted at ground | {s['received']} |",
              f"| Invalid frames rejected at ground (all sessions) | {res['ground_rejected']} |",
              f"| Missing sequence numbers (expected, not received) | {len(missing_all)} |",
              f"| - of which a corrupted frame was observed | {len(s['missing_corrupt'])} |",
              f"| Matching records (packet = onboard record) | {s['match']} |",
              f"| Mismatched records | {s['mismatch']} |",
              f"| Ground packets preserving a damaged onboard line | {len(s['ground_recovers'])} |",
              f"| Ground-only packets (unexplained) | {len(s['ground_only'])} |",
              f"| Unexplained anomalies | {len(s['anomalies'])} |", "",
              f"- Missing, no frame observed: {_ranges(s['missing'])}",
              f"- Missing, corrupted frame observed: {_ranges(s['missing_corrupt'])}",
              f"- Not transmitted (onboard TX failure): {_ranges(s['not_transmitted'])}",
              f"- Ground copy preserves damaged onboard line: {_ranges(s['ground_recovers'])}",
              f"- Ground reception completeness: {s['match'] + s['mismatch']}/{s['tx_done']} = "
              f"{(100 * (s['match'] + s['mismatch']) / s['tx_done']) if s['tx_done'] else 0:.1f} % "
              f"of transmissions confirmed in valid onboard lines",
              ""]
    unresolved = [d for d in res["discrepancies"] if d["class"] in
                  ("MISMATCH", "GROUND_ONLY", "RECEIVED_DESPITE_TX_FAIL")]
    L += ["## Unresolved discrepancies",
          f"{len(unresolved)} unresolved." if unresolved else
          "None. Every missing packet is recoverable from the onboard log, every damaged onboard line is either covered by a ground packet or reported above, and every received packet matches its onboard record.",
          ""]
    return "\n".join(L)


def write_discrepancies(res: dict, path: str):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, ["session", "pkt_seq", "rec_seq", "class", "detail"])
        w.writeheader()
        w.writerows(res["discrepancies"])


def main():
    ap = argparse.ArgumentParser(description="Reconcile STRATOS onboard and ground logs")
    ap.add_argument("onboard_csv")
    ap.add_argument("ground_accepted_csv")
    ap.add_argument("ground_rejected_csv")
    ap.add_argument("--report", default="reconciliation_report.md")
    ap.add_argument("--discrepancies", default="reconciliation_discrepancies.csv")
    ap.add_argument("--note", default="")
    a = ap.parse_args()
    res = reconcile(a.onboard_csv, a.ground_accepted_csv, a.ground_rejected_csv)
    with open(a.report, "w") as f:
        f.write(format_report(res, a.note))
    write_discrepancies(res, a.discrepancies)
    print(format_report(res, a.note))


if __name__ == "__main__":
    main()
