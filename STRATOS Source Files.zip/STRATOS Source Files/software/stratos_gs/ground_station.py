"""
STRATOS ground-station host application (terminal version).

Reads the receiver's serial lines (RX,<ms>,<rssi>,<snr>,<len>,<hex>) either
live from a serial port or from a previously captured file, validates every
frame, tracks sequence numbers, prints a one-line status per frame and writes:
  rx_serial_capture.txt   raw serial lines with host UTC timestamps (evidence)
  ground_accepted.csv     CRC-valid packets, one row each
  ground_rejected.csv     frames that failed validation, with raw bytes
  ground_gaps.csv         missing packet-sequence ranges

STATUS: software prototype. Replay mode has been exercised with synthetic,
simulated captures only. Live serial mode has NOT been connected to STRATOS
receiver hardware.

Usage:
  python -m stratos_gs.ground_station --replay rx_serial_capture.txt --out gs_logs
  python -m stratos_gs.ground_station --serial COM5 --baud 115200 --out gs_logs
"""
from __future__ import annotations

import argparse
import datetime as dt
import os
import sys

from .packet import to_engineering
from .tracker import GroundTracker


def status_line(ev, tracker: GroundTracker, simulated: bool) -> str:
    tag = "[SIM] " if simulated else ""
    s = tracker.summary()
    if not ev.accepted:
        return (f"{tag}{ev.rx_utc}  REJECTED {ev.reason:<7} len={len(ev.raw):<3} "
                f"rssi={ev.rssi:.0f}  | ok={s['accepted']} bad={s['rejected']} miss={s['missing']}")
    p = ev.packet
    e = to_engineering(p)
    fmt = lambda v, f: ("  n/a " if v is None else format(v, f))
    return (f"{tag}{ev.rx_utc}  #{p.pkt_seq:<5} rec={p.rec_seq:<6} T={fmt(e['temp_C'], '6.2f')}C "
            f"P={fmt(e['press_hPa'], '7.2f')}hPa RH={fmt(e['rh_pct'], '5.1f')}% "
            f"Vb={fmt(e['vbat_V'], '4.2f')}V rssi={ev.rssi:.0f} {ev.seq_event:<12}"
            f" | ok={s['accepted']} bad={s['rejected']} miss={s['missing']}")


def run(lines, out_dir: str, simulated: bool, live_capture=None, quiet=False):
    os.makedirs(out_dir, exist_ok=True)
    tr = GroundTracker()
    try:
        for raw in lines:
            raw = raw.strip()
            if not raw or raw.startswith("#"):
                continue
            if raw.startswith("RX,"):                     # live line: stamp with host UTC now
                utc = dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds")
                line = raw
            else:                                         # replay line: "<utc> RX,..."
                utc, _, line = raw.partition(" ")
            if live_capture:
                live_capture.write(f"{utc} {line}\n"); live_capture.flush()
            ev = tr.feed_line(line, utc)
            if ev and not quiet:
                print(status_line(ev, tr, simulated))
    except KeyboardInterrupt:
        pass
    finally:   # logs are always written, including after Ctrl+C in live mode
        tr.write_logs(os.path.join(out_dir, "ground_accepted.csv"),
                      os.path.join(out_dir, "ground_rejected.csv"),
                      os.path.join(out_dir, "ground_gaps.csv"))
    return tr


def main():
    ap = argparse.ArgumentParser(description="STRATOS ground station (prototype)")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--serial", help="serial port of the receiver (live mode)")
    src.add_argument("--replay", help="captured file to replay")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--out", default="gs_logs")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()
    if a.replay:
        with open(a.replay) as f:
            simulated = "SIMULATED" in f.readline().upper()
            f.seek(0)
            tr = run(f, a.out, simulated, quiet=a.quiet)
    else:
        try:
            import serial  # pyserial
        except ImportError:
            sys.exit("pyserial is required for live mode: pip install pyserial")
        os.makedirs(a.out, exist_ok=True)
        port = serial.Serial(a.serial, a.baud, timeout=1)
        lines = (port.readline().decode("ascii", "replace") for _ in iter(int, 1))
        with open(os.path.join(a.out, "rx_serial_capture.txt"), "a") as cap:
            tr = run(lines, a.out, False, live_capture=cap, quiet=a.quiet)
    print("\nSummary:", tr.summary())


if __name__ == "__main__":
    main()
