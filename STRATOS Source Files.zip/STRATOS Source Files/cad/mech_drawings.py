"""
STRATOS_Mechanical_Drawings.pdf — dimensioned drawing sheets generated from the
CadQuery model with OpenCascade hidden-line removal (cad/hlr.py).
Sheets (A3 landscape): 1 general arrangement, 2 internal arrangement + section,
3 exploded view + parts list, 4 fabricated-part details.
"""
import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "design"))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import cadquery as cq
import stratos_cad as SC
from hlr import project, to2d, iso_view
import layout as LY
from baseline import GEOM as G, ENVELOPE, REV, DATE, OVERALL_H

OUT, SRC = sys.argv[1], sys.argv[2]
REPORT = json.load(open(sys.argv[3])) if len(sys.argv) > 3 else None
plt.rcParams["font.family"] = "DejaVu Sans"
fab, hw, mods = SC.build_all()

INK, HID, DIM, NOTE = "#111111", "#9a9a9a", "#1F4E8C", "#B26A00"


def compound(parts):
    return cq.Compound.makeCompound([p.val() for p in parts])


def new_sheet(title, n, total, scale_txt):
    fig = plt.figure(figsize=(16.54, 11.69))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 420); ax.set_ylim(0, 297); ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(plt.Rectangle((10, 10), 400, 277, fill=False, lw=1.2, ec=INK))
    x0, y0, w, h = 270, 10, 140, 34
    ax.add_patch(plt.Rectangle((x0, y0), w, h, fill=False, lw=1.0, ec=INK))
    for yy in (y0 + 11, y0 + 22):
        ax.plot([x0, x0 + w], [yy, yy], color=INK, lw=0.6)
    ax.text(x0 + 3, y0 + 26, f"STRATOS — {title}", fontsize=10, weight="bold")
    ax.text(x0 + 3, y0 + 15, f"Team Nothingburger · Rev {REV} · {DATE} · {scale_txt} · units mm", fontsize=7.5)
    ax.text(x0 + 3, y0 + 4, f"Sheet {n} of {total} · generated from cad/stratos_cad.py (HLR projection)", fontsize=7.5)
    ax.text(14, 281, "PROPOSED DESIGN — NOT YET FABRICATED. Values marked * are PRELIMINARY (module outlines are estimates to be "
            "measured on the actual parts when received).", fontsize=8, color=NOTE, weight="bold")
    return fig, ax


def draw_view(ax, shape, view, origin, scale, hidden=True, lw=0.6, label=None):
    vis, hid = project(shape, view, hidden=hidden)
    ox, oy = origin
    for P in hid:
        ax.plot(ox + scale * P[:, 0], oy + scale * P[:, 1], color=HID, lw=0.35, ls=(0, (2, 1.5)))
    for P in vis:
        ax.plot(ox + scale * P[:, 0], oy + scale * P[:, 1], color=INK, lw=lw)
    if label:
        allp = np.vstack(vis)
        ax.text(ox + scale * allp[:, 0].mean(), oy + scale * allp[:, 1].min() - 9, label, ha="center",
                fontsize=8.5, weight="bold")

    def m(p3):
        u, v = to2d(view, p3)
        return ox + scale * u, oy + scale * v
    return m


def fit_view(ax, shape, view, box, lw=0.5, hidden=False):
    """Project and fit into box = (x0, y0, x1, y1) in sheet mm; returns the model→sheet mapping."""
    vis, hid = project(shape, view, hidden=hidden)
    P = np.vstack(vis)
    (u0, v0), (u1, v1) = P.min(0), P.max(0)
    sc = min((box[2] - box[0]) / (u1 - u0), (box[3] - box[1]) / (v1 - v0))
    ox = (box[0] + box[2]) / 2 - sc * (u0 + u1) / 2
    oy = (box[1] + box[3]) / 2 - sc * (v0 + v1) / 2
    for Q in hid:
        ax.plot(ox + sc * Q[:, 0], oy + sc * Q[:, 1], color=HID, lw=0.35, ls=(0, (2, 1.5)))
    for Q in vis:
        ax.plot(ox + sc * Q[:, 0], oy + sc * Q[:, 1], color=INK, lw=lw)

    def m(p3):
        u, v = to2d(view, p3)
        return ox + sc * u, oy + sc * v
    return m


def place_view(ax, shape, view, center, scale, lw=0.6, hidden=True):
    """Project at a fixed scale with the view's bounding box centred on `center` (sheet mm)."""
    vis, hid = project(shape, view, hidden=hidden)
    P = np.vstack(vis)
    (u0, v0), (u1, v1) = P.min(0), P.max(0)
    ox = center[0] - scale * (u0 + u1) / 2
    oy = center[1] - scale * (v0 + v1) / 2
    for Q in hid:
        ax.plot(ox + scale * Q[:, 0], oy + scale * Q[:, 1], color=HID, lw=0.35, ls=(0, (2, 1.5)))
    for Q in vis:
        ax.plot(ox + scale * Q[:, 0], oy + scale * Q[:, 1], color=INK, lw=lw)

    def m(p3):
        u, v = to2d(view, p3)
        return ox + scale * u, oy + scale * v
    return m


def dim(ax, a, b, off, text, orient="h", fs=7.5):
    (x1, y1), (x2, y2) = a, b
    if orient == "h":
        y = max(y1, y2) + off if off > 0 else min(y1, y2) + off
        ax.plot([x1, x1], [y1, y + np.sign(off) * 1.5], color=DIM, lw=0.4)
        ax.plot([x2, x2], [y2, y + np.sign(off) * 1.5], color=DIM, lw=0.4)
        ax.annotate("", xy=(x1, y), xytext=(x2, y), arrowprops=dict(arrowstyle="<|-|>", color=DIM, lw=0.6,
                                                                 mutation_scale=6, shrinkA=0, shrinkB=0))
        ax.text((x1 + x2) / 2, y + 1.0, text, ha="center", va="bottom", fontsize=fs, color=DIM)
    else:
        x = max(x1, x2) + off if off > 0 else min(x1, x2) + off
        ax.plot([x1, x + np.sign(off) * 1.5], [y1, y1], color=DIM, lw=0.4)
        ax.plot([x2, x + np.sign(off) * 1.5], [y2, y2], color=DIM, lw=0.4)
        ax.annotate("", xy=(x, y1), xytext=(x, y2), arrowprops=dict(arrowstyle="<|-|>", color=DIM, lw=0.6,
                                                                 mutation_scale=6, shrinkA=0, shrinkB=0))
        ax.text(x - 1.0, (y1 + y2) / 2, text, ha="right", va="center", fontsize=fs, color=DIM, rotation=90,
                rotation_mode="anchor") if False else ax.text(x - 0.8, (y1 + y2) / 2, text, ha="center", va="bottom",
                fontsize=fs, color=DIM, rotation=90)


def leader(ax, p, txt, to, fs=7.2, color=INK):
    ax.annotate(txt, xy=p, xytext=to, fontsize=fs, color=color, ha="left", va="center",
                arrowprops=dict(arrowstyle="-|>", color=color, lw=0.5, mutation_scale=6))


def table(ax, x, y, rows, widths, fs=6.8, rh=4.6, head=True):
    for i, r in enumerate(rows):
        cx = x
        for j, (c, w) in enumerate(zip(r, widths)):
            ax.add_patch(plt.Rectangle((cx, y - (i + 1) * rh), w, rh, fill=(i == 0 and head),
                                       fc="#E8EEF5", ec="#666", lw=0.4))
            ax.text(cx + 1, y - (i + 1) * rh + rh / 2, str(c), fontsize=fs, va="center",
                    weight="bold" if (i == 0 and head) else "normal")
            cx += w


ext_parts = [fab[n] for n in ("BottomCap", "Shell", "TopCap", "Yoke", "Spine")] + list(hw.values())
EXT = compound(ext_parts)
INT_A = compound([fab["BottomCap"], fab["TopCap"], fab["Spine"], fab["Yoke"]] + list(hw.values()) + list(mods.values()))
pdf = PdfPages(os.path.join(OUT, "STRATOS_Mechanical_Drawings.pdf"))
pages = []

# =========================================================== sheet 1: general arrangement
fig, ax = new_sheet("General arrangement (exterior)", 1, 4, "scale 1:1")
S = 1.0
mF = draw_view(ax, EXT, "front", (82, 80), S, hidden=False)
ax.text(82, 58, "FRONT (from +Y, face A)", ha="center", fontsize=8.5, weight="bold")
mR = draw_view(ax, EXT, "right", (175, 80), S, hidden=False)
ax.text(175, 58, "RIGHT SIDE (from +X)", ha="center", fontsize=8.5, weight="bold")
mT = draw_view(ax, EXT, "top", (255, 205), S, hidden=False)
ax.text(255, 160, "TOP (from +Z)", ha="center", fontsize=8.5, weight="bold")
mB = draw_view(ax, compound([fab["BottomCap"]]), "bottom", (255, 105), S, hidden=False)
ax.text(255, 63, "BOTTOM (from −Z): access features", ha="center", fontsize=8.5, weight="bold")
for m in (mF, mR):   # rod centre lines (rods are hidden inside the shell)
    for x in (-G["rod_x"], G["rod_x"]):
        a, b = m((x, 0, 0)), m((x, 0, OVERALL_H))
        if abs(a[0] - b[0]) < 0.01:
            ax.plot([a[0], b[0]], [a[1], b[1]], color="#888", lw=0.35, ls=(0, (8, 2, 1, 2)))
ex0, ey0 = mF((ENVELOPE["d_max"] / 2, 0, 0)); ex1, ey1 = mF((-ENVELOPE["d_max"] / 2, 0, ENVELOPE["h_max"]))
ax.add_patch(plt.Rectangle((ex0, ey0), ex1 - ex0, ey1 - ey0, fill=False, ec=NOTE, lw=0.6, ls=(0, (6, 2, 1, 2))))
ax.text(82, 52, f"dash-dot outline = reference envelope Ø{ENVELOPE['d_max']:.0f} × {ENVELOPE['h_max']:.0f} (assumed)", ha="center", fontsize=6.5, color=NOTE)
R = G["cap_d"] / 2
dim(ax, mF((R, 0, 0)), mF((-R, 0, 0)), -9, f"Ø{G['cap_d']:.1f}")
dim(ax, mF((R, 0, 0)), mF((R, 0, OVERALL_H)), -10, f"{OVERALL_H:.1f} overall", "v")
dim(ax, mF((R, 0, 0)), mF((R, 0, LY.Z_TOP_FACE)), -19, f"{LY.Z_TOP_FACE:.0f}", "v")
dim(ax, mF((-R, 0, 0)), mF((-R, 0, G["cap_t"])), 7, f"{G['cap_t']:.0f}", "v")
dim(ax, mF((-R, 0, LY.Z_SHELL0)), mF((-R, 0, LY.Z_SHELL0 + G["shell_len"])), 14, f"{G['shell_len']:.1f} shell", "v")
dim(ax, mF((G["yoke_l"] / 2, 0, LY.Z_YOKE0 + 3)), mF((-G["yoke_l"] / 2, 0, LY.Z_YOKE0 + 3)), 9, f"{G['yoke_l']:.0f} yoke")
dim(ax, mR((0, -5, LY.Z_YOKE0 + 3)), mR((0, 5, LY.Z_YOKE0 + 3)), 9, "10")
dim(ax, mR((0, R, 0)), mR((0, R, LY.Z_SPINE0)), 8, "7", "v")
leader(ax, mR((0, -R, 72)), "4 vent slots 12 × 1.6\n(face B, beside BME280)", (205, 200))
leader(ax, mF((17.5, 32.5, 30)), "6 × Ø1.8 sound holes\n(buzzer, face A)", (20, 45))
dim(ax, mT((-G["rod_x"], 0, 0)), mT((G["rod_x"], 0, 0)), -36, f"{2 * G['rod_x']:.0f} rod centres (2 × M3)")
dim(ax, mB((-R, 0, 0)), mB((R, 0, 0)), -38, f"Ø{G['cap_d']:.1f}")
leader(ax, mB((LY.SWITCH["x"], LY.SWITCH["y"], 0)), "SW1 actuator slot 8 × 3\n(pen-tip operation)", (298, 85))
leader(ax, mB((G["rod_x"], 0, 0)), "M3 nut pockets (2)", (298, 112))
leader(ax, mB((24 * 0.7071, -24 * 0.7071, 0)), "4 × Ø3 drain holes on R24", (298, 135))
note_rows = [["#", "Assumption / unresolved item", "Status"],
             ["A1", "Envelope Ø66 × 115 from ESA CanSat; SEVA FIRST publishes none", "ASSUMED"],
             ["A2", "Rigid height excludes parachute, Y-bridle and swivel", "ASSUMED"],
             ["A3", "PETG prints, 0.4 mm nozzle; spigot fit 0.1 mm radial", "PROPOSED"],
             ["A4", "Module outlines from listings, not drawings", "PRELIM.*"],
             ["A5", "JST-XH mated height at carrier edge ≈2.4 mm to bore", "TO VERIFY"],
             ["A6", "Shell held by spigots (0.4 axial float); anti-rotation", "UNRESOLVED"],
             ["A7", "Final mass / ballast need measured masses", "UNRESOLVED"]]
table(ax, 290, 272, note_rows, [8, 82, 27], fs=6.0, rh=4.4)
ax.text(290, 274, "Mechanical assumptions and unresolved dimensions", fontsize=7.5, weight="bold")
ax.text(290, 228, "Load path (recovery): yoke → 2 × M3 A2 rods → bottom cap nut\n"
        "pockets; the spine is clamped between the caps and carries the\n"
        "modules; the shell is a non-structural sleeve.", fontsize=6.8)
pages.append(fig)

# =========================================================== sheet 2: internal arrangement
fig, ax = new_sheet("Internal arrangement (shell removed) and section", 2, 4, "scale 1.5:1")
S = 1.5
mA = draw_view(ax, INT_A, "front", (75, 62), S, hidden=False, label="FACE A — controller side (from +Y)")
mBv = draw_view(ax, INT_A, "rear", (195, 62), S, hidden=False, label="FACE B — battery / sensors / radio (from −Y)")
# ordinate Z dimensions for main modules
def zord(m, name, x_side, xoff, face):
    p = LY.PLACE[name]
    if p.get("shape") in ("cyl_y", "cyl_z"):
        z0 = p.get("z0", p.get("cz", 0) - p.get("d", 0) / 2); z1 = z0 + p.get("h", p.get("d", 0))
    else:
        z0, z1 = p["z0"], p["z0"] + p["h"]
    a = m((x_side, 0, z0)); b = m((x_side, 0, z1))
    dim(ax, a, b, xoff, f"Z {z0:.1f}–{z1:.1f}", "v", fs=6.2)
zord(mA, "ESP32_DevKitC", -30, -10, "A"); zord(mA, "SD_Breakout", -30, -10, "A")
zord(mA, "U7_Protection", 30, 10, "A"); zord(mA, "Carrier", 30, 22, "A")
zord(mBv, "Batt_Holder", -30, -8, "B"); zord(mBv, "IMU", 30, 9, "B"); zord(mBv, "LoRa", 30, 9, "B")
zord(mBv, "BME280", 30, 9, "B"); zord(mBv, "Antenna", 30, 26, "B")
for (cx, cz) in LY.STANDOFF_HOLES[:4]:
    px, py = mA((cx, 0, cz)); ax.plot(px, py, "+", color="#B3261E", ms=5)
leader(ax, mA((18, 0, 93)), "4 carrier bosses (+)\nM2.5 self-tapping", (mA((18, 0, 93))[0] + 25, mA((18, 0, 93))[1] + 18))
for (cx, cz, w, hh) in LY.CABLE_SLOTS:
    p = mBv((cx, 0, cz))
leader(ax, mBv((-11, 0, 91.5)), "cable slot 14 × 6\n(face A ↔ face B)", (mBv((-11, 0, 91.5))[0] - 42, mBv((-11, 0, 91.5))[1] + 22))
leader(ax, mBv((-8, 0, 11)), "cable slot 10 × 5\n(cell → U7)", (205, 36))
leader(ax, mA((0, 0, 41.6)), "ESP32 micro-USB faces −Z:\nreached with shell removed", (16, 36))
leader(ax, mA((-21.3, 0, 45)), "U5 microSD under the carrier;\ncard at the −X edge (shell removed)", (88, 36))
# section at Z = 55
zc = 55.0
slab = cq.Workplane("XY").box(200, 200, 1.0, centered=(True, True, False)).translate((0, 0, zc - 0.5)).val()
sec_parts = []
for n, p in list(fab.items()) + list(mods.items()) + list(hw.items()):
    try:
        x = p.val().intersect(slab)
        if x.Volume() > 1e-3:
            sec_parts.append(x)
    except Exception:
        pass
SEC = cq.Compound.makeCompound(sec_parts)
mS = draw_view(ax, SEC, "top", (335, 205), 1.5, hidden=False)
ax.text(335, 258, f"SECTION Z = {zc:.0f} (scale 1.5:1, from +Z)", ha="center", fontsize=8.5, weight="bold")
dim(ax, mS((-(G["shell_od"] / 2 - G["shell_wall"]), 0, 0)), mS(((G["shell_od"] / 2 - G["shell_wall"]), 0, 0)), -44,
    f"Ø{G['shell_od'] - 2 * G['shell_wall']:.1f} internal")
ax.text(335, 145, "face A (+Y) up · face B (−Y) down", ha="center", fontsize=7, color="#444")
if REPORT:
    rows = [["Item", "Radial clearance to shell bore (mm)"]]
    items = sorted([(k, v) for k, v in REPORT["radial_clearance"].items() if v is not None], key=lambda t: t[1])[:9]
    rows += [[k, f"{v:.2f}"] for k, v in items]
    table(ax, 290, 128, rows, [40, 62], fs=6.3, rh=4.3)
    ax.text(290, 130, "Smallest computed clearances (CAD check, cad_report.json)", fontsize=7, weight="bold")
pages.append(fig)

# =========================================================== sheet 3: exploded view
fig, ax = new_sheet("Exploded view and parts list", 3, 4, "isometric, not to scale")
off = {"BottomCap": (0, 0, -30), "TopCap": (0, 0, 35), "Yoke": (0, 0, 55), "Shell": (-80, 0, 10)}
parts = []
for n, p in fab.items():
    parts.append(p.val().translate(cq.Vector(*off.get(n, (0, 0, 0)))))
for n, p in hw.items():
    dz = 55 if n in ("Nut2", "Nut4") else (-30 if n in ("Nut1", "Nut3") else 0)
    parts.append(p.val().translate(cq.Vector(0, 0, dz)))
for n, p in mods.items():
    parts.append(p.val())
EXP = cq.Compound.makeCompound(parts)
iv = iso_view((1.0, -1.25, 0.75))
mE = fit_view(ax, EXP, iv, (25, 22, 265, 272), lw=0.45)
balloons = [("1", (0, 0, -30 + 2), "Bottom cap (PETG)"), ("2", (-80, -32.5, 10 + 60), "Shell (PETG)"),
            ("3", (0, 0, 35 + 102), "Top cap (PETG)"), ("4", (20, 0, 55 + 106), "Recovery yoke (Al 6061)"),
            ("5", (G["rod_x"], 0, 100), "M3 A2 threaded rod × 2"), ("6", (-G["rod_x"], 0, 55 + 110), "M3 nyloc nut × 2 (+ washers)"),
            ("7", (8, -1.5, 92), "Spine (PETG) with ribs, bosses, slots"), ("8", (-10.5, -11, 50), "Cell + holder (face B)"),
            ("9", (25, 7.5, 50), "Carrier + ESP32 (face A)"), ("10", (12, -10, 50), "IMU, radio, BME280 (face B)")]
for num, p3, _ in balloons:
    px, py = mE(p3)
    tx, ty = px + (28 if p3[0] >= 0 else -28), py + 10
    ax.annotate("", xy=(px, py), xytext=(tx, ty), arrowprops=dict(arrowstyle="-", color=INK, lw=0.5))
    ax.add_patch(plt.Circle((tx, ty), 3.6, fc="white", ec=INK, lw=0.7))
    ax.text(tx, ty, num, ha="center", va="center", fontsize=7.5, weight="bold")
rows = [["Item", "Part", "Material / source", "Qty"]]
rows += [["1", "Bottom cap", "PETG, printed", "1"], ["2", "Shell sleeve", "PETG, printed", "1"],
         ["3", "Top cap", "PETG, printed", "1"], ["4", "Recovery yoke 58×10×4", "Al 6061-T6 flat bar, drilled", "1"],
         ["5", "Threaded rod M3 × 112.5", "A2 stainless", "2"], ["6", "Nut M3 (bottom) / nyloc M3 (top)", "A2 stainless", "2 + 2"],
         ["7", "Spine", "PETG, printed", "1"], ["8", "18650 cell + holder", "see BOM", "1"],
         ["9", "Carrier assembly", "see BOM / schematic", "1"], ["10", "Face B modules", "see BOM / schematic", "1 set"]]
table(ax, 292, 255, rows, [9, 46, 46, 13], fs=6.4, rh=5.0)
ax.text(292, 257, "Parts list (mechanical)", fontsize=8, weight="bold")
ax.text(292, 190, "Assembly order (proposed):", fontsize=7.5, weight="bold")
for i, t in enumerate(["1  Mount modules on spine bosses; route harness through slots.",
                       "2  Insert rods through bottom-cap pockets and spine ribs.",
                       "3  Seat spine on the bottom cap; fit SW1 in its slot.",
                       "4  Slide shell over the spine (vents aligned with BME280).",
                       "5  Fit top cap, washers, yoke and nyloc nuts; torque lightly.",
                       "6  Attach the Y-bridle (two legs) + swivel + parachute to the yoke."]):
    ax.text(292, 184 - i * 5.2, t, fontsize=7)
pages.append(fig)

# =========================================================== sheet 4: part details
fig, ax = new_sheet("Fabricated part details", 4, 4, "scales as noted")
mBC = place_view(ax, compound([fab["BottomCap"]]), "top", (78, 205), 1.5)
ax.text(78, 134, "BOTTOM CAP — top view (1.5:1)", ha="center", fontsize=8.5, weight="bold")
dim(ax, mBC((-R, 0, 0)), mBC((R, 0, 0)), -50, f"Ø{G['cap_d']:.1f} flange / Ø{G['spigot_d']:.1f} spigot")
dim(ax, mBC((-G["rod_x"], 0, 7)), mBC((G["rod_x"], 0, 7)), 55, f"{2 * G['rod_x']:.0f}: Ø3.4 thru + M3 hex pocket 2.8 deep (underside)")
ax.text(78, 129, "Spigot 3 mm; SW1 slot 8 × 3 with 2 × Ø2.2 at 15 mm pitch;\n4 × Ø3 drains on R24. Print flange-down, 100 % perimeters at pockets.",
        ha="center", va="top", fontsize=6.6)
mTC = place_view(ax, compound([fab["TopCap"]]), "front", (78, 95), 1.5)
ax.text(78, 78, "TOP CAP — front view (1.5:1)", ha="center", fontsize=8.5, weight="bold")
dim(ax, mTC((R, 0, LY.Z_TOP_SPIGOT)), mTC((R, 0, LY.Z_TOP_SPIGOT + G["spigot_h"])), -8, f"{G['spigot_h']:.0f}", "v")
dim(ax, mTC((-R, 0, LY.Z_TOP_SPIGOT + G["spigot_h"])), mTC((-R, 0, LY.Z_TOP_FACE)), 7, f"{G['cap_t']:.0f}", "v")
dim(ax, mTC((R, 0, LY.Z_TOP_FACE)), mTC((-R, 0, LY.Z_TOP_FACE)), 6, f"Ø{G['cap_d']:.0f}")
mSp = place_view(ax, compound([fab["Spine"]]), "front", (192, 160), 1.5, hidden=False)
ax.text(192, 70, "SPINE — face A view (1.5:1)", ha="center", fontsize=8.5, weight="bold")
dim(ax, mSp((G["rod_x"] + 3.5, 0, LY.Z_SPINE0)), mSp((-(G["rod_x"] + 3.5), 0, LY.Z_SPINE0)), -8, f"{2 * G['rod_x'] + G['rib_w']:.0f}")
dim(ax, mSp((-(G["rod_x"] + 3.5), 0, LY.Z_SPINE0)), mSp((-(G["rod_x"] + 3.5), 0, LY.Z_SPINE0 + G["spine_h"])), 8,
    f"{G['spine_h']:.0f}", "v")
ax.text(192, 65, f"Web {G['spine_t']:.0f} mm; ribs {G['rib_w']:.0f} × {G['rib_t']:.0f} mm with Ø3.4 rod bores (print upright);\n"
        "Ø2.7 holes / Ø6 bosses for M2.5 screws; cable slots 14 × 6 and 10 × 5;\nzip-tie slots 2.2 × 5 beside the cell holder.",
        ha="center", va="top", fontsize=6.6)
mY = place_view(ax, compound([fab["Yoke"]]), "top", (330, 248), 2.0, hidden=False)
ax.text(330, 230, "RECOVERY YOKE — top view (2:1)", ha="center", fontsize=8.5, weight="bold")
dim(ax, mY((-G["yoke_l"] / 2, 0, 0)), mY((G["yoke_l"] / 2, 0, 0)), 11, f"{G['yoke_l']:.0f} × {G['yoke_w']:.0f} × {G['yoke_t']:.0f}, R3 corners")
ax.text(330, 224, f"Ø3.4 at ±25 (rods); 2 × Ø4.2 at ±{G['bridle_x']:.0f} (Y-bridle). 6061-T6 flat bar;\n"
        "deburr all holes; edges broken 0.3 mm to protect the bridle.", ha="center", va="top", fontsize=6.6)
mSh = place_view(ax, compound([fab["Shell"]]), "rear", (330, 140), 1.0, hidden=False)
ax.text(330, 70, "SHELL — face B side (1:1)", ha="center", fontsize=8.5, weight="bold")
dim(ax, mSh((-G["shell_od"] / 2, 0, LY.Z_SHELL0)), mSh((-G["shell_od"] / 2, 0, LY.Z_SHELL0 + G["shell_len"])), -8,
    f"{G['shell_len']:.1f}", "v")
dim(ax, mSh((-G["shell_od"] / 2, 0, LY.Z_SHELL0)), mSh((G["shell_od"] / 2, 0, LY.Z_SHELL0)), -8, f"Ø{G['shell_od']:.0f} × {G['shell_wall']} wall")
b = LY.PLACE["BME280"]
ax.text(330, 65, f"Vent slots 4 × (12 × 1.6), pitch 3.0, first at Z {b['z0'] + 1.5:.1f}, centred on X = {b['x0'] + b['w'] / 2:.1f};\n"
        "sound holes 6 × Ø1.8 on face A at Z 30 / 36. Print upright, 3 perimeters.", ha="center", va="top", fontsize=6.6)
pages.append(fig)

for f in pages:
    pdf.savefig(f)
pdf.close()
for i, f in enumerate(pages, start=1):
    f.savefig(os.path.join(SRC, f"STRATOS_Mechanical_Sheet{i}.png"), dpi=160)
print("ok")
