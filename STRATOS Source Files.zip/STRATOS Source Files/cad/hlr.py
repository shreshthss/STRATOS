"""Hidden-line-removed orthographic projection of CadQuery shapes (OpenCascade HLR)."""
import numpy as np
import cadquery as cq
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.gp import gp_Ax2, gp_Pnt, gp_Dir
from OCP.BRepLib import BRepLib

VIEWS = {
    # name: (view normal toward the viewer, screen-x direction)
    "front": ((0, 1, 0), (-1, 0, 0)),     # from +Y (face A)
    "rear": ((0, -1, 0), (1, 0, 0)),      # from −Y (face B)
    "right": ((1, 0, 0), (0, 1, 0)),      # from +X
    "top": ((0, 0, 1), (1, 0, 0)),        # from +Z
    "bottom": ((0, 0, -1), (1, 0, 0)),    # from −Z
}


def iso_view(n=(1.0, -1.0, 0.8)):
    n = np.array(n, float); n /= np.linalg.norm(n)
    x = np.cross([0, 0, 1], n); x /= np.linalg.norm(x)
    return tuple(n), tuple(x)


def basis(view):
    n, x = VIEWS[view] if isinstance(view, str) else view
    n = np.array(n, float); n /= np.linalg.norm(n)
    x = np.array(x, float); x /= np.linalg.norm(x)
    y = np.cross(n, x)
    return n, x, y


def to2d(view, p):
    """Model point → drawing coordinates for the given view."""
    n, x, y = basis(view)
    p = np.asarray(p, float)
    return float(p @ x), float(p @ y)


def project(shape, view, hidden=True, seg_len=0.6):
    """Return (visible, hidden) lists of 2-D polylines (numpy arrays)."""
    n, x, _ = basis(view)
    hlr = HLRBRep_Algo()
    hlr.Add(shape.wrapped if hasattr(shape, "wrapped") else shape)
    hlr.Projector(HLRAlgo_Projector(gp_Ax2(gp_Pnt(0, 0, 0), gp_Dir(*n), gp_Dir(*x))))
    hlr.Update()
    hlr.Hide()
    h2s = HLRBRep_HLRToShape(hlr)
    vis_c = [h2s.VCompound(), h2s.Rg1LineVCompound(), h2s.OutLineVCompound()]
    hid_c = [h2s.HCompound(), h2s.OutLineHCompound()] if hidden else []

    def polylines(comps):
        out = []
        for c in comps:
            if c.IsNull():
                continue
            BRepLib.BuildCurves3d_s(c, 1e-5)
            for e in cq.Shape.cast(c).Edges():
                L = e.Length()
                k = max(2, int(L / seg_len) + 1) if e.geomType() != "LINE" else 2
                pts = [e.positionAt(i / (k - 1)) for i in range(k)]
                out.append(np.array([(p.x, p.y) for p in pts]))
        return out
    return polylines(vis_c), polylines(hid_c)
