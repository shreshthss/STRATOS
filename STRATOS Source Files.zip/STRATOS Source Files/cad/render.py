"""
Z-buffer renderer for the STRATOS CadQuery model (numpy only, no OpenGL).

Tessellates each solid, projects orthographically, rasterises triangles into a
depth buffer with Lambert shading, overlays depth-tested B-rep edges, then
downsamples for anti-aliasing. Returns the image and a projection function so
labels can be placed at true 3-D anchor points. This is a CAD visualisation of
the proposed design, not a photograph of hardware.
"""
import math
import numpy as np
from PIL import Image


def view_basis(az_deg, el_deg):
    az, el = math.radians(az_deg), math.radians(el_deg)
    d = np.array([math.cos(el) * math.cos(az), math.cos(el) * math.sin(az), math.sin(el)])  # toward camera
    right = np.cross([0.0, 0.0, 1.0], d); right /= np.linalg.norm(right)
    up = np.cross(d, right)
    return d, right, up


class Scene:
    def __init__(self, az=-55, el=22, light=(0.35, -0.6, 0.85)):
        self.d, self.r, self.u = view_basis(az, el)
        L = np.array(light, float)
        self.light = L / np.linalg.norm(L)
        self.tris = []      # (Nx3x3 array, rgb)
        self.segs = []      # (Mx2x3 array, rgb)

    def add_shape(self, shape, rgba, offset=(0, 0, 0), edges=True, edge_rgb=None, tol=0.08):
        off = np.array(offset, float)
        verts, faces = shape.tessellate(tol, 0.2)
        V = np.array([(v.x, v.y, v.z) for v in verts]) + off
        F = np.array(faces, dtype=int)
        if len(F):
            self.tris.append((V[F], np.array(rgba[:3], float)))
        if edges:
            er = np.array(edge_rgb if edge_rgb is not None else [c * 0.35 for c in rgba[:3]], float)
            S = []
            for e in shape.Edges():
                try:
                    n = 2 if e.geomType() == "LINE" else max(2, int(e.Length() / 1.0) + 1)
                    P = np.array([(q.x, q.y, q.z) for q in (e.positionAt(i / (n - 1)) for i in range(n))]) + off
                except Exception:
                    continue
                S.append(np.stack([P[:-1], P[1:]], axis=1))
            if S:
                self.segs.append((np.concatenate(S), er))

    def render(self, width_px=1200, height_px=1600, margin=40, ss=2, bg=(255, 255, 255)):
        W, H = width_px * ss, height_px * ss
        allp = np.concatenate([t.reshape(-1, 3) for t, _ in self.tris])
        X, Y = allp @ self.r, allp @ self.u
        xmin, xmax, ymin, ymax = X.min(), X.max(), Y.min(), Y.max()
        sc = min((W - 2 * margin * ss) / (xmax - xmin), (H - 2 * margin * ss) / (ymax - ymin))
        cx, cy = (xmin + xmax) / 2, (ymin + ymax) / 2
        R, U, D = self.r, self.u, self.d

        def px(P):
            return W / 2 + (P @ R - cx) * sc, H / 2 - (P @ U - cy) * sc, P @ D

        zbuf = np.full((H, W), -1e9)
        img = np.zeros((H, W, 3)); img[:] = np.array(bg) / 255.0
        for T, rgb in self.tris:
            n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
            nn = np.linalg.norm(n, axis=1); ok = nn > 1e-12
            T, n = T[ok], n[ok] / nn[ok, None]
            n[(n @ D) < 0] *= -1
            shade = 0.42 + 0.58 * np.clip(n @ self.light, 0, 1) + 0.10 * np.clip(n @ D, 0, 1)
            col = np.clip(rgb[None, :] * shade[:, None], 0, 1)
            sx, sy, sz = px(T.reshape(-1, 3))
            sx, sy, sz = sx.reshape(-1, 3), sy.reshape(-1, 3), sz.reshape(-1, 3)
            for i in range(len(T)):
                x0, x1 = int(max(0, np.floor(sx[i].min()))), int(min(W - 1, np.ceil(sx[i].max())))
                y0, y1 = int(max(0, np.floor(sy[i].min()))), int(min(H - 1, np.ceil(sy[i].max())))
                if x1 < x0 or y1 < y0:
                    continue
                gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
                (ax_, bx, cx_), (ay, by, cy_) = sx[i], sy[i]
                den = (by - cy_) * (ax_ - cx_) + (cx_ - bx) * (ay - cy_)
                if abs(den) < 1e-12:
                    continue
                w0 = ((by - cy_) * (gx - cx_) + (cx_ - bx) * (gy - cy_)) / den
                w1 = ((cy_ - ay) * (gx - cx_) + (ax_ - cx_) * (gy - cy_)) / den
                w2 = 1 - w0 - w1
                m = (w0 >= -1e-6) & (w1 >= -1e-6) & (w2 >= -1e-6)
                if not m.any():
                    continue
                z = w0 * sz[i, 0] + w1 * sz[i, 1] + w2 * sz[i, 2]
                zb = zbuf[y0:y1 + 1, x0:x1 + 1]
                upd = m & (z > zb)
                zb[upd] = z[upd]
                img[y0:y1 + 1, x0:x1 + 1][upd] = col[i]
        # depth-tested edges
        for S, rgb in self.segs:
            a, b = S[:, 0], S[:, 1]
            for j in range(len(S)):
                ax_, ay, az_ = px(a[j][None, :]); bx, by, bz = px(b[j][None, :])
                L = max(2, int(np.hypot(bx - ax_, by - ay)[0] * 1.5))
                t = np.linspace(0, 1, L)
                xs = (ax_ + (bx - ax_) * t).astype(int); ys = (ay + (by - ay) * t).astype(int)
                zs = az_ + (bz - az_) * t
                for ox, oy in ((0, 0), (1, 0), (0, 1)):
                    xx, yy = np.clip(xs + ox, 0, W - 1), np.clip(ys + oy, 0, H - 1)
                    vis = zs >= zbuf[yy, xx] - 0.35
                    img[yy[vis], xx[vis]] = rgb
        out = Image.fromarray((img * 255).astype(np.uint8)).resize((width_px, height_px), Image.LANCZOS)

        def proj_px(p3):
            p = np.asarray(p3, float)
            return (W / 2 + (p @ R - cx) * sc) / ss, (H / 2 - (p @ U - cy) * sc) / ss
        return out, proj_px
