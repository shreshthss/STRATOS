"""Render STRATOS_Main_Assembly.png — labelled conceptual assembly views of the CAD model."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "design"))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import stratos_cad as SC
from render import Scene
import layout as LY
from baseline import GEOM as G, ENVELOPE, REV, DATE, OVERALL_H

OUT = sys.argv[1]
for f in ("Inter", "DejaVu Sans"):
    if any(f in x.name for x in font_manager.fontManager.ttflist):
        plt.rcParams["font.family"] = f; break
fab, hw, mods = SC.build_all()
COL = LY.COLORS


def scene(az, el, include_shell=True, internals=True):
    sc = Scene(az=az, el=el)
    for n, p in fab.items():
        if n == "Shell" and not include_shell:
            continue
        rgba = (0.80, 0.84, 0.90, 1.0) if n == "Shell" else COL[n]
        sc.add_shape(p.val(), rgba)
    for n, p in hw.items():
        sc.add_shape(p.val(), COL["Hardware"], edges=False)
    if internals:
        for n, p in mods.items():
            sc.add_shape(p.val(), COL[LY.PLACE[n]["cat"]])
    return sc


ANCHOR_OVERRIDE = {"Carrier": (-22.0, LY.CARRIER_TOP, 80.0), "SD_Breakout": (-12.0, LY.CARRIER_TOP, 45.0)}


def anchor(name, face):
    if name in ANCHOR_OVERRIDE:
        return ANCHOR_OVERRIDE[name]
    p = LY.PLACE[name]
    if p.get("shape") == "cyl_z":
        return (p["cx"], p["cy"] + (p["d"] / 2 if face == "A" else -p["d"] / 2), p["z0"] + p["h"] * 0.6)
    if p.get("shape") == "cyl_y":
        return (p["cx"], p["y0"] + p["t"], p["cz"])
    y = p["y0"] + p["t"] if face == "A" else p["y0"]
    return (p["x0"] + p["w"] / 2, y, p["z0"] + p["h"] / 2)


BOUNDS = None
views = {}
specs = {
    "ext": dict(az=-48, el=20, include_shell=True),
    "A": dict(az=62, el=16, include_shell=False),
    "B": dict(az=-118, el=16, include_shell=False),
}
for k, v in specs.items():
    sc = scene(v["az"], v["el"], include_shell=v["include_shell"], internals=not v["include_shell"])
    img, proj = sc.render(1100, 1500, margin=50)
    arr = np.asarray(img.convert("L"))
    ys, xs = np.where(arr < 250)
    x0, y0 = max(0, xs.min() - 160), max(0, ys.min() - 30)
    x1, y1 = min(img.size[0], xs.max() + 160), min(img.size[1], ys.max() + 30)
    img = img.crop((x0, y0, x1, y1))
    views[k] = (img, (lambda pr, ox, oy: (lambda p3: (pr(p3)[0] - ox, pr(p3)[1] - oy)))(proj, x0, y0))

fig = plt.figure(figsize=(24, 13.5), dpi=150, facecolor="white")
fig.text(0.02, 0.955, "STRATOS — Conceptual assembly (CAD model, proposed design)", fontsize=24, weight="bold")
fig.text(0.02, 0.925, f"Rev {REV} · {DATE} · Team Nothingburger · rendered from the parametric CadQuery model "
         f"(cad/stratos_cad.py). Not a photograph: no STRATOS hardware has been built.", fontsize=13, color="#52514e")

callA = [("ESP32_DevKitC", "1"), ("SD_Breakout", "2"), ("Regulator", "3"), ("J3_RADIO", "4"), ("BUZZER", "5"),
         ("U7_Protection", "6"), ("Switch", "7"), ("Carrier", "8")]
callB = [("Cell_18650", "9"), ("Batt_Holder", "10"), ("IMU", "11"), ("LoRa", "12"), ("Antenna", "13"), ("BME280", "14")]
ax_pos = {"ext": [0.01, 0.03, 0.24, 0.84], "A": [0.25, 0.03, 0.24, 0.84], "B": [0.49, 0.03, 0.24, 0.84]}
titles = {"ext": "A  Exterior (shell fitted)", "A": "B  Face A — controller side (shell removed)",
          "B": "C  Face B — battery, sensors, radio (shell removed)"}
for k in ("ext", "A", "B"):
    img, proj = views[k]
    ax = fig.add_axes(ax_pos[k]); ax.imshow(img); ax.axis("off")
    ax.set_title(titles[k], fontsize=15, weight="bold", loc="left", color="#0b0b0b")
    W, H = img.size
    if k == "ext":
        ext_labels = [((0, 0, G["cap_t"] + 50), "15  Shell (PETG, removable sleeve)", (0.03, 0.55)),
                      ((-G["rod_x"] + 3, 0, LY.Z_YOKE0 + 2), "16  Recovery yoke + M3 rods", (0.05, 0.93)),
                      ((12, -30, 74), "17  BME280 vent slots", (0.62, 0.62)),
                      ((0, 0, 2), "18  Bottom cap (switch slot below)", (0.05, 0.08))]
        for p3, txt, (fx, fy) in ext_labels:
            px, py = proj(p3)
            ax.annotate(txt, xy=(px, py), xytext=(fx * W, (1 - fy) * H), fontsize=11.5,
                        arrowprops=dict(arrowstyle="-", color="#333", lw=1.0),
                        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#999", lw=0.8))
        continue
    lst = callA if k == "A" else callB
    pts = [(name, num) + tuple(proj(anchor(name, k))) for name, num in lst]
    right = sorted([q for q in pts if q[2] > W * 0.5], key=lambda q: q[3])
    left = sorted([q for q in pts if q[2] <= W * 0.5], key=lambda q: q[3])
    placed = []
    for group, fx in ((right, 0.95), (left, 0.05)):
        n = len(group)
        for j, q in enumerate(group):
            ty = H * (0.15 + (0.72 * (j + 0.5) / max(n, 1)))
            placed.append((q, W * fx, ty))
    for (name, num, px, py), tx, ty in placed:
        ax.annotate(num, xy=(px, py), xytext=(tx, ty), fontsize=12, weight="bold", ha="center", va="center",
                    arrowprops=dict(arrowstyle="-", color="#333", lw=1.0, shrinkA=9),
                    bbox=dict(boxstyle="circle,pad=0.3", fc="#fff4d6", ec="#b26a00", lw=1.2))

# label list
lx = fig.add_axes([0.745, 0.04, 0.25, 0.84]); lx.axis("off")
items = [("1", "U1 ESP32-DevKitC V4 on female headers"), ("2", "U5 microSD breakout, under the carrier (slot at −X edge)"),
         ("3", "U6 S7V8F3 3.3 V regulator"), ("4", "J2/J3/J5 JST-XH harness connectors"), ("5", "BZ1 recovery buzzer"),
         ("6", "U7 TP4056 + DW01A protection module"), ("7", "SW1 DPDT master switch (pen-tip, through cap)"),
         ("8", "50 × 70 mm perfboard carrier on 4 bosses"), ("9", "BT1 18650 Li-ion cell"), ("10", "Single-cell holder"),
         ("11", "U3 LSM6DSOX IMU breakout"), ("12", "U4 Ra-01H radio on adapter"), ("13", "E1 868 MHz helical antenna"),
         ("14", "U2 BME280 breakout beside vents"), ("15", "Shell Ø65 × 95.6 mm, 1.6 mm wall, PETG"),
         ("16", "Al yoke 58 × 10 × 4 mm, 2 bridle holes, on two M3 A2 rods"), ("17", "4 vent slots 12 × 1.6 mm"),
         ("18", "Bottom cap: nut pockets, switch slot, drains")]
lx.text(0.0, 1.0, "Component labels", fontsize=15, weight="bold", va="top")
for i, (n, t) in enumerate(items):
    lx.text(0.0, 0.955 - i * 0.034, n, fontsize=12, weight="bold", color="#b26a00", va="top")
    lx.text(0.07, 0.955 - i * 0.034, t, fontsize=12, va="top")
y0 = 0.955 - len(items) * 0.034 - 0.03
lx.text(0.0, y0, "Key dimensions (mm)", fontsize=14, weight="bold", va="top")
dims = [f"Outer diameter (caps, shell): {G['cap_d']:.1f}  (envelope ≤ {ENVELOPE['d_max']:.0f}, assumed)",
        f"Overall rigid height: {OVERALL_H:.1f}  (envelope ≤ {ENVELOPE['h_max']:.0f}, assumed)",
        f"Spine: {G['spine_h']:.0f} tall, 3 mm web, 7 × 7 mm rod ribs",
        "Internal radial clearance (worst): 1.5 (buzzer to shell)"]
for i, t in enumerate(dims):
    lx.text(0.0, y0 - 0.035 - i * 0.03, t, fontsize=11.5, va="top")
lx.text(0.0, 0.02, "Module outlines are simplified envelopes. Dimensions marked\nPRELIMINARY in the drawings must be measured on the actual parts.",
        fontsize=10.5, color="#7a4a00", va="bottom")
fig.savefig(os.path.join(OUT, "STRATOS_Main_Assembly.png"), facecolor="white")
print("ok")
