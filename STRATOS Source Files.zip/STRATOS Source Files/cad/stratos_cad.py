"""
STRATOS parametric CAD model (CadQuery) — Rev A, proposed design.

Builds every part from design/baseline.py (GEOM) and design/layout.py
(component placements and envelope dimensions), exports:
  * STRATOS_Assembly.step            whole assembly (editable in FreeCAD, Fusion, Onshape, SolidWorks)
  * STRATOS_<part>.step / .stl        individual fabricated parts (caps, shell, spine, yoke)
  * cad_report.json                   volumes, masses of printed parts, envelope checks, interference checks
Electronic modules are represented as simple envelope blocks (labelled
PRELIMINARY where their dimensions are not from a manufacturer drawing).

Coordinates: Z up from the bottom face of the bottom cap; the spine lies in the
X–Z plane; face A (controller side) is +Y, face B (battery/sensor side) is −Y.
"""
import json, os, sys, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "design"))
import cadquery as cq
from baseline import GEOM as G, ENVELOPE
import layout as LY

OUT = sys.argv[1] if (__name__ == "__main__" and len(sys.argv) > 1) else os.path.join(HERE, "out")

R_SHELL_IN = G["shell_od"] / 2 - G["shell_wall"]

# ---------------------------------------------------------------- fabricated parts
def bottom_cap():
    c = (cq.Workplane("XY").circle(G["cap_d"] / 2).extrude(G["cap_t"])
         .faces(">Z").workplane().circle(G["spigot_d"] / 2).extrude(G["spigot_h"]))
    for x in (-G["rod_x"], G["rod_x"]):
        c = c.cut(cq.Workplane("XY").center(x, 0).circle(1.7).extrude(10))
        c = c.cut(cq.Workplane("XY").center(x, 0).polygon(6, 6.6).extrude(2.8))   # M3 nut pocket (6.35 A/C + clearance)
    sw = LY.SWITCH
    c = c.cut(cq.Workplane("XY").center(sw["x"], sw["y"]).rect(sw["slot_w"], sw["slot_l"]).extrude(10))  # actuator slot
    for dx in (-sw["hole_pitch"] / 2, sw["hole_pitch"] / 2):
        c = c.cut(cq.Workplane("XY").center(sw["x"] + dx, sw["y"]).circle(1.1).extrude(10))
    for ang in (45, 135, 225, 315):                                                 # drain holes
        a = math.radians(ang)
        c = c.cut(cq.Workplane("XY").center(24 * math.cos(a), 24 * math.sin(a)).circle(1.5).extrude(10))
    return c

def top_cap():
    z0 = LY.Z_TOP_SPIGOT
    c = (cq.Workplane("XY").workplane(offset=z0).circle(G["spigot_d"] / 2).extrude(G["spigot_h"])
         .faces(">Z").workplane().circle(G["cap_d"] / 2).extrude(G["cap_t"]))
    for x in (-G["rod_x"], G["rod_x"]):
        c = c.cut(cq.Workplane("XY").workplane(offset=z0 - 1).center(x, 0).circle(1.7).extrude(12))
    # antenna-side lightening is not needed; keep the cap plain for printability
    return c

def shell():
    z0, L = LY.Z_SHELL0, G["shell_len"]
    s = (cq.Workplane("XY").workplane(offset=z0).circle(G["shell_od"] / 2).circle(R_SHELL_IN).extrude(L))
    # vent slots beside the BME280 (face B, -Y side)
    b = LY.PLACE["BME280"]
    for i in range(4):
        z = b["z0"] + 1.5 + i * 3.0
        slot = (cq.Workplane("XZ", origin=(0, 0, 0)).center(b["x0"] + b["w"] / 2, z)
                .rect(12.0, 1.6).extrude(40, both=False))   # XZ normal is -Y: extrude toward -Y
        s = s.cut(slot)
    # sound holes opposite the buzzer (face A, +Y side)
    bz = LY.PLACE["BUZZER"]
    for dx in (-3.0, 0.0, 3.0):
        for dz in (-3.0, 3.0):
            h = (cq.Workplane("XZ").center(bz["cx"] + dx, bz["cz"] + dz).circle(0.9).extrude(-40))
            s = s.cut(h)
    return s

def spine():
    z0, h = LY.Z_SPINE0, G["spine_h"]
    web = cq.Workplane("XY").box(2 * (G["rod_x"] - G["rib_w"] / 2), G["spine_t"], h, centered=(True, True, False)).translate((0, 0, z0))
    sp = web
    for x in (-G["rod_x"], G["rod_x"]):
        rib = cq.Workplane("XY").box(G["rib_w"], G["rib_t"], h, centered=(True, True, False)).translate((x, 0, z0))
        sp = sp.union(rib)
        sp = sp.cut(cq.Workplane("XY").workplane(offset=z0 - 1).center(x, 0).circle(1.7).extrude(h + 2))
    # cable pass-through slots
    for (cx, cz, w, hh) in LY.CABLE_SLOTS:
        sp = sp.cut(cq.Workplane("XZ").center(cx, cz).rect(w, hh).extrude(10, both=True))
    # zip-tie slots for the battery (pairs either side of the holder)
    for (cx, cz) in LY.ZIP_SLOTS:
        sp = sp.cut(cq.Workplane("XZ").center(cx, cz).rect(2.2, 5.0).extrude(10, both=True))
    # M2.5 mounting holes for standoffs
    for (cx, cz) in LY.STANDOFF_HOLES:
        sp = sp.cut(cq.Workplane("XZ").center(cx, cz).circle(1.35).extrude(10, both=True))
    return sp

def yoke():
    z0 = LY.Z_YOKE0
    y = cq.Workplane("XY").box(G["yoke_l"], G["yoke_w"], G["yoke_t"], centered=(True, True, False)).translate((0, 0, z0))
    y = y.edges("|Z").fillet(3.0)
    for x in (-G["rod_x"], G["rod_x"]):
        y = y.cut(cq.Workplane("XY").workplane(offset=z0 - 1).center(x, 0).circle(1.7).extrude(8))
    for x in (-G["bridle_x"], G["bridle_x"]):          # Y-bridle attachment holes
        y = y.cut(cq.Workplane("XY").workplane(offset=z0 - 1).center(x, 0).circle(2.1).extrude(8))
    return y

def rods():
    out = []
    for x in (-G["rod_x"], G["rod_x"]):
        out.append(cq.Workplane("XY").workplane(offset=LY.Z_ROD0).center(x, 0).circle(G["rod_d"] / 2).extrude(G["rod_len"]))
    return out

def nuts():
    out = []
    for x in (-G["rod_x"], G["rod_x"]):
        out.append(cq.Workplane("XY").workplane(offset=0.3).center(x, 0).polygon(6, 6.35).circle(1.5).extrude(2.4))   # bottom M3 nut
        out.append(cq.Workplane("XY").workplane(offset=LY.Z_YOKE0 + G["yoke_t"] + 0.5).center(x, 0)
                   .polygon(6, 6.35).circle(1.5).extrude(4.0))                                                   # M3 nyloc nut
    return out

# ---------------------------------------------------------------- module envelopes
def block(p):
    """Axis-aligned envelope block from a placement dict (x0, z0, w (X), h (Z), y0, t (Y thickness))."""
    return cq.Workplane("XY").box(p["w"], p["t"], p["h"], centered=False).translate((p["x0"], p["y0"], p["z0"]))

def cylinder_y(p):
    return (cq.Workplane("XZ").workplane(offset=-p["y0"]).center(p["cx"], p["cz"]).circle(p["d"] / 2).extrude(-p["t"]))

def cylinder_z(p):
    return cq.Workplane("XY").workplane(offset=p["z0"]).center(p["cx"], p["cy"]).circle(p["d"] / 2).extrude(p["h"])

def build_modules():
    parts = {}
    for name, p in LY.PLACE.items():
        if name == "Batt_Holder":            # open tray: cell visible from face B
            tray = block(p)
            cut = cq.Workplane("XY").box(p["w"] - 3.0, p["t"], p["h"] - 6.0, centered=False).translate(
                (p["x0"] + 1.5, p["y0"] - 0.01, p["z0"] + 3.0))
            parts[name] = tray.cut(cut.translate((0, 0, 0)).intersect(
                cq.Workplane("XY").box(p["w"], p["t"] * 0.5 + 0.01, p["h"], centered=False).translate((p["x0"], p["y0"] - 0.01, p["z0"]))))
            continue
        if p.get("shape") == "cyl_y":
            parts[name] = cylinder_y(p)
        elif p.get("shape") == "cyl_z":
            parts[name] = cylinder_z(p)
        else:
            parts[name] = block(p)
    return parts

def build_all():
    fab = {"BottomCap": bottom_cap(), "TopCap": top_cap(), "Shell": shell(), "Spine": spine(), "Yoke": yoke()}
    hw = {f"Rod{i+1}": r for i, r in enumerate(rods())}
    hw.update({f"Nut{i+1}": n for i, n in enumerate(nuts())})
    mods = build_modules()
    return fab, hw, mods


if __name__ == "__main__":
    fab, hw, mods = build_all()

    colors = LY.COLORS
    os.makedirs(OUT, exist_ok=True)
    asm = cq.Assembly(name="STRATOS_RevA")
    for n, p in fab.items():
        asm.add(p, name=n, color=cq.Color(*colors.get(n, (0.8, 0.8, 0.8, 1))))
    for n, p in hw.items():
        asm.add(p, name=n, color=cq.Color(*colors["Hardware"]))
    for n, p in mods.items():
        asm.add(p, name=n, color=cq.Color(*colors.get(LY.PLACE[n]["cat"], (0.5, 0.5, 0.5, 1))))
    asm.export(os.path.join(OUT, "STRATOS_Assembly.step"))
    for n, p in fab.items():
        cq.exporters.export(p, os.path.join(OUT, f"STRATOS_{n}.step"))
        cq.exporters.export(p, os.path.join(OUT, f"STRATOS_{n}.stl"), tolerance=0.05, angularTolerance=0.2)

    # ---------------- checks
    rep = {"fabricated_parts": {}, "envelope": {}, "interference": [], "radial_clearance": {}}
    for n, p in fab.items():
        vol = p.val().Volume()
        mat = LY.MATERIAL[n]
        rep["fabricated_parts"][n] = {"volume_cm3": round(vol / 1000, 3), "material": mat[0],
                                      "density_g_cm3": mat[1], "mass_solid_g": round(vol / 1000 * mat[1], 1)}
    allparts = list(fab.items()) + list(hw.items()) + list(mods.items())
    bb = None
    for n, p in allparts:
        b = p.val().BoundingBox()
        rep["radial_clearance"][n] = None
        bb = b if bb is None else bb.add(b)
    rep["envelope"] = {"x": [round(bb.xmin, 2), round(bb.xmax, 2)], "y": [round(bb.ymin, 2), round(bb.ymax, 2)],
                       "z": [round(bb.zmin, 2), round(bb.zmax, 2)],
                       "max_diameter_used_mm": None, "height_mm": round(bb.zmax - bb.zmin, 2),
                       "limit_d_mm": ENVELOPE["d_max"], "limit_h_mm": ENVELOPE["h_max"]}
    # radial check: every internal item must stay inside the shell inner radius
    worst = (None, 0.0)
    for n, p in list(mods.items()) + [("Spine", fab["Spine"])]:
        verts = p.val().Vertices()
        r = max(math.hypot(v.X, v.Y) for v in verts) if verts else 0
        clear = R_SHELL_IN - r
        rep["radial_clearance"][n] = round(clear, 2)
        if worst[0] is None or clear < worst[1]:
            worst = (n, clear)
    rep["worst_radial_clearance"] = {"item": worst[0], "clearance_mm": round(worst[1], 2)}
    outer_r = max(math.hypot(v.X, v.Y) for n, p in allparts for v in p.val().Vertices())
    rep["envelope"]["max_diameter_used_mm"] = round(2 * outer_r, 2)
    # pairwise interference among internal items (volume of intersection)
    internal = list(mods.items()) + [("Spine", fab["Spine"])] + list(hw.items())
    for i in range(len(internal)):
        for j in range(i + 1, len(internal)):
            a, b = internal[i], internal[j]
            if (a[0], b[0]) in LY.ALLOWED_CONTACT or (b[0], a[0]) in LY.ALLOWED_CONTACT:
                continue
            ba, bb2 = a[1].val().BoundingBox(), b[1].val().BoundingBox()
            if ba.xmax <= bb2.xmin or bb2.xmax <= ba.xmin or ba.ymax <= bb2.ymin or bb2.ymax <= ba.ymin \
               or ba.zmax <= bb2.zmin or bb2.zmax <= ba.zmin:
                continue
            try:
                v = a[1].intersect(b[1]).val().Volume()
            except Exception:
                v = 0.0
            if v > 0.5:
                rep["interference"].append({"a": a[0], "b": b[0], "volume_mm3": round(v, 1)})
    with open(os.path.join(OUT, "cad_report.json"), "w") as f:
        json.dump(rep, f, indent=2)
    print(json.dumps({k: rep[k] for k in ("envelope", "worst_radial_clearance", "interference")}, indent=1))
    print(json.dumps(rep["fabricated_parts"], indent=1))
